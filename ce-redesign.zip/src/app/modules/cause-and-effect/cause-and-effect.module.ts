import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { DeviceHelperService } from '../../shared/services/device-helper.service';
import { SharedModule } from '../../shared/shared.module';
import { DevicesApiService } from '../devices/api/devices-api.service';
import { DeviceResolverService } from '../devices/services/device-resolver.service';
import { DevicesService } from '../devices/services/devices.service';
import { PanelsApiService } from '../panels/api/panels-api.service';
import { ModuleDetailService } from '../panels/services/module-detail.service';
import { AreasApiService } from './../../core/api/areas-api.service';
import { ModulesSettingApiService } from './../panels/api/modules-setting-api.service';
import { ModulesSettingService } from './../panels/services/modules-setting.service';
import { CERuleApiService } from './api/ce-rule-api.service';
import { CauseAndEffectRoutingModule } from './cause-and-effect-routing.module';
import { AddInputPointsComponent } from './component/add-input-points/add-input-points.component';
import { AddInputsComponent } from './component/add-inputs/add-inputs.component';
import { AddOutputPointsComponent } from './component/add-output-points/add-output-points.component';
import { AddOutputsComponent } from './component/add-outputs/add-outputs.component';
import { AddIOModulesComponent } from './component/cause-and-effect--add-io-modules/ce-add-io-modules.component';
import { CauseAndEffectAddDelayTimeComponent } from './component/cause-and-effect-add-delay-time/ce-add-delay-time.component';
import { AddInputDevicesComponent } from './component/cause-and-effect-add-input-devices/ce-add-input-devices.component';
import { CauseAndEffectAddnewruleComponent } from './component/cause-and-effect-addnewrule/ce-addnewrule.component';
import { CauseAndEffectFooterComponent } from './component/cause-and-effect-footer/ce-footer.component';
import { CauseAndEffectInputComponent } from './component/cause-and-effect-input/cause-and-effect-input.component';
import { CauseAndEffectNewruleheaderComponent } from './component/cause-and-effect-newruleheader/ce-newruleheader.component';
import { CauseAndEffectOutputComponent } from './component/cause-and-effect-output/cause-and-effect-output.component';
import { RuleAsInputComponent } from './component/cause-and-effect-rule-as-input/ce-rule-as-input.component';
import { CauseAndEffectRulesHeaderComponent } from './component/cause-and-effect-rules-header/ce-rules-header.component';
import { CauseAndEffectRulesListViewComponent } from './component/cause-and-effect-rules-list-view/ce-rules-list-view.component';
import { CeAddDetectionPointsComponent } from './component/ce-add-detection-points/ce-add-detection-points.component';
import { CeAddFareIOModuleComponent } from './component/ce-add-fare-io-module/ce-add-fare-io-module.component';
import { CeAddManagedAreaComponent } from './component/ce-add-managed-area/ce-add-managed-area.component';
import { CeAddManagedAreaOutputsComponent } from './component/ce-add-managedarea-outputs/ce-add-managedarea-outputs.component';
import { CeAddRemoteLedDevicesComponent } from './component/ce-add-remote-led-devices/ce-add-remote-led-devices.component';
import { CeAddIndicatorLedDevicesComponent } from './component/ce-add-indicator-led-devices/ce-add-indicator-led-devices.component';
import { CERuleService } from './services/ce-rule.service';
import { CeDeleteSuccessComponent } from './component/ce-delete-success/ce-delete-success.component';
import { AgGridModule } from 'ag-grid-angular';
import { AgGridCEInputBlockRendererComponent } from './component/ce-ag-grid-input-cellrenderer/ce-ag-grid-input-cellrenderer';
import { AgGridCEOutputBlockRendererComponent } from './component/ce-ag-grid-output-cellrenderer/ce-ag-grid-output-cellrenderer';
import { CeAddPanelDisconnectedComponent } from './component/ce-add-panel-disconnected/ce-add-panel-disconnected.component';
import { CeAddModuleDisconnectedComponent } from './component/ce-add-module-disconnected/ce-add-module-disconnected.component';
import { CeRuleActionsCellRendererComponent } from './component/ce-rule-actions-cellrenderer/ce-rule-actions-cellrenderer.component';
import { CeRulesPaginationComponent } from './component/ce-rules-pagination/ce-rules-pagination.component';
import { CeAddScheduleComponent } from './component/ce-add-schedule/ce-add-schedule.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CauseAndEffectRoutingModule,
    MatTableModule, 
    AgGridModule
  ],
  declarations: [
    CauseAndEffectRulesListViewComponent,
    CauseAndEffectRulesHeaderComponent,
    CauseAndEffectAddnewruleComponent,
    AddInputsComponent,
    CauseAndEffectNewruleheaderComponent,
    RuleAsInputComponent,
    CauseAndEffectAddDelayTimeComponent,
    AddInputDevicesComponent,
    CauseAndEffectFooterComponent,
    AddIOModulesComponent,
    CeAddFareIOModuleComponent,
    AddInputPointsComponent,
    CeAddManagedAreaComponent,
    CeAddRemoteLedDevicesComponent,
    CeAddIndicatorLedDevicesComponent,
    CeAddDetectionPointsComponent,
    CauseAndEffectInputComponent,
    CauseAndEffectOutputComponent,
    AddOutputsComponent,
    AddOutputPointsComponent,
    CeAddManagedAreaOutputsComponent,
    CeDeleteSuccessComponent,
    AgGridCEInputBlockRendererComponent,
    AgGridCEOutputBlockRendererComponent,
    CeAddPanelDisconnectedComponent,
    CeAddModuleDisconnectedComponent,
    CeAddScheduleComponent,
    CeRuleActionsCellRendererComponent,
    CeRulesPaginationComponent
  ],
  providers: [CERuleService, CERuleApiService, DevicesService,
    PanelsApiService, DeviceResolverService, DeviceHelperService,
    ModuleDetailService, DevicesApiService, ModulesSettingService,
    ModulesSettingApiService, AreasApiService]
})
export class CauseAndEffectModule { }
