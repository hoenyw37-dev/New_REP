import { Component, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { filter, takeUntil } from 'rxjs/operators';
import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { CauseAndEffectOutputActionOn, CEEnums, CERule, InputBlock, OutputAction, OutputBlock, RuleInputEntity, RuleOutputEntity } from '../../../../model/cause-effect';
import { CustomerSite } from '../../../../model/customerSite';
import { DeleteDialogComponent } from '../../../../shared/components/delete-dialog/delete-dialog.component';
import { DialogConfig } from '../../../../shared/components/dialog/model/dialogConfig.model';
import { ScrollSettings } from '../../../../shared/models/grid-models';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { getSelectedSite } from '../../../../state/active-sites';
import { SetAppTitleAction } from '../../../../state/app-title';
import { AppState } from '../../../../state/app.state';
import { CERuleService } from '../../services/ce-rule.service';
import { DialogType, MessageDialog, MessageType } from '../../../../../app/model/message-dialog';
import { MessageDialogComponent } from '../../../../shared/components/message-dialog/message-dialog.component';
import { InputSource } from '../../model/input-source';
import { BehaviorSubject, Observable } from 'rxjs';
import { alertOptions } from '../../../../model/enums';
import { CauseAndEffectAddnewruleComponent } from '../cause-and-effect-addnewrule/ce-addnewrule.component';
import { ColDef, GridApi, GridReadyEvent, ICellRendererParams, ITextFilterParams, RowSelectionOptions, SelectionChangedEvent } from 'ag-grid-community';
import { AllCommunityModule, ModuleRegistry } from 'ag-grid-community';
import { AgGridButtonRendererComponent } from '../../../../shared/components/ag-grid-button-renderer/ag-grid-button-renderer';
import { CeRuleActionsCellRendererComponent } from '../ce-rule-actions-cellrenderer/ce-rule-actions-cellrenderer.component';
import { AgGridCEInputBlockRendererComponent } from '../ce-ag-grid-input-cellrenderer/ce-ag-grid-input-cellrenderer';
import { AgGridCEOutputBlockRendererComponent } from '../ce-ag-grid-output-cellrenderer/ce-ag-grid-output-cellrenderer';

ModuleRegistry.registerModules([AllCommunityModule]);

@Component({
  selector: 'app-cause-and-effect-rules-list-view',
  templateUrl: './ce-rules-list-view.component.html',
  styleUrls: ['./ce-rules-list-view.component.scss']
})
export class CauseAndEffectRulesListViewComponent extends UnsubscribeDirective implements OnInit {

  @ViewChild(DeleteDialogComponent, { static: true }) deletedialogComponentObj: DeleteDialogComponent;
  @ViewChild(MessageDialogComponent, { static: false }) messageDialogComponent: MessageDialogComponent;
  @ViewChild(CauseAndEffectAddnewruleComponent, { static: false }) causeAndEffectAddnewruleComponent: CauseAndEffectAddnewruleComponent;

  deleteRuleDialog: DialogConfig = { key: DialogKeys.DELETE_CE_RULE };
  deleteSuccessDialog: DialogConfig = { key: DialogKeys.CE_DELETE_SUCCESS };
  oneOutAllOutRuleDialog: DialogConfig = { key: DialogKeys.ONEOUT_ALLOUT_INFO };
  saveChangesModuleDialog: DialogConfig = { key: DialogKeys.SAVE_CHANGES_ALERT };
  ruleCount: number = 1;
  ruleHeader: string = 'CAUSEEFFECT_RULE';
  isAddNewRulePopupVisible = false;
  selectedSiteId: string;
  selectedSiteObj: CustomerSite;
  ceEnums: CEEnums = new CEEnums();
  rulesGridData: Array<CERule> = [];
  scrollSettings: ScrollSettings = new ScrollSettings();
  selectedCERule: CERule;
  selectedCERules: CERule[] = [];
  rulePopUpEditMode: boolean = false;
  isDataLoading: boolean = false;
  oneOutAllOutExists: boolean = false;
  checkIfCancelled$ = new BehaviorSubject<boolean>(false);
  alertBoxLabel: string = this.translate.instant('ACTIVESITE_CAUSE_AND_EFFECT');
  isSaveDisabled: boolean = false;
  extendDelay: number = 0;
  showDeleteSelected: boolean = false;
  isMultipleDelete: boolean = false;
  rowDrag: boolean = false;
  wrapText: boolean = false;
  autoHeight: boolean = false;
  defaultColDef: ColDef = {
    flex: 1,
    sortable: true,
    wrapHeaderText: true,
    autoHeight: false,
    autoHeaderHeight: true
  }
  cAndEGridColumnDefs: ColDef<CERule>[] = [];
  gridApi!: GridApi;
  rowSelection: RowSelectionOptions | "single" | "multiple" = {
    mode: "multiRow",
    headerCheckbox: true,
  };
  textFilterParams: ITextFilterParams = {
    filterOptions: [{
      displayKey: "customContains",
      displayName: this.translate.instant('loop-device-grid-view-contains'),
      predicate: (value: any[], cellValue: any) => {
        return cellValue !== null && value.length > 0 && cellValue.toString().toLowerCase().includes(value[0].toString().toLowerCase()) === true
      },
      numberOfInputs: 1
    }],
    maxNumConditions: 1,
    filterPlaceholder: this.translate.instant('COMMON_FILTER') + '...'
  }
  inputOutputFilterParams: ITextFilterParams = {
    filterOptions: [{
      displayKey: "customContains",
      displayName: this.translate.instant('loop-device-grid-view-contains'),
      predicate: (value, cellValue: any[]) => {
        return cellValue.some(item => item.toLowerCase().includes(value[0].toLowerCase()));
      },
      numberOfInputs: 1,
    }],
    maxNumConditions: 1,
    filterPlaceholder: this.translate.instant('COMMON_FILTER') + '...'
  }

  constructor(private ceRuleService: CERuleService, private store: Store<AppState>,
    protected dialogService: DialogService, private translate: TranslateService) {
    super();
    this.store.dispatch(new SetAppTitleAction('ACTIVESITE_CAUSE_AND_EFFECT'));
  }

  ngOnInit() {
    this.makeDomElementInactive('navbar__reports--id');
    this.store.select(getSelectedSite).pipe(filter(site => !!site), takeUntil(this.ngUnsubscribe$)).subscribe(site => {
      this.selectedSiteObj = site;
      this.selectedSiteId = site.id;
      this.scrollSettings.height = 0;
      this.getCERules();
      this.getExtendDelayForSite();
    });
    this.assignCandEGridColumns();
  }

  makeDomElementInactive(domElementId: string) {
    const el = document.getElementById(domElementId);
    if (!!el) {
      el.classList.remove('active');
    }
  }

  private getCERules() {
    this.isDataLoading = true;
    this.ceRuleService.getRules(this.selectedSiteId).subscribe((ruleList: Array<CERule>) => {
      if (ruleList) {
        this.ruleCount = ruleList.length;
        this.ruleHeader = (this.ruleCount > 1) ? 'CAUSEEFFECT_RULES' : 'CAUSEEFFECT_RULE';
        this.oneOutAllOutExists = ruleList.some(rule => rule.ruleNumber == 0);
        this.constructRuleGridData(ruleList);
      }
      this.isDataLoading = false;
    },
    (error: any) => {
      this.isDataLoading = false;
      console.log('Error obtaining C&E rules', error);
    });
  }

  getExtendDelayForSite() {
    this.ceRuleService.getExtendDelayForSite(this.selectedSiteId).subscribe((res) => {
      if (res) {
        this.extendDelay = res.causeAndEffectSetting.extendDelay;
      }
    });
  }

  constructRuleGridData(ruleList: Array<CERule>) {
    this.rulesGridData = ruleList.map(rule =>
    ({
      ruleId: rule.id,
      ruleName: rule.ruleName,
      inputBlock: rule.inputBlock,
      outputBlock: rule.outputBlock,
      siteId: rule.siteId,
      label: rule.label,
      parentOperand: rule.parentOperand,
      isNested: rule.isNested,
      childCauseAndEffectRuleItem: rule.childCauseAndEffectRuleItem,
      isNegated: rule.isNegated,
      activatingDuration: rule.activatingDuration,
      inputDelayTime: rule.inputDelayTime,
      id: rule.id,
      ruleNumber: rule.ruleNumber,
      isSelected: false,
      repeatedAction: rule.repeatedAction,
      isDeactivateAfterActivatingDuration: rule.isDeactivateAfterActivatingDuration,
      isFixedDelay: rule.isFixedDelay
    }));
  }

  /**
   * @description Event handler for add new rule button
   */
  addNewRule() {
    this.isAddNewRulePopupVisible = true;
  }

  triggerAddRemoveOneOutAllOutRule(isAddOneOutAllOutRule: boolean) {
    if (isAddOneOutAllOutRule) {
      this.configureAddOneOutAllOutRuleMsg();
      this.dialogService.openDialog(this.oneOutAllOutRuleDialog.key);
    } else {
      this.confirmOneOutAllOutRuleDeletion();
    }
  }

  private confirmOneOutAllOutRuleDeletion() {
    this.isMultipleDelete = false;
    this.deletedialogComponentObj.config = this.ceRuleService.populateDeleteRuleConfig(this.selectedSiteObj, this.isMultipleDelete, true);
    this.dialogService.openDialog(this.deleteRuleDialog.key);
    const oneOutAllOutRuleId = this.rulesGridData.find(rule => rule.ruleNumber == 0).id;
    this.selectedCERule = new CERule();
    this.selectedCERule.id = oneOutAllOutRuleId;
    this.selectedCERule.isDeactivateAfterActivatingDuration = true;
  }

  private configureAddOneOutAllOutRuleMsg() {
    const infoMessage: MessageDialog = {
      icon: null,
      title: 'ce-add-one-out-all-out',
      messageHeading: '',
      type: MessageType.Info,
      detailedMessage: 'ce-one-out-all-out-description',
      dialogType: DialogType.UserInput,
      okButtonTitle: 'COMMON_OK',
      callbackOkEvent: true,
      callbackCancelEvent: true
    };
    this.messageDialogComponent.config = infoMessage;
  }

  addOneOutAllOutRule() {
    this.dialogService.closeDialog(this.oneOutAllOutRuleDialog.key);
    this.isDataLoading = true;
    this.ceRuleService.createOneOutAllOutRule(this.selectedSiteId).subscribe((rule: CERule) => {
      this.getCERules();
    },
      (error) => {
        console.log('Error occured while creating OneOutAllOutRule', error);
      },
      () => {
        this.isDataLoading = false;
      });
  }

  cancelOneOutAllOutRule() {
    this.oneOutAllOutExists = false;
    this.checkIfCancelled$.next(true);
    this.dialogService.closeDialog(this.oneOutAllOutRuleDialog.key);
  }

  canDeactivate(): Observable<boolean> | boolean {
    if (this.isAddNewRulePopupVisible) {
      this.isSaveDisabled = this.causeAndEffectAddnewruleComponent.isSaveDisabled();
      this.dialogService.openDialog(this.saveChangesModuleDialog.key);
      return this.dialogService.navigateAwaySelection$;
    }
    return true;
  }

  alertSelection(alertOption: alertOptions) {
    switch (alertOption) {
      case alertOptions.Save:
        if (!this.causeAndEffectAddnewruleComponent.isSaveDisabled()) {
          this.causeAndEffectAddnewruleComponent.save();
        }
        break;
      case alertOptions.Discard:
        this.cancel();
        break;
      case alertOptions.Cancel:
        break;
      default:
        break;
    }
  }

  /**
  * @description Event handler for cancel add new rule popup
  */
  cancel() {
    this.isAddNewRulePopupVisible = false;
    this.rulePopUpEditMode = false;
    this.selectedCERules = [];
    this.showDeleteSelected = false;
  }

  /**
   * reset after having saved
   */
  resetAfterSave() {
    this.cancel();
    this.getCERules();
  }

  /**
   * Columns follow the redesign (C_E design frame 1): Rule ID, Rule Name (link), Activating duration,
   * Delay, Last updated, kebab menu. Input/output detail columns were removed from the list because the
   * design does not show them; they remain visible in the rule editor.
   */
  private assignCandEGridColumns() {
    this.cAndEGridColumnDefs = [
      {
        field: 'ruleNumber',
        headerName: this.translate.instant('ce.design.col.rule-id'),
        flex: 1, editable: false, filter: true, filterParams: this.textFilterParams
      },
      {
        field: 'ruleName',
        headerName: this.translate.instant('ce.design.col.rule-name'),
        editable: false, flex: 3, filter: true, filterParams: this.textFilterParams,
        // Rule name is a blue link that opens the editor (rule 0 / One-In-All-Out is not editable).
        cellRenderer: (params: any) => {
          const name = this.translate.instant(params.value);
          if (params.data?.ruleNumber === 0) { return name; }
          const a = document.createElement('a');
          a.className = 'ce-rule-link';
          a.textContent = name;
          a.addEventListener('click', () => this.editCERule({ rowData: params.data }));
          return a;
        }
      },
      {
        field: 'activatingDuration',
        headerName: this.translate.instant('ce.design.col.activating-duration'),
        editable: false, flex: 2,
        cellRenderer: (params: any) => this.getActivatingDuration(params) || this.translate.instant('ce.design.no-value')
      },
      {
        field: 'inputDelayTime',
        headerName: this.translate.instant('ce.design.col.delay'),
        editable: false, flex: 2,
        cellRenderer: (params: any) => this.getInputDelayTime(params) || this.translate.instant('ce.design.no-value')
      },
      {
        // GAP: CERule has no "last updated" field and no backend endpoint returns one. Shows the value
        // only if the API ever supplies `lastUpdated`; otherwise an em dash. See README "Gaps".
        field: 'lastUpdated' as any,
        headerName: this.translate.instant('ce.design.col.last-updated'),
        editable: false, flex: 2,
        valueFormatter: (params: any) => params.value ? new Date(params.value).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' }) : this.translate.instant('ce.design.no-value')
      },
      {
        headerName: '', flex: 0.6, editable: false, resizable: false, sortable: false,
        cellRenderer: CeRuleActionsCellRendererComponent,
        cellRendererParams: {
          onEdit: (p: ICellRendererParams) => this.editCERule({ rowData: p.data }),
          onDuplicate: (p: ICellRendererParams) => this.duplicateCERule({ rowData: p.data }),
          onDelete: (p: ICellRendererParams) => this.deleteCERule({ rowData: p.data })
        }
      }
    ];
  }

  onGridReady(params: GridReadyEvent<CERule>) {
    this.gridApi = params.api;
    this.syncPagination();
  }

  // ---- Redesign additions: search / filter row / custom pagination ----
  pageSize = 10;
  currentPage = 0;
  totalRows = 0;
  floatingFilters = false;

  /** Quick search across all visible columns (header search box). */
  onSearchChange(text: string) {
    this.gridApi?.setGridOption('quickFilterText', text);
    this.syncPagination();
  }

  /** Filter button: toggles ag-Grid per-column floating filters. */
  onFilterToggle(active: boolean) {
    this.floatingFilters = active;
    this.gridApi?.setGridOption('defaultColDef', { ...this.defaultColDef, floatingFilter: active });
  }

  onPageChange(page: number) {
    this.gridApi?.paginationGoToPage(page);
    this.syncPagination();
  }

  /** Pulls current page / row count from ag-Grid so the custom pager stays in sync. */
  syncPagination() {
    if (!this.gridApi) { return; }
    this.currentPage = this.gridApi.paginationGetCurrentPage();
    this.totalRows = this.gridApi.paginationGetRowCount();
  }

  toggleAutoHeight() {
    this.wrapText = !this.wrapText;
    this.autoHeight = !this.autoHeight;
    this.updateDefaultColDef();
    this.gridApi.refreshCells();
    this.gridApi.resetRowHeights();
  }

  toggleRowDrag() {
    this.rowDrag = !this.rowDrag;
    this.assignCandEGridColumns();
    this.gridApi.refreshCells();
  }

  onRowDragEnd(event: any) {
    this.rowDrag = false;
    this.assignCandEGridColumns();
    this.gridApi.refreshCells();
  }

  // To-DO check on this method need
  getRowHeight(params: any): number | undefined {
    return 48;
  }

  private updateDefaultColDef() {
    this.defaultColDef = {
      ...this.defaultColDef,
      wrapText: this.wrapText,
      autoHeight: this.autoHeight
    };
  }

  private getActivatingDuration(params: ICellRendererParams) {
    if (params && params.value) {
      return String(params.value.minutes).padStart(2, '0') + ':' + String(params.value.seconds).padStart(2, '0')
        + ' ' + this.translate.instant('common.min');
    } else if (params && params.data.inputBlock) {
      const inputs = params.data.inputBlock;
      let inputRecurringTime;
      inputs.forEach((item) => {
        if (!!item.inputRecurringTime && ((item.inputRecurringTime.minutes > 0) ||
          (item.inputRecurringTime.seconds > 0))) {
          inputRecurringTime = String(item.inputRecurringTime.minutes).padStart(2, '0') + ':' + String(item.inputRecurringTime.seconds).padStart(2, '0')
            + ' ' + this.translate.instant('common.min');
        }
      });
      return inputRecurringTime;
    }
  }

  private getInputDelayTime(params: ICellRendererParams) {
    if (params && params.value) {
      return String(params.value.minutes).padStart(2, '0') + ':' + String(params.value.seconds).padStart(2, '0')
        + ' ' + this.translate.instant('common.min') + ' ; ' + (params?.data?.isFixedDelay ? this.translate.instant('cause.effect.setting-standard-non-extendable-delay') : this.translate.instant('cause.effect.setting-standard-extendable-delay') + ' : ' + this.extendDelay);
    } else if (params && params.data.inputBlock) {
      const inputs = params.data.inputBlock;
      let inputDelayTime;
      inputs.forEach((item) => {
        if (!!item.inputDelayTime) {
          inputDelayTime = String(item.inputDelayTime.minutes).padStart(2, '0') + ':' + String(item.inputDelayTime.seconds).padStart(2, '0')
            + ' ' + this.translate.instant('common.min') + ' ; ' + (params?.data?.isFixedDelay ? this.translate.instant('cause.effect.setting-standard-non-extendable-delay') : this.translate.instant('cause.effect.setting-standard-extendable-delay') + ' : ' + this.extendDelay);
        }
      });
      return inputDelayTime;
    }
  }

  private getParentOperand(params: ICellRendererParams) {
    if (params && params.value != null) {
      return this.translate.instant(this.ceEnums.zoneOperand.get(params.value));
    }
  }

  private deleteCERule(event) {
    this.selectedCERule = new CERule();
    this.selectedCERule.id = event.rowData.ruleId;
    this.isMultipleDelete = false;
    this.deletedialogComponentObj.config = this.ceRuleService.populateDeleteRuleConfig(this.selectedSiteObj, this.isMultipleDelete, false);
    this.dialogService.openDialog(this.deleteRuleDialog.key);
  }

  private editCERule(event) {
    this.rulePopUpEditMode = true;
    this.ceRuleService.getRule(event.rowData.ruleId).subscribe((rule: CERule) => {
      this.selectedCERule = rule;
      this.isAddNewRulePopupVisible = true;
    },
      (error: any) => {
        console.log('Error obtaining C&E rule', error);
      });
  }

  private duplicateCERule(event) {
    let copiedRule: CERule = JSON.parse(JSON.stringify(event.rowData));
    const copiedFromRuleName = copiedRule.ruleName;
    const numOfRulesWithSameName = this.filterNumberOfRulesWithTheSameName(copiedFromRuleName);

    this.ceRuleService.getRuleNumber(this.selectedSiteId).subscribe((ruleNumber: number) => {
      if (ruleNumber) {
        copiedRule.ruleNumber = ruleNumber;
        copiedRule.ruleName = copiedFromRuleName + ' (' + (numOfRulesWithSameName) + ')';
        copiedRule.id = null;
        copiedRule.label = 'Default';
        this.saveDuplicatedRule(copiedRule);
      }
    },
      (error: any) => {
        console.log('Error obtaining C&E rule number', error);
      });
  }

  private filterNumberOfRulesWithTheSameName(existingRuleName: string) {
    const numOfRulesWithThisName = this.rulesGridData.filter(rule => rule.ruleName.includes(existingRuleName)).length;
    return numOfRulesWithThisName;
  }

  onSelectionChanged(event: SelectionChangedEvent) {
    let selectedData = event.api.getSelectedNodes().map<CERule>(rowData => rowData.data);
    this.selectedCERules = selectedData;
    this.showDeleteSelected = this.selectedCERules.length > 0;
  }

  deleteSelected(event: any) {
    this.isMultipleDelete = true;
    this.deletedialogComponentObj.config = this.ceRuleService.populateDeleteRuleConfig(this.selectedSiteObj, this.isMultipleDelete, false);
    this.dialogService.openDialog(this.deleteRuleDialog.key);
  }

  /**
  * Delete CE Rule
  */
  deleteRule() {
    if (this.isMultipleDelete) {
      let ids = this.selectedCERules.map((rule: CERule) => rule.id);
      this.ceRuleService.deleteSelected(ids).subscribe((response: any) => {
        if (response) {
          this.dialogService.openDialog(this.deleteSuccessDialog.key);
        }
      },
      (error: any) => {
        console.log('Error deleting multiple c & e rule', error);
      });
    }
    else {
      this.ceRuleService.deleteRule(this.selectedCERule.id).subscribe((rule: CERule) => {
        this.clearSelection();
        this.getCERules();
      },
      (error: any) => {
        console.log('Error deleting c & e rule', error);
      });
    }
  }

  deletedSuccessfully(event: any) {
    if (event) {
      this.clearSelection();
      this.dialogService.closeDialog(this.deleteSuccessDialog.key);
      this.getCERules();
    }
  }

  cancelRuleDeletion() {
    this.oneOutAllOutExists = this.rulesGridData.some(rule => rule.ruleNumber == 0);
    this.checkIfCancelled$.next(true);
  }

  private saveDuplicatedRule(duplicatedRule) {
    this.isDataLoading = true;
    this.ceRuleService.saveCERule(duplicatedRule).subscribe((result: CERule) => {
      if (result) {
        console.log('Duplicate Rule Saved  successfully');
      }
    },
    (error: any) => {
      console.log('Error while saving the duplicate rule', error);
    },
    () => {
      this.isDataLoading = false;
      this.resetAfterSave();
    });
  }

  private clearSelection() {
    this.gridApi.deselectAll();
    this.selectedCERules = [];
    this.showDeleteSelected = false;
  }

  private getInputBlockDataForFilter(inputBlock: InputBlock[], ruleNumber: number) {
    let inputsString: string[] = [];
    if (inputBlock && Array.isArray(inputBlock)) {
      if (ruleNumber === 0) {
        const inputType = this.translate.instant(this.ceEnums.inputConditions.get(inputBlock[0].inputType));
        const inputSourceString = this.translate.instant(this.ceEnums.inputSource.get(InputSource.ManagedAreas)).replace('Add', '');
        inputsString.push(inputType);
        inputsString.push(inputSourceString);
      } else {
        inputBlock.map(item => {
          const inputType = this.translate.instant(this.ceEnums.inputConditions.get(item.inputType));
          const inputSourceString = this.translate.instant(this.ceEnums.inputSource.get(item.inputSource)).replace('Add', '');
          let inputDetailsString = '';
          for (let index = 0; index < item.inputSourceDetails.length; index++) {
            inputDetailsString += index === item.inputSourceDetails.length - 1
              ? this.getCompleteInputSourceDetails(item.inputSourceDetails[index])
              : this.getCompleteInputSourceDetails(item.inputSourceDetails[index]) + ', ';
          }
          inputsString.push(inputType);
          inputsString.push(inputSourceString);
          inputsString.push(inputDetailsString);
        });
      };
      return inputsString;
    }
  }

  private getCompleteInputSourceDetails(ruleInput: RuleInputEntity) {
    const sourceDetails = !!ruleInput.zoneNumber ? ruleInput.inputDetails + ' / ' + ruleInput.zoneNumber + ' - ' + ruleInput.zoneRefNumber : ruleInput.inputDetails;
    return sourceDetails;
  }

  private getCompleteOutputSourceDetails(ruleOutput: RuleOutputEntity) {
    const sourceDetails = !!ruleOutput.zoneNumber ? ruleOutput.outputDetails + ' / ' + ruleOutput.zoneNumber + ' - ' + ruleOutput.zoneRefNumber : ruleOutput.outputDetails;
    return sourceDetails;
  }

  private getOutputBlockDataForFilter(outputBlock: OutputBlock[], ruleNumber: number) {
    let outputActionsString: string[] = [];
    if (outputBlock && Array.isArray(outputBlock)) {
      if (ruleNumber === 0) {
        outputBlock.map((item: OutputBlock) => {
          const outputAction = this.translate.instant(Object.entries(item.outputActionType)[0][1]);
          let outputSourceString;
          if (outputAction === OutputAction.Activate) {
            outputSourceString = this.translate.instant(this.ceEnums.outputActionOn.get(CauseAndEffectOutputActionOn.ControlZone));
          }
          else if (outputAction === OutputAction.Evacuate) {
            outputSourceString = this.translate.instant(this.ceEnums.outputActionOn.get(CauseAndEffectOutputActionOn.AlarmZones));
          }
          outputActionsString.push(outputAction);
          outputActionsString.push(outputSourceString);
        });
      } else {
        outputBlock.map((item: OutputBlock) => {
          const outputAction = this.translate.instant(Object.entries(item.outputActionType)[0][1]);
          const outputSourceString = this.translate.instant(this.ceEnums.outputActionOn.get(item.outputActionOn)).replace('Add', '');
          let outputDetailsString = '';
          for (let index = 0; index < item.outputActionDetails.length; index++) {
            outputDetailsString += index === item.outputActionDetails.length - 1 
            ? this.getCompleteOutputSourceDetails(item.outputActionDetails[index])
            : this.getCompleteOutputSourceDetails(item.outputActionDetails[index]) + ', ';
          }
          outputActionsString.push(outputAction);
          outputActionsString.push(outputSourceString);
          outputActionsString.push(outputDetailsString);
        });
      };
    }
    return outputActionsString;
  }
}
