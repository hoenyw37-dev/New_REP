import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';

@Component({
  selector: 'app-cause-and-effect-rules-header',
  templateUrl: './ce-rules-header.component.html',
  styleUrls: ['./ce-rules-header.component.scss']
})
export class CauseAndEffectRulesHeaderComponent extends UnsubscribeDirective implements OnInit, OnChanges, OnDestroy {

  @Input() ruleCount: number;
  @Input() ruleHeader: string;
  @Input() oneOutAllOutExists: boolean = false;
  @Input() checkCancelObservable$: Observable<boolean>;
  @Input() showDeleteSelected: boolean = false;
  @Input() autoHeight: boolean;
  @Input() rowDrag: boolean;

  // Output properties
  @Output() onAddNewRule = new EventEmitter();
  @Output() onAddOneOutAllOutRule = new EventEmitter<boolean>();
  @Output() deleteSelected = new EventEmitter<boolean>();
  @Output() onToggleAutoHeight = new EventEmitter<void>();
  @Output() onToggleRowDrag = new EventEmitter<void>();
  // Redesign additions: quick search text and filter-row toggle.
  @Output() searchChange = new EventEmitter<string>();
  @Output() filterToggle = new EventEmitter<boolean>();
  searchText = '';
  filterActive = false;
  enableOneOutAllOut: boolean = false;

  constructor() {
    super();
  }

  ngOnInit() {
    this.checkCancelObservable$.pipe(takeUntil(this.ngUnsubscribe$)).subscribe((isOperationCancelled: Boolean) => {
      if (isOperationCancelled && this.oneOutAllOutExists) {
        this.enableOneOutAllOut = true;
      } else if (isOperationCancelled && !this.oneOutAllOutExists) {
        this.enableOneOutAllOut = false;
      }
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.hasOwnProperty('oneOutAllOutExists')) {
      this.enableOneOutAllOut = this.oneOutAllOutExists;
    }
  }

  /**
   * @description Event emiter for add new rule icon
   */
  addNewRule() {
    this.onAddNewRule.emit();
  }

  delete() {
    this.deleteSelected.emit(true);
  }

  addOneOutAllOutRule() {
    this.onAddOneOutAllOutRule.emit(this.enableOneOutAllOut);
  }

  onSearch(value: string) {
    this.searchText = value;
    this.searchChange.emit(value);
  }

  toggleFilter() {
    this.filterActive = !this.filterActive;
    this.filterToggle.emit(this.filterActive);
  }

  triggerToggleAutoHeight() {
    this.onToggleAutoHeight.emit();
  }

  triggerToggleRowDrag() {
    this.onToggleRowDrag.emit();
  }

  ngOnDestroy() {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }
}