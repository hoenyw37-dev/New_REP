import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { DialogService } from '../../../../core/services/dialog.service';
import { ZonesService } from '../../../../core/services/zones.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { AreaModalData, CEEnums, CERule, InputBlock, InputBlockDisplay, InputCondition, PanelsModulesModalData, PointsModalData, RuleInputEntity, RuleOption, 
  TriggerCondition, ZoneModalData, ZoneOperand, ZoneType, ScheduleModalData } from '../../../../model/cause-effect';
import { PanelsService } from '../../../../modules/panels/services/panels.service';
import { DialogSize } from '../../../../shared/components/dialog/dialogSize.enum';
import { DialogConfig } from '../../../../shared/components/dialog/model/dialogConfig.model';
import { getSelectedSite } from '../../../../state/active-sites';
import { AppState } from '../../../../state/app.state';
import { InputPoint } from '../../model/add-io-module';
import { InputSource } from '../../model/input-source';
import { CERuleService } from '../../services/ce-rule.service';

const singleInputBlockSupportedInputTypes : InputCondition[] =[ InputCondition.ManualEvacuation,
  InputCondition.Reset, InputCondition.SilenceResound, InputCondition.DelaysExtended,
  InputCondition.Resound
];

@Component({
  selector: 'app-cause-and-effect-input',
  templateUrl: './cause-and-effect-input.component.html',
  styleUrls: ['./cause-and-effect-input.component.scss']
})
export class CauseAndEffectInputComponent implements OnInit, AfterViewInit {
  @Output() parentOperand = new EventEmitter();
  @Output() sendInputBlock = new EventEmitter();
  @Input() ceRuleToEdit: CERule;
  @Input() editMode: boolean;
  @Input() ceRule: CERule;

  isNegated: boolean = false;
  ceEnums = new CEEnums();
  selectedParentOperand = null;
  // ceRule: CERule = new CERule();
  siteId: string;
  inputConditionList: Array<RuleOption> = [];
  selectedInputCondition: RuleOption;
  selectedInputState: RuleOption;
  extendDelay: number = 0;
  inputBlocks: Array<InputBlockDisplay> = [];
  operandList: any = [
    {
      label: this.translate.instant(this.ceEnums.zoneOperand.get(ZoneOperand.All)),
      value: 0,
    },
    {
      label: this.translate.instant(this.ceEnums.zoneOperand.get(ZoneOperand.Or)),
      value: 1,
    }
  ];
  negationOperand: any;
  triggerCondition: TriggerCondition;
  zoneType: ZoneType;
  addInputZonesDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_INPUTS };
  addInputPointsDialog: DialogConfig = { key: DialogKeys.CE_ADD_INPUT_POINTS, size: DialogSize.SMALL_BUT_WIDE };
  addDevicesDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_DEVICES };
  addIOModulesDialog: DialogConfig = { key: DialogKeys.CE_ADD_IO_MODULES };
  addAreaDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_AREA };
  addPanelDisconnectedDialog: DialogConfig = { key: DialogKeys.CE_PANEL_DISCONNECTED };
  addModuleDisconnectedDialog: DialogConfig = { key: DialogKeys.CE_MODULE_DISCONNECTED };
  ceAddScheduleDialog: DialogConfig = { key: DialogKeys.CE_SCHEDULE };

  htmlLanguage: string = 'en';
  selectedInputTypeIndex: InputCondition;
  indexForDialog: any;
  selectedInputBlock: InputBlock;
  modalData: ZoneModalData = new ZoneModalData();
  modalDataForManagedAreas: AreaModalData = new AreaModalData();
  modalDataForPoints: PointsModalData = new PointsModalData();
  modalDataForPanelsModules: PanelsModulesModalData = new PanelsModulesModalData();
  modalDataForSchedule: ScheduleModalData = new ScheduleModalData();
  disableDelay: boolean = false;
  selectedInputPointType: string;

  constructor(
    private translate: TranslateService,
    private ceRuleService: CERuleService,
    private dialogService: DialogService,
    private store: Store<AppState>,
    private zonesService: ZonesService,
    private panelService: PanelsService
  ) { }

  ngOnInit() {
    this.htmlLanguage = document.documentElement.lang;
    this.store.select(getSelectedSite).subscribe(site => {
      if (site) {
        this.siteId = site.id;
        this.getExtendDelayForSite();
      }
    });
    if (this.editMode) {
      this.inputBlocks = this.ceRuleToEdit.inputBlock as InputBlockDisplay[];
      this.selectedParentOperand = this.ceRuleToEdit.parentOperand;
      this.setUpEditWindow();
    } else {
      this.configureInputBlock();
    }
    this.getRuleInputConditions();
  }

  setUpEditWindow() {
    for (let rowIndex = 0; rowIndex < this.inputBlocks.length; rowIndex++) {
      this.displayInputSourceForEdit(rowIndex);
    }
  }

  ngAfterViewInit() {
    // this is called really often, so be careful with it!
    if (document.documentElement.lang !== this.htmlLanguage) {
      this.htmlLanguage = document.documentElement.lang;
    }
  }

  getExtendDelayForSite() {
    this.ceRuleService.getExtendDelayForSite(this.siteId).subscribe((res) => {
      if (res) {
        this.extendDelay = res.causeAndEffectSetting.extendDelay;
      }
    });
  }

  getRuleInputConditions() {
    this.ceRuleService.getRuleInputConditions().subscribe((inputConditionList: Array<RuleOption>) => {
      if (inputConditionList) {
        // TODO: Remove filter when hardware implemented
        this.inputConditionList = inputConditionList.filter(item => (item.name !== 'PreAlarm' && item.name !== 'RuleAsInput'));
      }
    },
    (error: any) => {
      console.log('Error obtaining C&E Input Conditions', error);
    });
  }

  getRuleInputConditionsForDropdown() {
    if (this.ceRule.repeatedAction) {
      return this.inputConditionList.filter(x => x.name.toLowerCase() =="alarm");
    }
    else if (this.inputBlocks.length > 1)
    {
      return this.inputConditionList.filter(x=> !singleInputBlockSupportedInputTypes.includes(x.value));
    }
    else {
      return this.inputConditionList;
    }
  }

  getInputStates(selectedInputCondition, index) {
    if (selectedInputCondition !== null) {
      this.ceRuleService.getRuleInputStates(selectedInputCondition, this.siteId, this.ceRule.repeatedAction).subscribe((list: Array<RuleOption>) => {
        if (list) {
          if (selectedInputCondition === 4) {
            this.inputBlocks[index].displayInputStates = list.filter((item) => (item.name === 'DetectionZones' || item.name === 'AlarmZones' || item.name === 'ControlZones' || item.name === 'InputPoints' || item.name === 'OutputPoints' || item.name === 'ManagedAreas'));
          } else {
            this.inputBlocks[index].displayInputStates = list;
          }
        }
      },
      (error: any) => {
        console.log('Error obtaining C&E Input States', error);
      });
    }
  }

  selectParentOperand() {
    this.parentOperand.emit(this.selectedParentOperand);
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
  }

  setNegation() {
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
  }

  selectInputCondition(selectedCondition, index) {
    this.inputBlocks[index].inputSource = null;
    this.inputBlocks[index].inputSelectedZonesList = null;
    this.inputBlocks[index].inputPointSelectedList = null;
    this.inputBlocks[index].inputSelectedAreaList = null;
    this.inputBlocks[index].inputSelectedPanelsList = null;
    this.inputBlocks[index].inputSelectedModulesList = null;
    this.inputBlocks[index].inputSourceDetails = [];
    this.inputBlocks[index].inputDelayTime = null;
    this.inputBlocks[index].inputRecurringTime = null;
    this.inputBlocks[index].coincedenceIndices = 0;
    this.inputBlocks[index].inputOperand = ZoneOperand.Or;
    this.getInputStates(selectedCondition, index);
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
  }

  selectInputSource(selectedSource, index, isToChange?: boolean) {
    const selection = this.filterSelection(this.inputBlocks[index].displayInputStates, selectedSource);
    if (selection.length > 0) {
      this.selectedInputState = selection[0];
      isToChange = isToChange ? true : false;
      this.selectInputSourceDetails(index, isToChange);
    }
  }

  filterSelection(array: Array<RuleOption>, filter: number) {
    filter = +filter;
    return array.filter((item) => (item.value === filter));
  }

  deleteBlock(selectedindex) {
    this.inputBlocks = this.inputBlocks.filter((item, index) => index !== selectedindex);
    if (this.inputBlocks.length < 2) {
      this.selectedParentOperand = null;
      this.parentOperand.emit(this.selectedParentOperand);
    }
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
  }

  /**
   * Actions to be taken when input source is selected
   */
  selectInputSourceDetails(index, isToChange: boolean) {
    this.indexForDialog = index;
    this.selectedInputBlock = this.inputBlocks[index];
    this.inputBlocks[this.indexForDialog].inputSelectedSchedulesList = null;
    if (isToChange) {
      this.displayInputSourceForEdit(index, true);
    }
    this.triggerCondition = TriggerCondition.Input;
    this.selectedInputTypeIndex = this.inputBlocks[index].inputType;
    switch (this.inputBlocks[index].inputSource) {
      case InputSource.DetectionZones:
      case InputSource.AlarmZones:
      case InputSource.ControlZones:
        if (this.inputBlocks[index].inputSource === InputSource.DetectionZones) {
          this.zoneType = ZoneType.DetectionZones;
        } else if (this.inputBlocks[index].inputSource === InputSource.AlarmZones) {
          this.zoneType = ZoneType.AlarmZones;
        } else if (this.inputBlocks[index].inputSource === InputSource.ControlZones) {
          this.zoneType = ZoneType.ControlZones;
        }
        if (!isToChange) {
          this.modalData.selectedZones = [];
          this.dialogService.openDialog(this.addInputZonesDialog.key);
        }
        break;
      case InputSource.ConfirmationInputPoints:
      case InputSource.ControlInputPoints:
      case InputSource.InputPoints:
      case InputSource.OutputPoints:
      case InputSource.TransferFlags:
        if (this.editMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleInputsToPoints(this.inputBlocks[index].inputSourceDetails);
          this.modalDataForPoints.operand = this.inputBlocks[index].inputOperand;
          this.modalDataForPoints.operandLimit = this.inputBlocks[index].coincedenceIndices;
        } else {
          this.modalDataForPoints.selectedPoints = [];
        }
        this.dialogService.openDialog(this.addInputPointsDialog.key);
        break;
      // case InputSource.InputDevices:
      //   this.dialogService.openDialog(this.addDevicesDialog.key);
      //   break;
      case InputSource.IOModuleInput:
        this.dialogService.openDialog(this.addIOModulesDialog.key);
        break;
      case InputSource.ManagedAreas:
        if (this.editMode || isToChange) {
          this.modalDataForManagedAreas.selectedAreas = this.mapFromRuleInputsToEntityIDs(this.inputBlocks[index].inputSourceDetails);
          this.modalDataForManagedAreas.operand = this.inputBlocks[index].inputOperand;
          this.modalDataForManagedAreas.operandLimit = this.inputBlocks[index].coincedenceIndices;
        } else {
          this.modalDataForManagedAreas.selectedAreas = [];
        }
        this.dialogService.openDialog(this.addAreaDialog.key);
        break;
       case InputSource.PanelDisconnected:
        if (this.editMode || isToChange) {
          this.modalDataForPanelsModules.selectedItems = this.mapFromRuleInputsToPanelDetails(this.inputBlocks[index].inputSourceDetails);
          this.modalDataForPanelsModules.operand = this.inputBlocks[index].inputOperand;
          this.modalDataForPanelsModules.operandLimit = this.inputBlocks[index].coincedenceIndices;
        } else {
          this.modalDataForPanelsModules.selectedItems = [];
        }
        this.dialogService.openDialog(this.addPanelDisconnectedDialog.key);
        break;
      case InputSource.ModuleDisconnected:
        if (this.editMode || isToChange) {
          this.modalDataForPanelsModules.selectedItems = this.mapFromRuleInputsToModuleDetails(this.inputBlocks[index].inputSourceDetails);
          this.modalDataForPanelsModules.operand = this.inputBlocks[index].inputOperand;
          this.modalDataForPanelsModules.operandLimit = this.inputBlocks[index].coincedenceIndices;
        } else {
          this.modalDataForPanelsModules.selectedItems = [];
        }
        this.dialogService.openDialog(this.addModuleDisconnectedDialog.key);
        break;
      case InputSource.Schedule:
        if (this.editMode || isToChange) {
          this.modalDataForSchedule.selectedItems = this.mapFromRuleInputsToScheduleDetails(this.inputBlocks[index].inputSourceDetails);
          this.modalDataForSchedule.operand = this.inputBlocks[index].inputOperand;
          this.modalDataForSchedule.operandLimit = this.inputBlocks[index].coincedenceIndices;
        } else {
          this.modalDataForSchedule.selectedItems = [];
        }
        this.dialogService.openDialog(this.ceAddScheduleDialog.key);
        break;
      default:
        break;
    }
    this.ceRuleService.setBlockDetails(this.selectedInputBlock);
  }

  mapFromRuleInputsToEntityIDs(inputDetails: RuleInputEntity[]): string[] {
    const entityIDs: string[] = inputDetails.map((inputEntity) => inputEntity.inputEntityId);
    return entityIDs;
  }

  private mapFromRuleInputsToEntityDetails(inputDetails: RuleInputEntity[]): string[] {
    const entityDetails: string[] = inputDetails.map((inputEntity) => inputEntity.inputDetails);
    return entityDetails;
  }

  mapFromRuleInputsToPoints(inputSourceDetails: RuleInputEntity[]): InputPoint[] {
    const inputPoints: InputPoint[] = inputSourceDetails.map((inputEntity) => ({
      pointId: inputEntity.inputEntityId, 
      address: inputEntity.inputDetails,
      checked: true, 
      label: 'duno', 
      $deviceType: 'some sensor I guess(?)',
      zones: [{
        deviceReferenceNumber : inputEntity.zoneRefNumber,
        zoneId: '',
        zoneNumber: inputEntity.zoneNumber
      }]
    }));
    return inputPoints;
  }

  private mapFromRuleInputsToPanelDetails(inputDetails: RuleInputEntity[]): any[] {
    const entityDetails: any[] = inputDetails.map((inputEntity) => ({
      id: inputEntity.inputEntityId,
      panelNumber: inputEntity.inputDetails,
      panelLabel: ''
    }));
    return entityDetails;
  }

   private mapFromRuleInputsToModuleDetails(inputDetails: RuleInputEntity[]): any[] {
    const entityDetails: any[] = inputDetails.map((inputEntity) => ({
      id: inputEntity.inputEntityId,
      description: inputEntity.inputDetails
    }));
    return entityDetails;
  }

  private mapFromRuleInputsToScheduleDetails(inputDetails: RuleInputEntity[]): any[] {
    return inputDetails.map((inputEntity) => ({
      id: inputEntity.inputEntityId,
      scheduleDisplay: inputEntity.inputDetails,
      scheduleLabel: inputEntity.inputDetails
    }));
  }

  displayInputSourceForEdit(index, isShowPopup : boolean = false) {
    if (this.editMode) {
      this.getInputStates(this.inputBlocks[index].inputType, index);
    }
    this.inputBlocks[index].inputSelectedSource = this.translate.instant(
      this.ceEnums.inputSourceShort.get(this.inputBlocks[index].inputSource));
    switch (this.inputBlocks[index].inputSource) {
      case InputSource.DetectionZones:
      case InputSource.ControlZones:
      case InputSource.AlarmZones:
        let zoneType;
        if (this.inputBlocks[index].inputSource === InputSource.DetectionZones) {
          zoneType = ZoneType.DetectionZones;
        } else if (this.inputBlocks[index].inputSource === InputSource.ControlZones) {
          zoneType = ZoneType.ControlZones;
        } else if (this.inputBlocks[index].inputSource === InputSource.AlarmZones) {
          zoneType = ZoneType.AlarmZones;
        }
        this.getZonesForSite(index, zoneType, isShowPopup);
        break;
      case InputSource.ConfirmationInputPoints:
      case InputSource.ControlInputPoints:
      case InputSource.InputPoints:
      case InputSource.OutputPoints:
      case InputSource.TransferFlags:
        this.inputBlocks[index].inputPointSelectedList = ' ( ' + this.inputBlocks[index].inputSourceDetails.map.call(this.inputBlocks[index].inputSourceDetails,
        (s: any) => s.inputDetails + ' ').toString() + ' )';
        this.assingnOperandForEdit(index);
        this.modalDataForManagedAreas.operand = this.inputBlocks[index].inputOperand;
        this.modalDataForManagedAreas.operandLimit = this.inputBlocks[index].coincedenceIndices;
        break;
      case InputSource.ManagedAreas:
        this.inputBlocks[index].inputSelectedAreaList =
          this.mapFromRuleInputsToEntityDetails(this.inputBlocks[index].inputSourceDetails).join(', ');
        this.assingnOperandForEdit(index);
        break;
      case InputSource.PanelDisconnected:
        this.inputBlocks[index].inputSelectedPanelsList = ' ( ' +
          this.mapFromRuleInputsToEntityDetails(this.inputBlocks[index].inputSourceDetails).join(', ') + ' )';
        this.assingnOperandForEdit(index);
        break;
      case InputSource.ModuleDisconnected:
        this.inputBlocks[index].inputSelectedModulesList = ' ( ' +
          this.mapFromRuleInputsToEntityDetails(this.inputBlocks[index].inputSourceDetails).join(', ') + ' )';
        this.assingnOperandForEdit(index);
        break;
      case InputSource.Schedule:
        this.inputBlocks[index].inputSelectedSchedulesList = ' ( ' +
          this.mapFromRuleInputsToEntityDetails(this.inputBlocks[index].inputSourceDetails).join(', ') + ' )';
        this.assingnOperandForEdit(index);
        break;
      default:
        break;
    }
  }

  assingnOperandForEdit(index) {
    if (this.inputBlocks[index].inputOperand === 2) {
      this.inputBlocks[index].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(this.inputBlocks[index].inputOperand))
        + '-' + this.inputBlocks[index].coincedenceIndices;
    } else {
      this.inputBlocks[index].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(this.inputBlocks[index].inputOperand));
    }
  }

  getZonesForSite(index: number, zoneType: ZoneType, isShowPopup : boolean) {
    this.indexForDialog = index;
    this.zonesService.getZonesForSite(zoneType, this.siteId, 0, 0).subscribe(async (zonePage) => {
      const allZones = zonePage.payload;
      const zoneDetails = new ZoneModalData();
      zoneDetails.selectedZones = allZones.filter(z => {
        return (this.inputBlocks[index].inputSourceDetails.findIndex(s => s.inputEntityId === z.id) >= 0);
      });
      // do we really have to use now renamed additional properties all of a sudden? phew...
      // let's get that straight somehow...
      zoneDetails.selectedZones.forEach(z => {
        z['Id'] = z.id;
        z['ZoneID'] = `000${z.zoneNumber}`.slice(-6).toString();
        z['ZoneLabel'] = z.label;
        z['panelId'] = z.panelId === null ? '' : z.panelId;
      });
      await this.applyPanelPrefixToInputDetails(index, zoneDetails.selectedZones);
      zoneDetails.operand = this.inputBlocks[index].inputOperand;
      zoneDetails.operandLimit = this.inputBlocks[index].coincedenceIndices;
      this.modalData.operand = this.inputBlocks[index].inputOperand;
      this.modalData.operandLimit = this.inputBlocks[index].coincedenceIndices;
      this.modalData.selectedZones = zoneDetails.selectedZones;
      this.getInputSourceDetails(zoneDetails, index);
      if(isShowPopup) {
        this.dialogService.openDialog(this.addInputZonesDialog.key);
      }
    },
    (error: any) => {
      console.log('error fetching detection zone');
    });
  }

  /**
   * Reconstructs the panel-prefixed details (panelNo.zoneNo) for local zones on edit reload,
   * so the persisted bare zone numbers are displayed and re-saved with the panel prefix.
   */
  private async applyPanelPrefixToInputDetails(index: number, selectedZones: any[]) {
    for (const detail of this.inputBlocks[index].inputSourceDetails) {
      const matchedZone = selectedZones.find(z => z['Id'] === detail.inputEntityId);
      if (matchedZone && matchedZone['panelId'] !== '' && matchedZone['panelId'] !== '00000000-0000-0000-0000-000000000000'
        && !`${detail.inputDetails}`.includes('.')) {
        const panel = await this.panelService.getPanelDetails(matchedZone['panelId']).toPromise();
        detail.inputDetails = `${panel.number}`.padStart(3, '0') + '.' + detail.inputDetails;
      }
    }
  }

  configureInputBlock() {
    const newInput = new InputBlockDisplay();
    newInput['inputType'] = null;
    newInput['inputSource'] = null;
    newInput['inputSourceDetails'] = [];
    newInput['inputOperand'] = ZoneOperand.Or;
    newInput['isNegated'] = false;
    newInput['inputDelayTime'] = null;
    newInput['inputRecurringTime'] = null;
    newInput['inputSelectedZonesList'] = null;
    newInput['inputSelectedPointList'] = null;
    newInput['inputSelectedAreaList'] = null;
    newInput['inputSelectedPanelsList'] = null;
    newInput['inputSelectedModulesList'] = null;
    newInput['inputSelectedSchedulesList'] = null;
    this.inputBlocks.push(newInput);
    if (this.inputBlocks.length > 1) {
      this.selectedParentOperand = 0;
      this.parentOperand.emit(this.selectedParentOperand);
    }
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
  }

  clearInputBlock() {
    this.inputBlocks = [];
    this.configureInputBlock();
  }

  /** Max items listed in the "Input at" field before collapsing to "+N more" (design frame 5). */
  private static readonly SUMMARY_MAX_ITEMS = 5;

  /** True once a zone/area/point/panel/module/schedule selection exists for the block. */
  hasInputSelection(block: any): boolean {
    return !!(block.inputSelectedZonesList || block.inputSelectedAreaList || block.inputPointSelectedList ||
      block.inputSelectedPanelsList || block.inputSelectedModulesList || block.inputSelectedSchedulesList);
  }

  /** Builds the text shown in the "Input at" field: operand chip, first N items and "+N more". */
  getInputAtSummary(block: any): { operand: string; text: string; full: string } {
    const raw = block.inputSelectedZonesList || block.inputSelectedAreaList || block.inputPointSelectedList ||
      block.inputSelectedPanelsList || block.inputSelectedModulesList || block.inputSelectedSchedulesList || '';
    const items: string[] = (Array.isArray(raw) ? raw : String(raw).split(','))
      .map((x: any) => String(x).trim()).filter((x: string) => x.length > 0);
    const max = CauseAndEffectInputComponent.SUMMARY_MAX_ITEMS;
    const shown = items.slice(0, max).join(', ');
    const extra = items.length - max;
    const text = extra > 0 ? `${shown}, ${this.translate.instant('ce.design.more', { count: extra })}` : shown;
    return { operand: block.inputSelectedOperand || '', text, full: items.join(', ') };
  }

  trackByIdx(index: number, obj: any): any {
    return index;
  }

  async getSelectedZoneDetails(zoneDetails: ZoneModalData) {
    const ruleInputEntities: Array<RuleInputEntity> = [];
    for (const selectedZone of zoneDetails.selectedZones) {
      if (selectedZone.panelId !== '' && selectedZone.panelId !== '00000000-0000-0000-0000-000000000000') {
        const panel = await this.panelService.getPanelDetails(selectedZone.panelId).toPromise();
        ruleInputEntities.push({
          inputEntityId: selectedZone.Id,
          inputDetails: `${panel.number}`.padStart(3, '0') + `${'.'}` + `${selectedZone.ZoneID}`
        });
      } else {
        ruleInputEntities.push({
          inputEntityId: selectedZone.Id,
          inputDetails: selectedZone.ZoneID
        });
      }
    }
    this.inputBlocks[this.indexForDialog].inputSourceDetails = ruleInputEntities;
    this.inputBlocks[this.indexForDialog].inputOperand = zoneDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = zoneDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.getInputSourceDetails(zoneDetails, this.indexForDialog);
  }

  /**
  * @description Fetch the input source details
  */
  getInputSourceDetails(zoneDetails: ZoneModalData, rowNum: number) {
    this.resetInputSourceInfo();
    this.inputBlocks[rowNum].inputSelectedSource = this.translate.instant(this.ceEnums.inputSourceShort.get(this.inputBlocks[rowNum].inputSource));
    const zoneInputIds = this.inputBlocks[rowNum].inputSourceDetails.map((inputSourceDetail: any) => inputSourceDetail.inputDetails);
    this.inputBlocks[rowNum].inputSelectedZonesList = ' ( ' + zoneInputIds.join(', ') + ' )';
    if (zoneDetails.operand === 2) {
      this.inputBlocks[rowNum].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(zoneDetails.operand))
        + '-' + zoneDetails.operandLimit;
    } else {
      this.inputBlocks[rowNum].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(zoneDetails.operand));
    }
  }

  getSelectedPointDetails(pointsDetails: PointsModalData) {
    this.resetInputSourceInfo();
    this.inputBlocks[this.indexForDialog].inputSelectedSource = this.translate.instant(this.ceEnums.inputSource.get(this.inputBlocks[this.indexForDialog].inputSource));
    this.inputBlocks[this.indexForDialog].inputSourceDetails = pointsDetails.selectedPoints.map((inputPoint: InputPoint) => ({
      inputEntityId: inputPoint.pointId,
      inputDetails: inputPoint.address,
      zoneNumber: !!inputPoint.zones ? inputPoint.zones.map(zone => `${zone.zoneNumber}`.padStart(2, '0'))[0] : '',
      zoneRefNumber: !!inputPoint.zones ? inputPoint.zones.map(zone => `${zone.deviceReferenceNumber}`.padStart(2, '0'))[0] : ''
    }));
    this.inputBlocks[this.indexForDialog].inputOperand = pointsDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = pointsDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.inputBlocks[this.indexForDialog].inputPointSelectedList = ' ( ' +
      this.inputBlocks[this.indexForDialog].inputSourceDetails.map.call(
        this.inputBlocks[this.indexForDialog].inputSourceDetails,
        (s: any) => s.inputDetails + ' ').toString() + ' )';
    if (pointsDetails.operand === 2) {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(pointsDetails.operand))
        + '-' + pointsDetails.operandLimit;
    } else {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(pointsDetails.operand));
    }
  }

  getSelectedAreaDetails(areaDetails: AreaModalData) {
    this.inputBlocks[this.indexForDialog].inputSourceDetails = areaDetails.selectedAreas.map((area) => ({ inputEntityId: area.Id, inputDetails: area.AreaID }));
    this.inputBlocks[this.indexForDialog].inputOperand = areaDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = areaDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.getAreaInputSourceDetails(areaDetails);
  }

  cancelInputsSelection() {
    if (!this.inputBlocks[this.indexForDialog].inputPointSelectedList &&
      !this.inputBlocks[this.indexForDialog].inputSelectedZonesList &&
      !this.inputBlocks[this.indexForDialog].inputSelectedAreaList &&
      !this.inputBlocks[this.indexForDialog].inputSelectedPanelsList &&
      !this.inputBlocks[this.indexForDialog].inputSelectedModulesList &&
      !this.inputBlocks[this.indexForDialog].inputSelectedSchedulesList) {
      this.inputBlocks[this.indexForDialog].inputSource = null;
    }
  }

  /**
  * @description Fetch the area input source details
  */
  getAreaInputSourceDetails(areaDetails: AreaModalData) {
    this.resetInputSourceInfo();
    const areaInputIds = areaDetails.selectedAreas.map((area: any) => area.AreaID);
    this.inputBlocks[this.indexForDialog].inputSelectedSource = this.translate.instant(
      this.ceEnums.inputSourceShort.get(this.inputBlocks[this.indexForDialog].inputSource));
    this.inputBlocks[this.indexForDialog].inputSelectedAreaList = ' ( ' + areaInputIds.join(', ') + ' )';
    if (areaDetails.operand === 2) {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(areaDetails.operand))
        + '-' + areaDetails.operandLimit;
    } else {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(areaDetails.operand));
    }
  }

  resetInputSourceInfo() {
    this.inputBlocks[this.indexForDialog].inputSelectedZonesList = null;
    this.inputBlocks[this.indexForDialog].inputSelectedAreaList = null;
    this.inputBlocks[this.indexForDialog].inputPointSelectedList = null;
    this.inputBlocks[this.indexForDialog].inputSelectedOperand = null;
    this.inputBlocks[this.indexForDialog].inputSelectedPanelsList = null;
    this.inputBlocks[this.indexForDialog].inputSelectedModulesList = null;
    this.inputBlocks[this.indexForDialog].inputSelectedSchedulesList = null;
  }

  getPointTypeLabel(inputSource) {
    if (inputSource === InputSource.OutputPoints) {
      return "cause-effect.output-point-list";
    } else if (inputSource === InputSource.TransferFlags) {
      return "cause-effect.action-on.transfer-flags";
    } else {
      return "cause-effect.input-point-list";
    }
  }

  getSelectedPanelDetails(panelDetails: PanelsModulesModalData) {
    this.inputBlocks[this.indexForDialog].inputSourceDetails = panelDetails.selectedItems.map((panel) => ({ inputEntityId: panel.id, inputDetails: panel.panelNumber }));
    this.inputBlocks[this.indexForDialog].inputOperand = panelDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = panelDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.getPanelInputSourceDetails(panelDetails);
  }

  getPanelInputSourceDetails(panelDetails: PanelsModulesModalData) {
    this.resetInputSourceInfo();
    const panelInputIds = panelDetails.selectedItems.map((panel: any) => panel.panelNumber);
    this.inputBlocks[this.indexForDialog].inputSelectedSource = this.translate.instant(
      this.ceEnums.inputSourceShort.get(this.inputBlocks[this.indexForDialog].inputSource));
    this.inputBlocks[this.indexForDialog].inputSelectedPanelsList = ' ( ' + panelInputIds.join(', ') + ' )';
    if (panelDetails.operand === 2) {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(panelDetails.operand)) + '-' + panelDetails.operandLimit;
    } else {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(panelDetails.operand));
    }
  }

  getSelectedModuleDetails(moduleDetails: PanelsModulesModalData) {
    this.inputBlocks[this.indexForDialog].inputSourceDetails = moduleDetails.selectedItems.map((module) => ({ inputEntityId: module.id, inputDetails: module.moduleDescription }));
    this.inputBlocks[this.indexForDialog].inputOperand = moduleDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = moduleDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.getModuleInputSourceDetails(moduleDetails);
  }

  getSelectedScheduleDetails(scheduleDetails: PanelsModulesModalData) {
    this.inputBlocks[this.indexForDialog].inputSourceDetails = scheduleDetails.selectedItems.map((schedule) => ({
      inputEntityId: schedule.id,
      inputDetails: schedule.scheduleNumber
    }));
    this.inputBlocks[this.indexForDialog].inputOperand = scheduleDetails.operand;
    this.inputBlocks[this.indexForDialog].coincedenceIndices = scheduleDetails.operandLimit;
    this.sendInputBlock.emit(this.inputBlocks as InputBlock[]);
    this.getScheduleInputSourceDetails(scheduleDetails);
  }

  getModuleInputSourceDetails(moduleDetails: PanelsModulesModalData) {
    this.resetInputSourceInfo();
    const moduleInputIds = moduleDetails.selectedItems.map((module: any) => module.moduleDescription);
    this.inputBlocks[this.indexForDialog].inputSelectedSource = this.translate.instant(
      this.ceEnums.inputSourceShort.get(this.inputBlocks[this.indexForDialog].inputSource));
    this.inputBlocks[this.indexForDialog].inputSelectedModulesList = ' ( ' + moduleInputIds.join(', ') + ' )';
    if (moduleDetails.operand === 2) {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(moduleDetails.operand)) + '-' + moduleDetails.operandLimit;
    } else {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(moduleDetails.operand));
    }
  }

  getScheduleInputSourceDetails(scheduleDetails: PanelsModulesModalData) {
    this.resetInputSourceInfo();
    const scheduleInputIds = scheduleDetails.selectedItems.map((schedule: any) => schedule.scheduleNumber);
    this.inputBlocks[this.indexForDialog].inputSelectedSource = this.translate.instant(
      this.ceEnums.inputSourceShort.get(this.inputBlocks[this.indexForDialog].inputSource));
    this.inputBlocks[this.indexForDialog].inputSelectedSchedulesList = ' ( ' + scheduleInputIds.join(', ') + ' )';
    if (scheduleDetails.operand === 2) {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(
        this.ceEnums.zoneOperand.get(scheduleDetails.operand)) + '-' + scheduleDetails.operandLimit;
    } else {
      this.inputBlocks[this.indexForDialog].inputSelectedOperand = this.translate.instant(this.ceEnums.zoneOperand.get(scheduleDetails.operand));
    }
  }
}