import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';

/**
 * Params supplied by the rules list view. Callbacks are passed in (not injected) so the
 * renderer stays dumb and the list view keeps ownership of edit/duplicate/delete logic.
 */
export interface CeRuleActionsParams extends ICellRendererParams {
  onEdit: (params: ICellRendererParams) => void;
  onDuplicate: (params: ICellRendererParams) => void;
  onDelete: (params: ICellRendererParams) => void;
}

/** Kebab (⋮) row menu from the design: Edit / Duplicate / Delete. */
@Component({
  selector: 'app-ce-rule-actions-cellrenderer',
  templateUrl: './ce-rule-actions-cellrenderer.component.html',
  styleUrls: ['./ce-rule-actions-cellrenderer.component.scss']
})
export class CeRuleActionsCellRendererComponent implements ICellRendererAngularComp {
  params: CeRuleActionsParams;
  /** Rule 0 (the auto-generated One-In-All-Out rule) cannot be edited or duplicated. */
  canEditOrDuplicate = true;

  agInit(params: CeRuleActionsParams): void {
    this.params = params;
    this.canEditOrDuplicate = params.data?.ruleNumber !== 0;
  }

  refresh(): boolean { return false; }
}
