import { Component, EventEmitter, Input, Output } from '@angular/core';

/**
 * Custom pager matching the design ("1-10 records of 28", ‹ 1 2 3 … 6 ›).
 * ag-Grid's built-in panel is suppressed; this component drives it via (pageChange).
 */
@Component({
  selector: 'app-ce-rules-pagination',
  templateUrl: './ce-rules-pagination.component.html',
  styleUrls: ['./ce-rules-pagination.component.scss']
})
export class CeRulesPaginationComponent {
  @Input() total = 0;
  @Input() pageSize = 10;
  /** Zero-based current page. */
  @Input() page = 0;
  @Output() pageChange = new EventEmitter<number>();

  get pageCount(): number { return Math.max(1, Math.ceil(this.total / this.pageSize)); }
  get from(): number { return this.total === 0 ? 0 : this.page * this.pageSize + 1; }
  get to(): number { return Math.min(this.total, (this.page + 1) * this.pageSize); }

  /** Page buttons: first three, an ellipsis (-1) when there is a gap, and the last page. Keeps the current page visible. */
  get pages(): number[] {
    const n = this.pageCount;
    if (n <= 6) { return Array.from({ length: n }, (_, i) => i); }
    const set = new Set<number>([0, 1, 2, n - 1, this.page]);
    const sorted = Array.from(set).filter(p => p >= 0 && p < n).sort((a, b) => a - b);
    const out: number[] = [];
    sorted.forEach((p, i) => { if (i > 0 && p - sorted[i - 1] > 1) { out.push(-1); } out.push(p); });
    return out;
  }

  go(p: number) {
    if (p < 0 || p >= this.pageCount || p === this.page) { return; }
    this.pageChange.emit(p);
  }
}
