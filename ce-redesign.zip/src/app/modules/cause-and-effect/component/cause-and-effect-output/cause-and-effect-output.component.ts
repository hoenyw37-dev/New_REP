import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { DialogService } from '../../../../core/services/dialog.service';
import { ZonesService } from '../../../../core/services/zones.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import {
  AreaModalData, CauseAndEffectOutputActionOn, CEEnums, CERule, DisablementDuration, InputCondition, OutputAction, OutputBlock, OutputBlockDisplay, PointsModalData,
  RuleOption, RuleOutputEntity, TriggerCondition, ZoneModalData, ZoneType
} from '../../../../model/cause-effect';
import { PaginationResult } from '../../../../model/paginationResult';
import { DialogSize } from '../../../../shared/components/dialog/dialogSize.enum';
import { DialogConfig } from '../../../../shared/components/dialog/model/dialogConfig.model';
import { getSelectedSite } from '../../../../state/active-sites';
import { AppState } from '../../../../state/app.state';
import { Zone } from '../../../zones/model/zone';
import { InputPoint } from '../../model/add-io-module';
import { CERuleService } from '../../services/ce-rule.service';
import { PanelsService } from '../../../../modules/panels/services/panels.service';
import { AlarmSignalTypes } from '../../../../model/business-entities/signal-definition';
import { HmiSetting } from '../../../../model/hmi';
import { getActiveSiteHmiSetting } from '../../../settings/state/hmi';
import { DeviceBrand } from '../../../../model/domain/device-brand.enum';

const activationOnlyOutputActions = [OutputAction.ExtendDelay, OutputAction.Reset, OutputAction.Silence,
OutputAction.Resound, OutputAction.Mutebuzzer, OutputAction.Daymode, OutputAction.Nightmode
];

const calendarRestrictedOutputActions = [...activationOnlyOutputActions, OutputAction.AfterDelay, OutputAction.Activate];

@Component({
  selector: 'app-cause-and-effect-output',
  templateUrl: './cause-and-effect-output.component.html',
  styleUrls: ['./cause-and-effect-output.component.scss']
})
export class CauseAndEffectOutputComponent implements OnInit {

  @Input() outputBlocksToEdit: Array<OutputBlock>;
  @Input() isEditMode: boolean;
  @Input() ceRule: CERule;
  @Output() outputBlocksAvailable = new EventEmitter();

  zoneType: ZoneType;
  modalData: ZoneModalData = new ZoneModalData();
  modalDataForManagedAreas: AreaModalData = new AreaModalData();
  modalDataForPoints: PointsModalData = new PointsModalData();
  addOutputPointsDialog: DialogConfig = { key: DialogKeys.CE_ADD_OUTPUT_POINTS, size: DialogSize.SMALL_BUT_WIDE };
  addRemoteLedDevicesDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_REMOTE_LED_DEVICES };
  addIndicatorLedDevicesDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_INDICATOR_LED_DEVICES };
  addDetectionPointsDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_DETECTION_POINTS };
  addAreaDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_AREA_FOR_OUTPUT };
  addOutputsDialog: DialogConfig = { key: DialogKeys.CE_RULE_ADD_OUTPUTS };
  outputActionList: Array<RuleOption> = [];
  ceEnums: CEEnums = new CEEnums();
  causeAndEffectOutputActionOn = CauseAndEffectOutputActionOn;
  selectedOutputBlock: OutputBlock;
  selectedOutputActionIndex: any;
  htmlLanguage: string = 'en';
  triggerCondition: TriggerCondition;
  outputBlocks: Array<OutputBlockDisplay> = [];
  selectedRowIndex: number;
  selectedSiteID: any;
  isCancelled: boolean = false;
  outputBlockToEdit: OutputBlock;
  selectedOutputAction: string;
  hmi: HmiSetting;

  constructor(private ceRuleService: CERuleService, protected dialogService: DialogService,
    private zonesService: ZonesService, private translate: TranslateService, private store: Store<AppState>,
    private panelService: PanelsService) { }

  ngOnInit() {
    this.htmlLanguage = document.documentElement.lang;
    this.store.select(getSelectedSite).subscribe(site => {
      if (site) {
        this.selectedSiteID = site.id;
        this.getRuleOutputActions();
      }
    });
    if (this.isEditMode) {
      this.outputBlocks = this.outputBlocksToEdit as OutputBlockDisplay[];
      this.setUpEditWindow();
    } else {
      this.configureOutputBlock();
    }
    this.store.select(getActiveSiteHmiSetting).subscribe((hmi: HmiSetting) => {
      if(hmi) {
        this.hmi = hmi;
      }
    });
  }

  configureOutputBlock() {
    const newOutput = new OutputBlockDisplay();
    this.outputBlocks.push(newOutput);
    this.notifyParentOfOutputBlock();
  }

  clearOutputBlock() {
    this.outputBlocks = [];
    this.configureOutputBlock();
  }

  getRuleOutputActions() {
    this.ceRuleService.getRuleOutputActions(this.selectedSiteID).subscribe((outputActions: { [type: number]: any }) => {
      if (outputActions) {
        this.outputActionList = Object.entries(outputActions).map(item => {
          return {
            value: parseInt(item[0], 10),
            name: item[1].item1,
            type: item[1].item2
          };
        });
        // TODO: Remove filter when hardware implemented
        this.outputActionList = this.outputActionList.filter(item => item.name !== 'AfterDelay');
      }
    },
      (error: any) => {
        console.log('Error obtaining C&E Output Actions', error);
      });
  }

  outputActionListForDropdown() {
    if (this.ceRule.repeatedAction) {
      // Returning only signals which have type as FARE
      return this.outputActionList.filter(x => x.type === AlarmSignalTypes.Fare);
    }
    else if (this.hasOnlyCalendarInputs()) {
      return this.outputActionList.filter(outputAction =>
        outputAction.type === AlarmSignalTypes.None
        && !calendarRestrictedOutputActions.includes(outputAction.name as OutputAction));
    }
    else if (!this.hasOnlyActivationInputs()) {
      return this.outputActionList.filter(outputAction => !activationOnlyOutputActions.includes(outputAction.name as OutputAction));
    }
    else {
      return this.outputActionList;
    }
  }

  selectOutputAction(selectedActionType: any, index: number) {
    this.clearAllPreviousOutputSelections(index);
    this.outputBlocks[index].outputActionType = {};
    this.outputBlocks[index].disablementDuration = { hour: 0, min: 0 };
    const key = this.outputActionList.filter(x => x.name === selectedActionType)[0].value;
    this.outputBlocks[index].outputActionType[key] = this.outputBlocks[index].displayOutputActionType;
    this.getOutputStates(selectedActionType, index);
    this.notifyParentOfOutputBlock();
  }

  getOutputStates(selectedActionType: string, index: number) {
    if (selectedActionType !== null) {
      this.ceRuleService.getRuleOutputStates(selectedActionType, this.selectedSiteID, this.ceRule.repeatedAction).subscribe((list: Array<RuleOption>) => {
        if (list) {
          if (this.hmi.deviceBrand === DeviceBrand.Esser)
          {
            let outputActionTypeValue = Object.entries(this.outputBlocks[index].outputActionType)[0][1];
            if (outputActionTypeValue === OutputAction.Activate)
            {
              this.outputBlocks[index].displayOutputActionOn = list.filter(x => x.value !== CauseAndEffectOutputActionOn.RemoteLed);
            }
            else
            {
              this.outputBlocks[index].displayOutputActionOn = list;
            }
          }
          else
          {
            this.outputBlocks[index].displayOutputActionOn = list;
          }
        }
      },
        (error: any) => {
          console.log('Error obtaining C&E Output States', error);
        });
    }
  }

  selectOutputSourceDetails(rowNumber: number, isToChange?: boolean) {
    this.selectedOutputBlock = this.outputBlocks[rowNumber];
    this.selectedOutputActionIndex = this.outputBlocks[rowNumber].displayOutputActionType;
    this.selectedRowIndex = rowNumber;
    if (isToChange) {
      this.displayOuputActionForEdit(true);
    }
    switch (this.outputBlocks[rowNumber].outputActionOn) {
      case CauseAndEffectOutputActionOn.AlarmZones:
        this.zoneType = ZoneType.AlarmZones;
        if (!isToChange) {
          this.modalData.selectedZones = [];
          this.modalData.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
          this.modalData.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
          this.dialogService.openDialog(this.addOutputsDialog.key);
        }
        break;
      case CauseAndEffectOutputActionOn.ControlZone:
        this.zoneType = ZoneType.ControlZones;
        if (!isToChange) {
          this.modalData.selectedZones = [];
          this.modalData.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
          this.modalData.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
          this.dialogService.openDialog(this.addOutputsDialog.key);
        }
        break;
      case CauseAndEffectOutputActionOn.DetectionZones:
        this.zoneType = ZoneType.DetectionZones;
        if (!isToChange) {
          this.modalData.selectedZones = [];
          this.modalData.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
          this.modalData.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
          this.dialogService.openDialog(this.addOutputsDialog.key);
        }
        break;
      case CauseAndEffectOutputActionOn.OutputPoints:
      case CauseAndEffectOutputActionOn.ControlOutputPoints:
      case CauseAndEffectOutputActionOn.AlaramOutputPoints:
      case CauseAndEffectOutputActionOn.TransferFlags:
        if (this.isEditMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleOutputsToPoints(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
        } else {
          this.modalDataForPoints.selectedPoints = [];
        }
        this.modalDataForPoints.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
        this.modalDataForPoints.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
        this.dialogService.openDialog(this.addOutputPointsDialog.key);
        break;
      case CauseAndEffectOutputActionOn.RemoteLed:
        if (this.isEditMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleOutputsToPoints(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
        } else {
          this.modalDataForPoints.selectedPoints = [];
        }
        this.dialogService.openDialog(this.addRemoteLedDevicesDialog.key);
        break;
      case CauseAndEffectOutputActionOn.IndicatorLed:
        if (this.isEditMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleOutputsToPoints(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
        } else {
          this.modalDataForPoints.selectedPoints = [];
        }
        this.dialogService.openDialog(this.addIndicatorLedDevicesDialog.key);
        break;
      case CauseAndEffectOutputActionOn.DetectionPoints:
        this.selectedOutputAction = this.outputBlocks[rowNumber].displayOutputActionType;
        if (this.isEditMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleOutputsToPoints(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
          console.log("if", this.modalDataForPoints.selectedPoints);
        } else {
          this.modalDataForPoints.selectedPoints = [];
          console.log("else", this.modalDataForPoints.selectedPoints);
        }
        this.modalDataForPoints.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
        this.modalDataForPoints.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
        this.dialogService.openDialog(this.addDetectionPointsDialog.key);
        break;
      case CauseAndEffectOutputActionOn.ManagedAreas:
        if (this.isEditMode || isToChange) {
          this.modalDataForManagedAreas.selectedAreas =
            this.mapFromRuleOutputsToEntityIDs(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
          this.modalDataForManagedAreas.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
          this.modalDataForManagedAreas.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
        } else {
          this.modalDataForManagedAreas.selectedAreas = [];
          this.modalDataForManagedAreas.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
          this.modalDataForManagedAreas.disablementDuration = { hour: 0, min: 0 };
        }
        this.dialogService.openDialog(this.addAreaDialog.key);
        break;
      case CauseAndEffectOutputActionOn.InputPoints:
        if (this.isEditMode || isToChange) {
          this.modalDataForPoints.selectedPoints = this.mapFromRuleOutputsToPoints(this.outputBlocks[this.selectedRowIndex].outputActionDetails);
        } else {
          this.modalDataForPoints.selectedPoints = [];
        }
        this.modalDataForPoints.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
        this.modalDataForPoints.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
        this.dialogService.openDialog(this.addOutputPointsDialog.key);
        break;
      default:
        break;
    }
    this.ceRuleService.setBlockDetails(this.selectedOutputBlock);
  }

  async getSelectedZoneDetails(zoneDetails: ZoneModalData) {
    const ruleOutputEntities: Array<RuleOutputEntity> = [];
    for (const selectedZone of zoneDetails.selectedZones) {
      if (selectedZone.panelId !== '' && selectedZone.panelId !== '00000000-0000-0000-0000-000000000000') {
        const panel = await this.panelService.getPanelDetails(selectedZone.panelId).toPromise();
        ruleOutputEntities.push({
          outputEntityId: selectedZone.Id,
          outputDetails: `${panel.number}`.padStart(3, '0') + `${'.'}` + `${selectedZone.ZoneID}`
        });
      } else {
        ruleOutputEntities.push({
          outputEntityId: selectedZone.Id,
          outputDetails: selectedZone.ZoneID
        });
      }
    }
    this.outputBlocks[this.selectedRowIndex].outputActionDetails = ruleOutputEntities;
    this.outputBlocks[this.selectedRowIndex].disablementDuration = zoneDetails.disablementDuration;
    this.getoutputActionDetails(this.selectedRowIndex, zoneDetails);
    this.notifyParentOfOutputBlock();
    if (this.outputBlocks[this.selectedRowIndex].outputSelectedZone.length > 0) {
      this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '';
      this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].detectionPointList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '';
    }
  }

  cancelOutputSelection() {
    if (!this.outputBlocks[this.selectedRowIndex].outputSelectedZonesList &&
      !this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList
      && !this.outputBlocks[this.selectedRowIndex].outputPointSelectedList
      && !this.outputBlocks[this.selectedRowIndex].detectionPointList &&
      !this.outputBlocks[this.selectedRowIndex].remoteLedSensorList &&
      !this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList) {
      this.outputBlocks[this.selectedRowIndex].outputActionOn = null;
    }
  }

  getSelectedAreaDetails(areaDetails: AreaModalData) {
    this.outputBlocks[this.selectedRowIndex].outputActionDetails = areaDetails.selectedAreas.map((area) => ({ outputEntityId: area.Id, outputDetails: area.AreaID }));
    this.outputBlocks[this.selectedRowIndex].disablementDuration = areaDetails.disablementDuration;
    this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = ' ( ' + areaDetails.selectedAreas.map((area: any) => area.AreaID).join(', ') + ' )';
    this.notifyParentOfOutputBlock();
    if (this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList.length > 0) {
      this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '';
      this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].detectionPointList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZone = '';
    }
  }

  getSelectRemoteLedSensors(remoteLedConfig: any) {
    this.outputBlocks[this.selectedRowIndex].outputActionDetails =
      remoteLedConfig.selectedSensors.map((sensor: any) => ({
        outputEntityId: sensor.id,
        outputDetails: sensor.address,
        zoneNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.zoneNumber}`.padStart(2, '0'))[0] : '',
        zoneRefNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.deviceReferenceNumber}`.padStart(2, '0'))[0] : ''
      }));
    this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '( ' + this.outputBlocks[this.selectedRowIndex].outputActionDetails.
      map.call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails).toString() + ' )';
    this.notifyParentOfOutputBlock();
    if (this.outputBlocks[this.selectedRowIndex].remoteLedSensorList.length > 0) {
      // clear other points and zones! (FSNCNF-5403)
      this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZone = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZonesList = '';
      this.outputBlocks[this.selectedRowIndex].detectionPointList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '';
    }
  }

  getSelectIndicatorLedSensors(indicatorLedConfig: any) {
    this.outputBlocks[this.selectedRowIndex].outputActionDetails =
      indicatorLedConfig.selectedSensors.map((sensor: any) => ({
        outputEntityId: sensor.id,
        outputDetails: sensor.address,
        zoneNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.zoneNumber}`.padStart(2, '0'))[0] : '',
        zoneRefNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.deviceReferenceNumber}`.padStart(2, '0'))[0] : ''
      }));
    this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '( ' + this.outputBlocks[this.selectedRowIndex].outputActionDetails.
      map.call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails).toString() + ' )';
    this.notifyParentOfOutputBlock();
    if (this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList.length > 0) {
      // clear other points and zones! (FSNCNF-5403)
      this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZone = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZonesList = '';
      this.outputBlocks[this.selectedRowIndex].detectionPointList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '';
      this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '';
    }
  }

  getSelectedDetectionPoints(detectionPointsConfig: any) {
    this.outputBlocks[this.selectedRowIndex].outputActionDetails =
      detectionPointsConfig.selectedSensors.map((sensor: any) => ({
        outputEntityId: sensor.id,
        outputDetails: sensor.address,
        zoneNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.zoneNumber}`.padStart(2, '0'))[0] : '',
        zoneRefNumber: !!sensor.zones ? sensor.zones.map(zone => `${zone.deviceReferenceNumber}`.padStart(2, '0'))[0] : ''
      }));
    this.outputBlocks[this.selectedRowIndex].detectionPointList = '( ' + this.outputBlocks[this.selectedRowIndex].outputActionDetails.
      map.call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
    this.outputBlocks[this.selectedRowIndex].disablementDuration = detectionPointsConfig.disablementDuration;
    this.notifyParentOfOutputBlock();

    if (this.outputBlocks[this.selectedRowIndex].detectionPointList.length > 0) {
      // clear other points and zones! (FSNCNF-5403)
      this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZone = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedZonesList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '';
      this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '';
    }
  }

  getSelectedPointDetails(pointsDetails: PointsModalData) {
    this.outputBlocks[this.selectedRowIndex].outputActionDetails = pointsDetails.selectedPoints.map((outputPoint: InputPoint) => ({
      outputEntityId: outputPoint.pointId,
      outputDetails: outputPoint.address,
      zoneNumber: !!outputPoint.zones ? outputPoint.zones.map(zone => `${zone.zoneNumber}`.padStart(2, '0'))[0] : '',
      zoneRefNumber: !!outputPoint.zones ? outputPoint.zones.map(zone => `${zone.deviceReferenceNumber}`.padStart(2, '0'))[0] : ''
    }));
    this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '( ' +
      this.outputBlocks[this.selectedRowIndex].outputActionDetails.map.call(this.outputBlocks[this.selectedRowIndex].outputActionDetails,
        (s: any) => s.outputDetails + ' ').toString() + ' )';
    this.outputBlocks[this.selectedRowIndex].disablementDuration = pointsDetails.disablementDuration;
    this.notifyParentOfOutputBlock();
    // when going for points, remove zones and vice-versa (FSNCNF-5365)
    if (!!this.outputBlocks[this.selectedRowIndex].outputPointSelectedList
      && this.outputBlocks[this.selectedRowIndex].outputPointSelectedList.length > 0) {
      this.outputBlocks[this.selectedRowIndex].outputSelectedZonesList = '';
      this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '';
      this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '';
      this.outputBlocks[this.selectedRowIndex].detectionPointList = '';
    }
  }

  private mapFromRuleOutputsToPoints(outputDetails: RuleOutputEntity[]): InputPoint[] {
    let inputPoints: InputPoint[] = [];
    if (outputDetails !== null && outputDetails !== undefined) {
      inputPoints = outputDetails.map((outputEntity) => ({
        pointId: outputEntity.outputEntityId,
        address: outputEntity.outputDetails,
        checked: true,
        label: 'duno',
        $deviceType: 'some... module I guess(?)',
        zones: [{
          deviceReferenceNumber: outputEntity.zoneRefNumber,
          zoneId: '',
          zoneNumber: outputEntity.zoneNumber
        }]
      }));
    }
    return inputPoints;
  }

  private mapFromRuleOutputsToEntityIDs(outputDetails: RuleOutputEntity[]): string[] {
    let entityIDs: string[] = [];
    if (outputDetails !== null && outputDetails !== undefined) {
      entityIDs = outputDetails.map((outputEntity) => outputEntity.outputEntityId);
    }
    return entityIDs;
  }

  private mapFromRuleOutputsToEntityDetails(outputDetails: RuleOutputEntity[]): string[] {
    const entityDetails: string[] = outputDetails.map((outputEntity) => outputEntity.outputDetails);
    return entityDetails;
  }

  private displayOuputActionForEdit(isShowPopup: boolean = false) {
    switch (this.outputBlocks[this.selectedRowIndex].outputActionOn) {
      case CauseAndEffectOutputActionOn.AlarmZones:
        this.zoneType = ZoneType.AlarmZones;
        this.getZonesForSite(this.selectedRowIndex, this.zoneType, isShowPopup);
        break;
      case CauseAndEffectOutputActionOn.ControlZone:
        this.zoneType = ZoneType.ControlZones;
        this.getZonesForSite(this.selectedRowIndex, this.zoneType, isShowPopup);
        break;
      case CauseAndEffectOutputActionOn.OutputPoints:
      case CauseAndEffectOutputActionOn.TransferFlags:
        this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      case CauseAndEffectOutputActionOn.RemoteLed:
        this.outputBlocks[this.selectedRowIndex].remoteLedSensorList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      case CauseAndEffectOutputActionOn.IndicatorLed:
        this.outputBlocks[this.selectedRowIndex].indicatorLedSensorList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      case CauseAndEffectOutputActionOn.DetectionZones:
        this.zoneType = ZoneType.DetectionZones;
        this.getZonesForSite(this.selectedRowIndex, this.zoneType, isShowPopup);
        break;
      case CauseAndEffectOutputActionOn.ManagedAreas:
        this.outputBlocks[this.selectedRowIndex].outputSelectedAreaList = '( ' +
          this.mapFromRuleOutputsToEntityDetails(this.outputBlocks[this.selectedRowIndex].outputActionDetails).join(',') + ' )';
        break;
      case CauseAndEffectOutputActionOn.InputPoints:
        this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      case CauseAndEffectOutputActionOn.DetectionPoints:
        this.outputBlocks[this.selectedRowIndex].detectionPointList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      case CauseAndEffectOutputActionOn.AlaramOutputPoints:
      case CauseAndEffectOutputActionOn.ControlOutputPoints:
        this.outputBlocks[this.selectedRowIndex].outputPointSelectedList = '( '
          + this.outputBlocks[this.selectedRowIndex].outputActionDetails.map
            .call(this.outputBlocks[this.selectedRowIndex].outputActionDetails, (s: any) => s.outputDetails + ' ').toString() + ' )';
        break;
      default:
        break;
    }
  }

  getoutputActionDetails(rowNumber: number, zoneDetails: ZoneModalData) {
    const zoneOutputIds = this.outputBlocks[rowNumber].outputActionDetails.map((outputActionDetail: any) => outputActionDetail.outputDetails);
    this.outputBlocks[rowNumber].outputSelectedZone = this.translate.instant(this.ceEnums.outputActionOnShort.get(this.outputBlocks[rowNumber].outputActionOn));
    this.outputBlocks[rowNumber].outputSelectedZonesList = ': ( ' + zoneOutputIds.join(' , ') + ' )';
  }

  deleteBlock(index: number) {
    this.outputBlocks.splice(index, 1);
    this.notifyParentOfOutputBlock();
  }

  private notifyParentOfOutputBlock() {
    this.outputBlocksAvailable.emit(this.outputBlocks as OutputBlock[]);
  }

  private setUpEditWindow() {
    for (let rowNum = 0; rowNum < this.outputBlocks.length; rowNum++) {
      this.selectedRowIndex = rowNum;
      this.outputBlocks[this.selectedRowIndex].displayOutputActionType = (Object.entries(this.outputBlocks[this.selectedRowIndex].outputActionType))[0][1];
      this.displayOuputActionForEdit();
    }
  }

  private getZonesForSite(rowNumber: number, zoneType: ZoneType, isShowPopup: boolean = false) {
    // using local variable here as the selectedRowIndex value gets messed up in editMode due to the
    // async api call
    this.zonesService.getZonesForSiteCAE(zoneType, this.selectedSiteID, 0, 0).subscribe(async (zonePage: PaginationResult<Zone>) => {
      const allZones = zonePage.payload;
      const zoneDetails = new ZoneModalData();
      zoneDetails.selectedZones = allZones.filter(z => {
        return (this.outputBlocks[rowNumber].outputActionDetails.findIndex(s => s.outputEntityId === z.id) >= 0);
      });
      zoneDetails.selectedZones.forEach(z => {
        z['Id'] = z.id;
        z['ZoneID'] = `000${z.zoneNumber}`.slice(-6).toString();
        z['ZoneLabel'] = z.label;
        z['panelId'] = z.panelId === null ? '' : z.panelId;
      });
      await this.applyPanelPrefixToOutputDetails(rowNumber, zoneDetails.selectedZones);
      this.modalData.selectedZones = zoneDetails.selectedZones;
      zoneDetails.operand = this.outputBlocks[rowNumber].outputOperand;
      this.getoutputActionDetails(rowNumber, zoneDetails);
      this.modalData.displayOutputActionType = this.outputBlocks[this.selectedRowIndex].displayOutputActionType;
      this.modalData.disablementDuration = this.outputBlocks[this.selectedRowIndex].disablementDuration;
      if (isShowPopup) {
        this.dialogService.openDialog(this.addOutputsDialog.key);
      }
    }, (error: any) => {
      console.log('error fetching zones');
    });
  }

  /**
   * Reconstructs the panel-prefixed details (panelNo.zoneNo) for local zones on edit reload,
   * so the persisted bare zone numbers are displayed and re-saved with the panel prefix.
   */
  private async applyPanelPrefixToOutputDetails(rowNumber: number, selectedZones: any[]) {
    for (const detail of this.outputBlocks[rowNumber].outputActionDetails) {
      const matchedZone = selectedZones.find(z => z['Id'] === detail.outputEntityId);
      if (matchedZone && matchedZone['panelId'] !== '' && matchedZone['panelId'] !== '00000000-0000-0000-0000-000000000000'
        && !`${detail.outputDetails}`.includes('.')) {
        const panel = await this.panelService.getPanelDetails(matchedZone['panelId']).toPromise();
        detail.outputDetails = `${panel.number}`.padStart(3, '0') + '.' + detail.outputDetails;
      }
    }
  }

  private clearAllPreviousOutputSelections(index: number) {
    this.outputBlocks[index].outputActionOn = null;
    this.outputBlocks[index].detectionPointList = '';
    this.outputBlocks[index].outputPointSelectedList = '';
    this.outputBlocks[index].outputSelectedZone = '';
    this.outputBlocks[index].outputSelectedZonesList = '';
    this.outputBlocks[index].outputSelectedAreaList = '';
    this.outputBlocks[index].outputActionDetails = null;
    this.outputBlocks[index].remoteLedSensorList = '';
    this.outputBlocks[index].indicatorLedSensorList = '';
  }

  enableTemporaryDisablement(outputActionType: { [key: number]: string }, disablementDuration: DisablementDuration) {
    if (disablementDuration === null || disablementDuration === undefined) {
      return false;
    }
    let outputActionTypeValue = outputActionType !== null && outputActionType !== undefined ? Object.entries(outputActionType)[0][1] : '';
    return disablementDuration.hour !== 0 ||
      disablementDuration.min !== 0 &&
      (outputActionTypeValue === OutputAction.Disablements ||
        outputActionTypeValue === OutputAction.DisablementOfControlOuputs ||
        outputActionTypeValue === OutputAction.DisablementOfAlarmDevices ||
        outputActionTypeValue === OutputAction.DisablementOfFireProtection ||
        outputActionTypeValue === OutputAction.DisablementOfFaultRouting ||
        outputActionTypeValue === OutputAction.DisablementOfFireAlarmRouting);
  }

  private hasOnlyActivationInputs() {
    const inputBlocks = this.ceRule?.inputBlock ?? [];

    return inputBlocks.length > 0 && inputBlocks.every(inputBlock => inputBlock?.inputType === null
      || (inputBlock?.inputType === InputCondition.Activation));
  }

  private hasOnlyCalendarInputs() {
    const inputBlocks = this.ceRule?.inputBlock ?? [];

    return inputBlocks.length > 0 && inputBlocks.every(inputBlock => inputBlock?.inputType === null
      || (inputBlock?.inputType === InputCondition.Calendar));
  }

  clearOutputBlocksForUnsupportedOutputActions() {
    let hasChanges = false;
    if (!this.hasOnlyActivationInputs()) {
      let clearedOutputBlocks: OutputBlockDisplay[] = [];
      this.outputBlocks.forEach((outputBlock, index) => {
        const selectedAction = outputBlock?.displayOutputActionType
          || (outputBlock?.outputActionType ? Object.entries(outputBlock.outputActionType)[0]?.[1] : null);
        let isActivationOnlyOutputAction = activationOnlyOutputActions.includes(selectedAction as OutputAction);
        if (isActivationOnlyOutputAction) {
          clearedOutputBlocks.push(outputBlock);
          this.clearAllPreviousOutputSelections(index);
          this.outputBlocks[index].displayOutputActionOn = [];
          this.outputBlocks[index].displayOutputActionType = null;
          this.outputBlocks[index].outputActionType = null;
          this.outputBlocks[index].displayOutputActionOn = [];
          this.outputBlocks[index].disablementDuration = { hour: 0, min: 0 };
          hasChanges = true;
        }
      });
      let outputBlockCount = this.outputBlocks.length;
      let clearedOutputBlockCount = clearedOutputBlocks.length;
      if (outputBlockCount === clearedOutputBlockCount) {
        clearedOutputBlocks = clearedOutputBlocks.slice(1);
      }
      if (clearedOutputBlocks.length > 0) {
        this.outputBlocks = this.outputBlocks.filter(outputBlock => !clearedOutputBlocks.includes(outputBlock));
      }
    }

    if (hasChanges) {
      this.notifyParentOfOutputBlock();
    }
  }

  /** Max items listed in the "Output at" field before collapsing to "+N more" (design frame 5). */
  private static readonly SUMMARY_MAX_ITEMS = 5;

  private outputSelectionRaw(block: any): any {
    return block.outputSelectedZonesList || block.outputSelectedAreaList || block.outputPointSelectedList ||
      block.detectionPointList || block.remoteLedSensorList || block.indicatorLedSensorList || '';
  }

  /** True once a zone/area/point/device selection exists for the output block. */
  hasOutputSelection(block: any): boolean {
    return !!this.outputSelectionRaw(block);
  }

  /** Text for the "Output at" field: first N items plus "+N more". */
  getOutputAtSummary(block: any): { text: string; full: string } {
    const raw = this.outputSelectionRaw(block);
    const items: string[] = (Array.isArray(raw) ? raw : String(raw).split(','))
      .map((x: any) => String(x).trim()).filter((x: string) => x.length > 0);
    const max = CauseAndEffectOutputComponent.SUMMARY_MAX_ITEMS;
    const shown = items.slice(0, max).join(', ');
    const extra = items.length - max;
    return {
      text: extra > 0 ? `${shown}, ${this.translate.instant('ce.design.more', { count: extra })}` : shown,
      full: items.join(', ')
    };
  }
}
