# C&E redesign: README

## What was built
The C&E feature already existed (`src/app/modules/cause-and-effect`), so it was **restyled and extended, not duplicated**. No `.ts` business logic, services, API classes or backend calls were changed.

- **Rules list (design frame 1):** new header (title, "One in all out" checkbox, search, filter, "+ Rule"); ag-Grid columns Rule ID / Rule Name (blue link -> editor) / Activating duration / Delay / Last updated / kebab (Edit, Duplicate, Delete); custom pager ("1-10 records of 28", ‹ 1 2 3 … 6 ›).
- **Rule editor (frames 2, 4, 5):** full-page view with back arrow, editable rule name, Inputs card and Outputs card; rows with NOT toggle, On / Action selects, "Input at / Output at" summary field with edit pencil, delete button; OR connector pill; "+N more" truncation; add input / add output / add delay buttons.
- **Add Zone dialog (frame 3):** NOT restyled yet. The existing dialogs (`add-inputs`, `add-outputs`, ...) are untouched and still work.

## Routes
Unchanged: `sites/.../causeandeffect/rules` (lazy-loaded, `UnsavedChangesGuard`).

## Files
New: `component/ce-rule-actions-cellrenderer/*`, `component/ce-rules-pagination/*`, `styles/_ce-design.scss`, `src/assets/images/icons/ce/*.png` (13 icons x 4 tints, cut from your Icon.png sheet).
Modified (all inside the C&E module unless noted): `cause-and-effect.module.ts`; list-view ts/html/scss; rules-header ts/html/scss (additive outputs `searchChange`, `filterToggle`); addnewrule html/scss; newruleheader html/scss; input html/scss + ts (additive helpers `hasInputSelection`, `getInputAtSummary`); output html/scss + ts (additive helpers); **`src/assets/i18n/en.json`** (outside module: 36 keys `ce.design.*`).
No shared components were modified.

## Icons used (indices in Icon.png, 20 columns, 36px pitch)
search 1165, trash 1399, timer 1382, pencil 1018, plus 1058, filter 589, kebab 512, chevron-down 301, chevron-left 304, chevron-right 305, OR-repeat 1107 (closest match to the design's connector glyph). Blue/red/white variants are recolours of the same glyph. Sort arrows (313) were exported but the grid still uses ag-Grid's built-in sort icons.

## Verification (what was and was not run)
- `npm install --ignore-scripts` (Electron/Puppeteer skipped): OK.
- `npx ngc -p src/tsconfig.app.json --noEmit` (full AOT template + type check): **0 errors**. A deliberately broken template was injected as a canary and was caught, then reverted.
- To get there in the sandbox I needed two things that are NOT part of the deliverable: a stub for `projects/battery-calculator/.../cable-type` (the repo zip lacks the `/projects` folder) and `useDefineForClassFields:false` + `downlevelIteration` in `src/tsconfig.app.json` (ngc run standalone doesn't get the Angular CLI's defaults). Do not copy those.
- **`npx ng build` was NOT completed:** webpack ran out of memory on the 3 GB sandbox (heap OOM, then killed). Please run `ng build` on your machine.
- **Visual check NOT done:** no backend is available and I did not build mock data, so there is no pixel comparison. Treat spacing/colours as unverified; tokens were sampled from the design in `styles/_ce-design.scss`.
- Existing specs were not run. `ce-rules-list-view` and header specs may need updating for the new columns and header.

## Gaps and assumptions
1. **Last updated:** `CERule` has no such field and no endpoint returns it. The column shows "—" (reads `lastUpdated` if the API ever adds it).
2. **Time pulse / add delay:** both open the existing delay dialog (assumption).
3. **Removed list columns:** logic gate, input and output columns are no longer in the list because the design omits them (still visible in the editor).
4. **Filter button:** toggles ag-Grid floating filters (assumption). Search is a quick filter.
5. **Add Zone dialog restyle and its "and" operator select** not done; the existing dialogs keep the old look.
6. **Save/Cancel + hint footer** kept in the editor although the design omits them (needed to save).
7. **Delete row:** disabled on the last remaining row.
8. **Other languages:** only `en.json` received the new keys.
9. **Site shell** (top bar, site bar, left rail) assumed existing and untouched.
10. Design copy: "Fare pulse" read as "Time pulse".
11. Frame 1 shows 8 rows but "1-10 of 28": treated as placeholder data.
