import { ZoneType } from '../../zones/model/zone-type';

/**
 * View-model for a single device card (frames 8-13).
 *
 * NOTE: the existing modules/zones/model/zone-io-grid-view.ts (ZoneIoGridView)
 * has no "added on" timestamp field, which the Figma cards display
 * prominently ("Added on 03:54 PM, 09/16/2026"). Since the backend isn't
 * changing, confirm with the API owner whether GetIoPoints (or equivalent)
 * already returns a createdOn/addedOn field that just isn't mapped into
 * ZoneIoGridView yet, or whether this is a genuinely new display requirement
 * with no backing data - in the latter case this field will need to be
 * either sourced elsewhere or dropped from the design.
 */
export interface DeviceCardViewModel {
  pointId: string;
  panelId: string;
  loopId: string;
  deviceId: string;
  label: string;
  type: ZoneType;
  addedOn: string | null;
  selected: boolean;
}
