import { ZoneType } from '../../zones/model/zone-type';

/**
 * One row of the "Areas" tab table (Figma frame 1).
 * Maps onto the existing Area model plus rollup counts joined in client-side
 * from buildings/zones/devices already held in the store - there is no
 * dedicated "area summary" endpoint on the backend.
 */
export interface AreaRow {
  id: string;
  areaName: string;
  buildingId: string;
  buildingName: string;
  zoneCount: number;
  panelCount: number;
  deviceCount: number;
  lastUpdated: string | null;
}

/**
 * One row of the "Zones" tab table (Figma frame 2).
 *
 * IMPORTANT: the backend has three separate physical entities - Alarm,
 * Control and Detection zones - each with its own Add/Get/Delete endpoints
 * (see core/api/serviceurl.ts). This row is a UI-level merge of up to three
 * physical zone records that share the same zoneNumber + label, grouped
 * client-side. See the dev guide (section 3) for the full rationale.
 * `sourceZones` keeps the original per-type record ids so edit/delete can
 * still target the correct underlying API calls.
 */
export interface ZoneRow {
  /** Composite key used for table tracking: `${zoneNumber}__${label}` */
  rowKey: string;
  zoneNumber: number;
  label: string;
  types: ZoneType[];
  buildingId: string;
  buildingName: string;
  areaId: string;
  areaName: string;
  deviceCount: number;
  lastUpdated: string | null;
  isLegacyZone?: boolean;
  sourceZones: Partial<Record<ZoneType, { id: string; panelId?: string }>>;
}

export type AreasZonesTab = 'areas' | 'zones';
