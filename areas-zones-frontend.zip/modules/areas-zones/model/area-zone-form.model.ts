import { ZoneType } from '../../zones/model/zone-type';

/** One row inside the "New Area" dialog's repeatable ("+ Add more") form (frames 3-4) */
export interface NewAreaFormRow {
  areaName: string;
  buildingId: string;
}

/** "New Zone" dialog form shape (frames 5-6) */
export interface NewZoneFormValue {
  zoneName: string;
  buildingId: string;
  /** Area select supports either picking an existing area or typing a new one - see Figma helper text */
  areaId: string | null;
  areaNameIfNew: string | null;
  /** raw text as typed, e.g. "5" or "1-10" - parsed by parseZoneNumberRange() below */
  zoneNumberRange: string;
  zoneTypes: ZoneType[];
  isLegacyZone: boolean;
}

export interface ParsedZoneRange {
  start: number;
  end: number;
  valid: boolean;
}

/**
 * Parses the "Zone number" field which accepts either a single number ("5")
 * or an inclusive range ("1-10"), per the Figma helper text on frame 5.
 * Mirrors the validation shown in frame 6 ("Invalid range entered").
 */
export function parseZoneNumberRange(raw: string): ParsedZoneRange {
  const trimmed = (raw || '').trim();
  const singleMatch = /^(\d+)$/.exec(trimmed);
  if (singleMatch) {
    const n = parseInt(singleMatch[1], 10);
    return { start: n, end: n, valid: n > 0 };
  }
  const rangeMatch = /^(\d+)\s*-\s*(\d+)$/.exec(trimmed);
  if (rangeMatch) {
    const start = parseInt(rangeMatch[1], 10);
    const end = parseInt(rangeMatch[2], 10);
    return { start, end, valid: start > 0 && end > start };
  }
  return { start: NaN, end: NaN, valid: false };
}

export function expandZoneNumberRange(range: ParsedZoneRange): number[] {
  if (!range.valid) {
    return [];
  }
  const numbers: number[] = [];
  for (let n = range.start; n <= range.end; n++) {
    numbers.push(n);
  }
  return numbers;
}
