import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { SharedModule } from '../../shared/shared.module';

import { AlarmZonesApiService } from '../zones/api/alarm-zones-api.service';
import { ControlZonesApiService } from '../zones/api/control-zones-api.service';
import { DetectionZonesApiService } from '../zones/api/detection-zones-api.service';
import { AlarmZoneOutputsApiService } from '../zones/api/alarm-zone-outputs-api.service';
import { ControlZoneInputsOutputsApiService } from '../zones/api/control-zone-inputs-outputs-api.service';
import { DetectionZoneInputsApiService } from '../zones/api/detection-zone-inputs-api.service';
import { AlarmZonesService } from '../zones/services/alarm-zones.service';
import { ControlZonesService } from '../zones/services/control-zones.service';
import { DetectionZonesService } from '../zones/services/detection-zones.service';
import { CommonZoneInputsOutputsService } from '../zones/services/common-zone-inputs-outputs.service';
import { AlarmZoneOutputsService } from '../zones/services/alarm-zone-outputs.service';
import { ControlZoneInputsOutputsService } from '../zones/services/control-zone-inputs-outputs.service';
import { DetectionZoneInputsService } from '../zones/services/detection-zone-inputs.service';

import { AreasZonesRoutingModule } from './areas-zones-routing.module';
import { areaZoneListReducer } from './state/area-zone-list/area-zone-list.reducer';
import { AreaZoneListEffects } from './state/area-zone-list/area-zone-list.effects';

import { AreasZonesShellComponent } from './components/areas-zones-shell/areas-zones-shell.component';
import { AreaZoneTableComponent } from './components/area-zone-table/area-zone-table.component';
import { NewAreaDialogComponent } from './components/new-area-dialog/new-area-dialog.component';
import { NewZoneDialogComponent } from './components/new-zone-dialog/new-zone-dialog.component';
import { ZoneTypeBadgeComponent } from './components/zone-type-badge/zone-type-badge.component';
import { ZoneDetailsComponent } from './components/zone-details/zone-details.component';
import { ZoneDeviceCardComponent } from './components/zone-device-card/zone-device-card.component';
import { DeviceListPanelComponent } from './components/device-list-panel/device-list-panel.component';

/**
 * PROVIDERS NOTE: AlarmZonesService/ControlZonesService/DetectionZonesService
 * and their dependencies (below) live under modules/zones/services, i.e.
 * they are provided within ZonesModule's own `providers` array, not
 * `providedIn: 'root'`. Since AreasZonesModule is a separate lazy-loaded
 * module, these need to be re-provided here too - a service provided only
 * inside one lazy module's injector isn't visible to a sibling lazy module.
 * Re-providing a plain (non-root) service in two modules is harmless (each
 * gets its own instance; these are stateless API wrappers), but if ZonesModule
 * changes any of these to `providedIn: 'root'` in the future this whole list
 * becomes redundant and can be deleted.
 *
 * AreasApiService/AreasService/BuildingsService are NOT re-provided here on
 * the assumption that, living under core/, they're already provided at the
 * root/AppModule level and therefore already app-wide - confirm this
 * assumption holds before relying on it; if it doesn't, add them here too.
 */
@NgModule({
  declarations: [
    AreasZonesShellComponent,
    AreaZoneTableComponent,
    NewAreaDialogComponent,
    NewZoneDialogComponent,
    ZoneTypeBadgeComponent,
    ZoneDetailsComponent,
    ZoneDeviceCardComponent,
    DeviceListPanelComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatSelectModule,
    DragDropModule,
    SharedModule,
    AreasZonesRoutingModule,
    StoreModule.forFeature('areaZoneList', areaZoneListReducer),
    EffectsModule.forFeature([AreaZoneListEffects])
  ],
  providers: [
    AlarmZonesApiService,
    ControlZonesApiService,
    DetectionZonesApiService,
    AlarmZoneOutputsApiService,
    ControlZoneInputsOutputsApiService,
    DetectionZoneInputsApiService,
    AlarmZonesService,
    ControlZonesService,
    DetectionZonesService,
    AlarmZoneOutputsService,
    ControlZoneInputsOutputsService,
    DetectionZoneInputsService,
    CommonZoneInputsOutputsService
  ]
})
export class AreasZonesModule { }
