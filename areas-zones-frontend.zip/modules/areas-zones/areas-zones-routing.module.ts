import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../shared/auth/auth-guard/auth.guard';
import { AreasZonesShellComponent } from './components/areas-zones-shell/areas-zones-shell.component';
import { AreaZoneTableComponent } from './components/area-zone-table/area-zone-table.component';
import { ZoneDetailsComponent } from './components/zone-details/zone-details.component';

/**
 * NOTE: modules/zones/components/zone-details already has an (unrelated,
 * legacy) ZoneDetailsComponent of its own. There is no naming collision at
 * compile time since the two live in different modules and are never
 * imported together, but flagging this for whoever reviews the PR since it's
 * a likely source of "which ZoneDetailsComponent?" confusion during review
 * and when navigating the file tree.
 *
 * All three child routes are nested under the same shell rather than pulling
 * zone-details out as a sibling top-level route: 'zones' and 'zones/:zoneId'
 * are distinct path templates Angular's router disambiguates cleanly as
 * sibling *children* of one parent, whereas splitting them across two
 * different levels of the routes array risks a subtle prefix-matching bug
 * (a child path of 'zones' can match as a *prefix* of 'zones/:zoneId'
 * without `pathMatch: 'full'`, swallowing the request before it ever reaches
 * a same-array-level sibling route). Keeping them as siblings under one
 * parent avoids relying on route declaration order or prefix-matching
 * subtleties entirely.
 *
 * `mode` in route data drives AreaZoneTableComponent's column config (see
 * dev guide §4/§5.2) instead of duplicating tab state into NgRx.
 *
 * AreasZonesShellComponent hides its Areas/Zones toggle when the active
 * child is zone-details (frames 8-9 have their own full-width layout with no
 * visible tab toggle) - see the shell component for the route-based check.
 */
const routes: Routes = [
  {
    path: '', component: AreasZonesShellComponent, canActivate: [AuthGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'areas' },
      { path: 'areas', component: AreaZoneTableComponent, canActivate: [AuthGuard], data: { mode: 'areas' } },
      { path: 'zones', component: AreaZoneTableComponent, canActivate: [AuthGuard], data: { mode: 'zones' } },
      { path: 'zones/:zoneId', component: ZoneDetailsComponent, canActivate: [AuthGuard] }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AreasZonesRoutingModule { }
