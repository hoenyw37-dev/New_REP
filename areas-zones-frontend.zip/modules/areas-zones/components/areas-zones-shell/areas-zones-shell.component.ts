import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map, startWith } from 'rxjs/operators';
import { LinkButton } from '../../../../shared/models/link-button';

/**
 * Frames 1-2 shell: "Areas & Zones" heading, Areas/Zones toggle, and the
 * "Generate report" / "Config actions" buttons top-right. Hosts a
 * <router-outlet> for the active child route (see areas-zones-routing.module.ts)
 * - matching how shared/components/nav-tabs is driven elsewhere in the app
 * (routerLink-based, not store-based), so the active tab is derived from the
 * URL rather than duplicated into NgRx state.
 *
 * The heading/toggle/topbar are hidden on the zone-details route (frames 8-9
 * have their own full-width layout with no visible tab toggle) via a simple
 * check on the current URL rather than a second shell component, since the
 * only actual difference is these header elements.
 *
 * "Generate report" / "Config actions" menu contents aren't shown expanded in
 * any Figma frame - wired here as stubs (see dev guide, open question 5)
 * pending that spec.
 */
@Component({
  selector: 'app-areas-zones-shell',
  templateUrl: './areas-zones-shell.component.html',
  styleUrls: ['./areas-zones-shell.component.scss']
})
export class AreasZonesShellComponent {

  tabs: LinkButton[] = [
    { label: 'areasZones.tabs.areas', url: ['areas'] },
    { label: 'areasZones.tabs.zones', url: ['zones'] }
  ];

  showTabsAndHeading$: Observable<boolean>;

  constructor(private router: Router) {
    this.showTabsAndHeading$ = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd),
      startWith(null),
      map(() => !/\/zones\/[^/]+$/.test(this.router.url))
    );
  }

  onGenerateReport() {
    // Report type/format menu not specified in the Figma export - stub only.
  }

  onConfigActions() {
    // Menu items not specified in the Figma export - stub only.
  }
}
