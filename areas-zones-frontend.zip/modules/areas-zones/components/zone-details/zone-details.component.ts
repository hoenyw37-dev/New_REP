import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { forkJoin, Observable } from 'rxjs';
import { map, take, takeUntil } from 'rxjs/operators';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { ZoneIo } from '../../../../model/zoneIo';
import { ZoneType } from '../../../zones/model/zone-type';
import { CommonZoneInputsOutputsService } from '../../../zones/services/common-zone-inputs-outputs.service';
import { PopOutType } from '../../../../shared/models/pop-out-type.enum';
import { RemoveZoneDevices } from '../../../zones/state/zone-devices/zone-devices.actions';
import { DeviceCardViewModel } from '../../model/device-card-view.model';
import { ZoneRow } from '../../model/area-zone-row.model';
import { getZoneRows } from '../../state/area-zone-list';

/**
 * Frames 8-9: Zone Details device browse/selection screen.
 *
 * IMPORTANT: a merged ZoneRow (see dev guide §3) can span up to three
 * physical zone records (one per type). The existing zone-devices NgRx slice
 * (modules/zones/state/zone-devices) uses switchMap on LoadZoneDevices,
 * which would cancel an in-flight request if a second type's load were
 * dispatched right after - unsafe for loading multiple types at once. This
 * component therefore calls CommonZoneInputsOutputsService.getIoPoints()
 * directly via forkJoin (one call per type in the row) for the read side,
 * and only uses the shared NgRx actions for writes (Add/RemoveZoneDevices),
 * since those effects use mergeMap and are safe for concurrent dispatch.
 *
 * "Type" shown per device card (frames 8-9 badges) comes from each ZoneIo's
 * own type/category field - the exact mapping from ZoneIo.pointType /
 * .function to the Alarm/Control/Detection label shown in the Figma isn't
 * specified anywhere in the model layer reviewed, so `mapDeviceType()` below
 * is a placeholder that needs confirming against real API responses before
 * this ships.
 */
@Component({
  selector: 'app-zone-details',
  templateUrl: './zone-details.component.html',
  styleUrls: ['./zone-details.component.scss']
})
export class ZoneDetailsComponent extends UnsubscribeDirective implements OnInit {

  popOutType = PopOutType;
  zoneRow: ZoneRow;
  devices: DeviceCardViewModel[] = [];
  loading = true;
  siteId = '';

  get alreadyAssignedPointIds(): string[] {
    return this.devices.map(d => d.pointId);
  }

  get selectedDevices(): DeviceCardViewModel[] {
    return this.devices.filter(d => d.selected);
  }

  get selectedCount(): number {
    return this.selectedDevices.length;
  }

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private store: Store,
    private ioService: CommonZoneInputsOutputsService
  ) {
    super();
  }

  ngOnInit() {
    const rowKey = this.route.snapshot.paramMap.get('zoneId');
    this.siteId = this.route.snapshot.paramMap.get('siteId') || '';

    this.store.select(getZoneRows).pipe(take(1), takeUntil(this.ngUnsubscribe$)).subscribe(rows => {
      this.zoneRow = rows.find(r => r.rowKey === rowKey);
      if (!this.zoneRow) {
        return; // row not found in store (e.g. deep link / refresh) - load path TODO
      }
      this.loadDevices(this.siteId);
    });
  }

  loadDevices(siteId: string) {
    this.loading = true;
    const types = Object.keys(this.zoneRow.sourceZones) as ZoneType[];

    const calls: Observable<{ type: ZoneType; devices: ZoneIo[] }>[] = types.map(type => {
      const source = this.zoneRow.sourceZones[type];
      return this.ioService.getIoPoints(type, source.id, siteId).pipe(
        map(devices => ({ type, devices }))
      );
    });

    forkJoin(calls).pipe(takeUntil(this.ngUnsubscribe$)).subscribe(results => {
      this.devices = results.flatMap(({ type, devices }) =>
        devices.map(io => this.toCardViewModel(io, type))
      );
      this.loading = false;
    });
  }

  goBack() {
    this.router.navigate(['../zones'], { relativeTo: this.route });
  }

  onCardSelect(device: DeviceCardViewModel) {
    device.selected = !device.selected;
  }

  clearSelection() {
    this.devices.forEach(d => d.selected = false);
  }

  selectAll() {
    this.devices.forEach(d => d.selected = true);
  }

  removeFromZone() {
    // NOTE: Figma doesn't show a confirmation step here, but this is a
    // destructive bulk action and the app's established pattern elsewhere
    // (shared/components/delete-dialog) confirms before deleting - flag with
    // design/PM (dev guide §5.5) before deciding whether to skip it here.
    const siteId = this.route.snapshot.paramMap.get('siteId') || '';
    const byType = new Map<ZoneType, ZoneIo[]>();

    for (const device of this.selectedDevices) {
      const io: ZoneIo = { pointId: device.pointId, panelId: device.panelId, loopId: device.loopId, deviceId: device.deviceId } as ZoneIo;
      const list = byType.get(device.type) ?? [];
      list.push(io);
      byType.set(device.type, list);
    }

    byType.forEach((ioDevices, type) => {
      const zoneId = this.zoneRow.sourceZones[type].id;
      this.store.dispatch(new RemoveZoneDevices({ zoneType: type, zoneId, siteId, devices: ioDevices }));
    });

    this.devices = this.devices.filter(d => !d.selected);
  }

  private toCardViewModel(io: ZoneIo, type: ZoneType): DeviceCardViewModel {
    return {
      pointId: io.pointId,
      panelId: io.panelId,
      loopId: io.loopId,
      deviceId: io.deviceId,
      label: io.label,
      type, // see class-level comment: placeholder until confirmed against real API data
      addedOn: null, // see DeviceCardViewModel comment - no backing field identified yet
      selected: false
    };
  }
}
