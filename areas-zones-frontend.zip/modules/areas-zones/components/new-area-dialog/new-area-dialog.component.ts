import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';
import { finalize, map, takeUntil } from 'rxjs/operators';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { Area } from '../../../../model/area';
import { Building } from '../../../../model/building';
import { AreasApiService } from '../../../../core/api/areas-api.service';
import { BuildingsService } from '../../../../core/services/buildings.service';
import { Store } from '@ngrx/store';
import { LoadAreaRows } from '../../state/area-zone-list';
import { ActivatedRoute } from '@angular/router';

/**
 * "New Area" dialog (frames 3-4). Uses a FormArray so "+ Add more" (frame 4)
 * can repeat the Area Name + Building pair, each with its own delete icon.
 *
 * NOTE: AreasService.addArea() (the existing orchestration-layer service)
 * pulls buildingId from the currently-selected-building store selector and
 * doesn't accept a per-call buildingId, which doesn't fit this dialog where
 * each row can pick its own building. This component calls
 * AreasApiService.addArea() directly instead and dispatches the store reload
 * itself - flagging this as a deliberate deviation from the usual
 * service-layer indirection, for the same reason.
 *
 * The Figma has no "Area number" field - GetNextFreeAreaNumber is called per
 * row immediately before POSTing, mirroring how the legacy area-creation
 * flow auto-assigns this value server-side.
 */
@Component({
  selector: 'app-new-area-dialog',
  templateUrl: './new-area-dialog.component.html',
  styleUrls: ['./new-area-dialog.component.scss']
})
export class NewAreaDialogComponent extends UnsubscribeDirective implements OnInit {

  form: FormGroup;
  buildings: Building[] = [];
  saving = false;

  get rows(): FormArray {
    return this.form.get('rows') as FormArray;
  }

  constructor(
    private fb: FormBuilder,
    private dialogService: DialogService,
    private areasApiService: AreasApiService,
    private buildingsService: BuildingsService,
    private store: Store,
    private route: ActivatedRoute
  ) {
    super();
  }

  ngOnInit() {
    this.form = this.fb.group({ rows: this.fb.array([this.buildRow()]) });

    const siteId = this.route.snapshot.paramMap.get('siteId') || '';
    this.buildingsService.getBuildings(siteId).pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe(buildings => this.buildings = buildings);
  }

  buildRow(): FormGroup {
    return this.fb.group({
      areaName: ['', Validators.required],
      buildingId: ['', Validators.required]
    });
  }

  addRow() {
    this.rows.push(this.buildRow());
  }

  removeRow(index: number) {
    this.rows.removeAt(index);
  }

  cancel() {
    this.resetForm();
    this.dialogService.closeDialog(DialogKeys.ADD_NEW_AREA);
  }

  save() {
    if (this.form.invalid || this.saving) {
      this.form.markAllAsTouched();
      return;
    }
    const siteId = this.route.snapshot.paramMap.get('siteId') || '';
    this.saving = true;

    const creates: Observable<Area>[] = this.rows.controls.map(row =>
      this.areasApiService.getAreaNumber(siteId).pipe(
        map(number => ({ label: row.value.areaName, buildingId: row.value.buildingId, number } as Area)),
        // switchMap into the actual create call
      )
    );

    // Resolve area numbers first, then create sequentially via forkJoin of
    // the create calls themselves (kept as two steps for clarity/logging).
    forkJoin(creates).pipe(
      map(areasToCreate => areasToCreate.map(area => this.areasApiService.addArea(area))),
      finalize(() => this.saving = false)
    ).subscribe(createObservables => {
      forkJoin(createObservables).subscribe(() => {
        this.store.dispatch(new LoadAreaRows({ siteId }));
        this.resetForm();
        this.dialogService.closeDialog(DialogKeys.ADD_NEW_AREA);
      });
    });
  }

  private resetForm() {
    while (this.rows.length > 1) {
      this.rows.removeAt(this.rows.length - 1);
    }
    this.form.reset();
  }
}
