import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { forkJoin, Observable } from 'rxjs';
import { finalize, map, takeUntil } from 'rxjs/operators';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { DialogType, MessageDialog, MessageType } from '../../../../model/message-dialog';
import { MessageDialogComponent } from '../../../../shared/components/message-dialog/message-dialog.component';
import { Building } from '../../../../model/building';
import { Area } from '../../../../model/area';
import { BuildingsService } from '../../../../core/services/buildings.service';
import { AreasService } from '../../../../core/services/areas.service';
import { AreasApiService } from '../../../../core/api/areas-api.service';
import { Zone } from '../../../zones/model/zone';
import { ZoneType } from '../../../zones/model/zone-type';
import { AlarmZonesService } from '../../../zones/services/alarm-zones.service';
import { ControlZonesService } from '../../../zones/services/control-zones.service';
import { DetectionZonesService } from '../../../zones/services/detection-zones.service';
import { LoadZoneRows } from '../../state/area-zone-list';
import { expandZoneNumberRange, parseZoneNumberRange } from '../../model/area-zone-form.model';

const ZONE_TYPES: ZoneType[] = ['Alarm', 'Control', 'Detection'];

/**
 * "New Zone" dialog (frames 5-6) + the duplicate-range "Warning!" confirmation
 * (frame 7). See dev guide section 3 for why a single logical "zone" here can
 * fan out into up to three physical Add*Zone calls (one per selected type),
 * each going through the existing per-type service (no backend change).
 */
@Component({
  selector: 'app-new-zone-dialog',
  templateUrl: './new-zone-dialog.component.html',
  styleUrls: ['./new-zone-dialog.component.scss']
})
export class NewZoneDialogComponent extends UnsubscribeDirective implements OnInit {

  dialogKeys = DialogKeys;
  form: FormGroup;
  buildings: Building[] = [];
  areas: Area[] = [];
  zoneTypeOptions = ZONE_TYPES;
  saving = false;
  addingNewArea = false;

  @ViewChild(MessageDialogComponent, { static: true }) messageDialogComponent: MessageDialogComponent;

  private siteId: string;

  private servicesByType: Record<ZoneType, AlarmZonesService | ControlZonesService | DetectionZonesService>;

  constructor(
    private fb: FormBuilder,
    private dialogService: DialogService,
    private buildingsService: BuildingsService,
    private areasService: AreasService,
    private areasApiService: AreasApiService,
    private alarmZonesService: AlarmZonesService,
    private controlZonesService: ControlZonesService,
    private detectionZonesService: DetectionZonesService,
    private store: Store,
    private route: ActivatedRoute
  ) {
    super();
    this.servicesByType = {
      Alarm: this.alarmZonesService,
      Control: this.controlZonesService,
      Detection: this.detectionZonesService
    };
  }

  ngOnInit() {
    this.siteId = this.route.snapshot.paramMap.get('siteId') || '';

    this.form = this.fb.group({
      zoneName: ['', Validators.required],
      buildingId: ['', Validators.required],
      areaId: ['', Validators.required],
      newAreaName: [''],
      zoneNumberRange: ['', [Validators.required, this.rangeValidator]],
      zoneTypes: [[], Validators.required],
      isLegacyZone: [false]
    });

    this.buildingsService.getBuildings(this.siteId).pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe(buildings => this.buildings = buildings);
    this.areasService.getAreasForSite(this.siteId).pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe(areas => this.areas = areas);
  }

  rangeValidator = (control: any) => {
    const parsed = parseZoneNumberRange(control.value);
    return parsed.valid ? null : { invalidRange: true };
  };

  toggleNewArea(useNew: boolean) {
    this.addingNewArea = useNew;
    this.form.get('areaId').setValue('');
    this.form.get('newAreaName').setValue('');
  }

  cancel() {
    this.form.reset({ zoneTypes: [], isLegacyZone: false });
    this.dialogService.closeDialog(DialogKeys.ADD_NEW_ZONE);
  }

  save() {
    if (this.form.invalid || this.saving) {
      this.form.markAllAsTouched();
      return;
    }

    const selectedTypes: ZoneType[] = this.form.value.zoneTypes;
    const range = parseZoneNumberRange(this.form.value.zoneNumberRange);
    const numbers = expandZoneNumberRange(range);

    this.saving = true;

    // Check every number in the range, against every selected type, for an
    // existing conflict (frame 7's "Few zone(s) already exist(s)..." case).
    const validityChecks = selectedTypes.flatMap(type =>
      numbers.map(n => this.servicesByType[type].zoneNumberIsValid(this.siteId, n).pipe(
        map(isValid => ({ type, number: n, isValid }))
      ))
    );

    forkJoin(validityChecks).pipe(finalize(() => this.saving = false)).subscribe(results => {
      const conflicts = results.filter(r => !r.isValid);
      if (conflicts.length > 0) {
        this.showRangeWarning(conflicts.length, range, () => this.createZones(selectedTypes, numbers));
      } else {
        this.createZones(selectedTypes, numbers);
      }
    });
  }

  private showRangeWarning(conflictCount: number, range: { start: number; end: number }, onProceed: () => void) {
    this.messageDialogComponent.config = {
      title: 'Warning!',
      detailedMessage: `Few zone(s) already exist(s) in the entered range (${range.start}-${range.end}). ` +
        `Do you wish to continue creating the remaining zones?`,
      type: MessageType.Warning,
      dialogType: DialogType.UserInput,
      okButtonTitle: 'Yes, Create',
      callbackOkEvent: true,
      callbackCancelEvent: true
    } as MessageDialog;
    this.dialogService.openDialog(DialogKeys.MODULE_INFO_MESSAGE);

    // "No, Go back" (cancelEvent) simply closes the warning and leaves this
    // dialog's form state intact, per the Figma flow. "Yes, Create" proceeds
    // with only the non-conflicting numbers.
    this.messageDialogComponent.okEvent.pipe(takeUntil(this.ngUnsubscribe$)).subscribe(() => {
      this.dialogService.closeDialog(DialogKeys.MODULE_INFO_MESSAGE);
      onProceed();
    });
  }

  private createZones(selectedTypes: ZoneType[], numbers: number[]) {
    this.saving = true;

    const resolveAreaId$: Observable<string> = this.addingNewArea
      ? this.areasApiService.getAreaNumber(this.siteId).pipe(
          map(number => ({ label: this.form.value.newAreaName, buildingId: this.form.value.buildingId, number } as Area)),
          // switchMap-style chain kept explicit via nested subscribe below for clarity
        )
      : null;

    if (this.addingNewArea) {
      resolveAreaId$.subscribe((areaToCreate: Area) => {
        this.areasApiService.addArea(areaToCreate).subscribe((createdArea: Area) => {
          this.createZonesForArea(createdArea.id, selectedTypes, numbers);
        });
      });
    } else {
      this.createZonesForArea(this.form.value.areaId, selectedTypes, numbers);
    }
  }

  private createZonesForArea(areaId: string, selectedTypes: ZoneType[], numbers: number[]) {
    const creates: Observable<Zone>[] = [];
    for (const type of selectedTypes) {
      for (const zoneNumber of numbers) {
        const zone: Zone = {
          id: null,
          label: this.form.value.zoneName,
          areaId,
          zoneNumber,
          isLegacyZone: this.form.value.isLegacyZone,
          zoneType: type
        };
        creates.push(this.servicesByType[type].addZone(zone) as unknown as Observable<Zone>);
      }
    }

    forkJoin(creates).pipe(finalize(() => this.saving = false)).subscribe(() => {
      this.store.dispatch(new LoadZoneRows({ siteId: this.siteId }));
      this.cancel();
    });
  }
}
