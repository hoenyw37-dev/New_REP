import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Store } from '@ngrx/store';
import { forkJoin } from 'rxjs';
import { PopOutService } from '../../../../shared/services/pop-out.service';
import { PopOutType } from '../../../../shared/models/pop-out-type.enum';
import { ZoneIo } from '../../../../model/zoneIo';
import { ZoneType } from '../../../zones/model/zone-type';
import { ZonesTypeDeviceSearchFilters } from '../../../zones/model/zones-type-device-search-filters';
import { CommonZoneInputsOutputsService } from '../../../zones/services/common-zone-inputs-outputs.service';
import { AddZoneDevices } from '../../../zones/state/zone-devices/zone-devices.actions';
import { ZoneRow } from '../../model/area-zone-row.model';
import { DeviceCardViewModel } from '../../model/device-card-view.model';

/**
 * Frames 10-13: the "Device list" slide-out panel.
 *
 * ASSUMPTION (flag before shipping): when a zone spans multiple types
 * (e.g. Alarm + Control, see dev guide §3), a device dropped here is added
 * under ALL of that zone's types via one AddZoneDevices call per type,
 * mirroring how zone creation itself fans out per selected type. The Figma
 * doesn't show per-type distinction anywhere in this panel, so this is the
 * most consistent reading, but it's an interpretation, not a confirmed spec.
 *
 * Drag-and-drop uses Angular CDK (@angular/cdk/drag-drop, already a
 * dependency). Multi-select-then-drag (frame 11-12: dragging one of several
 * selected rows moves the whole selection) is implemented by checking, at
 * drop time, whether the dragged item belongs to the current selection set -
 * if so the whole selection transfers, not just the one row physically
 * dragged.
 */
@Component({
  selector: 'app-device-list-panel',
  templateUrl: './device-list-panel.component.html',
  styleUrls: ['./device-list-panel.component.scss']
})
export class DeviceListPanelComponent implements OnChanges {
  @Input() zoneRow: ZoneRow;
  @Input() siteId: string;
  @Input() alreadyAssignedPointIds: string[] = [];
  @Output() devicesAdded = new EventEmitter<void>();

  available: DeviceCardViewModel[] = [];
  selectedForZone: DeviceCardViewModel[] = [];
  saving = false;

  constructor(
    private ioService: CommonZoneInputsOutputsService,
    private store: Store,
    private popOutService: PopOutService
  ) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes.zoneRow && this.zoneRow) {
      this.loadAvailableDevices();
    }
  }

  get multiSelectedOnRight(): DeviceCardViewModel[] {
    return this.available.filter(d => d.selected);
  }

  loadAvailableDevices() {
    const types = Object.keys(this.zoneRow.sourceZones) as ZoneType[];

    const calls = types.map(type => {
      const source = this.zoneRow.sourceZones[type];
      return this.ioService.getZoneDevicesForSite(
        type, this.siteId, source.panelId, source.id, ZonesTypeDeviceSearchFilters.UnassignedDevices
      );
    });

    forkJoin(calls).subscribe(results => {
      const alreadyAssigned = new Set(this.alreadyAssignedPointIds);
      const seen = new Set<string>();
      this.available = results.flat()
        .filter(io => !alreadyAssigned.has(io.pointId) && !seen.has(io.pointId) && seen.add(io.pointId))
        .map(io => ({
          pointId: io.pointId,
          panelId: io.panelId,
          loopId: io.loopId,
          deviceId: io.deviceId,
          label: io.label,
          type: types[0], // best-effort - see class comment on the type-mapping gap
          addedOn: null,
          selected: false
        }));
      this.selectedForZone = [];
    });
  }

  toggleAvailableSelection(device: DeviceCardViewModel) {
    device.selected = !device.selected;
  }

  onDrop(event: CdkDragDrop<DeviceCardViewModel[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      return;
    }

    const draggedItem: DeviceCardViewModel = event.previousContainer.data[event.previousIndex];
    const isMovingToSelected = event.container.data === this.selectedForZone;

    if (isMovingToSelected && draggedItem.selected && this.multiSelectedOnRight.length > 1) {
      // Multi-drag: move the whole selected set, not just the physically-dragged row (frames 11-12)
      const toMove = [...this.multiSelectedOnRight];
      toMove.forEach(item => {
        const i = this.available.indexOf(item);
        if (i > -1) {
          transferArrayItem(this.available, this.selectedForZone, i, this.selectedForZone.length);
        }
      });
    } else {
      transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex);
    }

    this.selectedForZone.forEach(d => d.selected = false);
  }

  clearSelectedForZone() {
    this.available.push(...this.selectedForZone);
    this.selectedForZone = [];
  }

  cancel() {
    this.selectedForZone = [];
    this.popOutService.close(PopOutType.ZoneDeviceList);
  }

  save() {
    if (this.selectedForZone.length === 0 || this.saving) {
      return;
    }
    this.saving = true;
    const types = Object.keys(this.zoneRow.sourceZones) as ZoneType[];

    const devices: ZoneIo[] = this.selectedForZone.map(d => ({
      pointId: d.pointId, panelId: d.panelId, loopId: d.loopId, deviceId: d.deviceId, label: d.label
    } as ZoneIo));

    types.forEach(type => {
      const source = this.zoneRow.sourceZones[type];
      this.store.dispatch(new AddZoneDevices({
        zoneType: type, zoneId: source.id, panelId: source.panelId, siteId: this.siteId, devices
      }));
    });

    this.saving = false;
    this.selectedForZone = [];
    this.devicesAdded.emit();
    this.popOutService.close(PopOutType.ZoneDeviceList);
  }
}
