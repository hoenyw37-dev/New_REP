import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DeviceCardViewModel } from '../../model/device-card-view.model';

/**
 * One device card. Deliberately dumb/presentational - used in two contexts
 * (ZoneDetailsComponent's browse grid, and DeviceListPanelComponent's
 * "Available devices" list) so selection/drag concerns live in the parents,
 * keeping this component trivial to reuse and test.
 */
@Component({
  selector: 'app-zone-device-card',
  templateUrl: './zone-device-card.component.html',
  styleUrls: ['./zone-device-card.component.scss']
})
export class ZoneDeviceCardComponent {
  @Input() device: DeviceCardViewModel;
  @Input() compact = false; // true = row layout (device-list-panel), false = card layout (zone details grid)
  @Output() select = new EventEmitter<DeviceCardViewModel>();

  onClick() {
    this.select.emit(this.device);
  }
}
