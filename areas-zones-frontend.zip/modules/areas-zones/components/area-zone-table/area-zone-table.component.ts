import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { TableColumn } from '../../../../shared/components/mat-grid/mat-grid.component';
import { AreasZonesTab, AreaRow, ZoneRow } from '../../model/area-zone-row.model';
import {
  getAreaRows,
  getZoneRows,
  getAreaZoneListLoading,
  LoadAreaRows,
  LoadZoneRows
} from '../../state/area-zone-list';

/**
 * Frames 1 (Areas) and 2 (Zones) table. Reused for both tabs - `mode` comes
 * from the active child route's `data.mode` (see areas-zones-routing.module.ts)
 * rather than being duplicated into NgRx state, matching how nav-tabs derives
 * its active state from the URL elsewhere in the app.
 *
 * KNOWN DEVIATION FROM FIGMA: app-mat-grid (shared/components/mat-grid) does
 * not support per-column custom cell templates, so the "Zone name"/"Area
 * name" cells cannot be rendered as an inline link with the rest of the row
 * as plain text the way the Figma shows. This implementation makes the whole
 * row clickable on the Zones tab instead (a common, acceptable data-table
 * pattern) rather than modifying the shared grid to add template projection,
 * which is a larger, higher-blast-radius change - flag this trade-off with
 * design/PM. The "Zone"/"Area" column text is still styled blue via CSS so
 * it reads the same as the Figma at a glance.
 */
@Component({
  selector: 'app-area-zone-table',
  templateUrl: './area-zone-table.component.html',
  styleUrls: ['./area-zone-table.component.scss']
})
export class AreaZoneTableComponent extends UnsubscribeDirective implements OnInit {

  mode: AreasZonesTab;
  dialogKeys = DialogKeys;

  loading$: Observable<boolean>;
  rows$: Observable<(AreaRow | ZoneRow)[]>;

  areaColumns: TableColumn[] = [
    { header: 'areaName', headerText: 'Area', isSortable: true },
    { header: 'buildingName', headerText: 'Building', isSortable: true },
    { header: 'zoneCount', headerText: 'No. of zones', isSortable: true, textAlign: 'right' },
    { header: 'panelCount', headerText: 'No. of panels', isSortable: true, textAlign: 'right' },
    { header: 'deviceCount', headerText: 'No. of devices', isSortable: true, textAlign: 'right' },
    { header: 'lastUpdated', headerText: 'Last updated', isSortable: true },
    { header: 'rowMenu', headerText: '' }
  ];

  zoneColumns: TableColumn[] = [
    { header: 'label', headerText: 'Zone', isSortable: true },
    { header: 'typesDisplay', headerText: 'Type' },
    { header: 'buildingName', headerText: 'Building', isSortable: true },
    { header: 'areaName', headerText: 'Area', isSortable: true },
    { header: 'deviceCount', headerText: 'No. of devices', isSortable: true, textAlign: 'right' },
    { header: 'lastUpdated', headerText: 'Last updated', isSortable: true },
    { header: 'rowMenu', headerText: '' }
  ];

  rowMenuConfig = {
    icon: 'assets/images/icons/icon-more-options.svg',
    activeIcon: 'assets/images/icons/icon-more-options-active.svg',
    label: 'row-actions',
    dataSource: [
      { id: 'edit', text: 'Edit' },
      { id: 'delete', text: 'Delete' }
    ]
  };

  private searchTerm$ = new BehaviorSubject<string>('');

  @ViewChild('newAreaDialog') newAreaDialogRef;
  @ViewChild('newZoneDialog') newZoneDialogRef;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private store: Store,
    private dialogService: DialogService
  ) {
    super();
  }

  ngOnInit() {
    this.mode = this.route.snapshot.data.mode;
    this.loading$ = this.store.select(getAreaZoneListLoading).pipe(takeUntil(this.ngUnsubscribe$));

    // TODO: replace with the real selected-site id selector used elsewhere
    // in the app (see state/active-sites) once this module is wired into the
    // real site-selection flow - left explicit here rather than guessed.
    const siteId = this.route.snapshot.paramMap.get('siteId') || '';

    if (this.mode === 'areas') {
      this.store.dispatch(new LoadAreaRows({ siteId }));
      const areaRows$ = this.store.select(getAreaRows).pipe(takeUntil(this.ngUnsubscribe$));
      this.rows$ = combineLatest([areaRows$, this.searchTerm$]).pipe(
        map(([rows, term]) => this.filterRows(rows, term, ['areaName', 'buildingName']))
      );
    } else {
      this.store.dispatch(new LoadZoneRows({ siteId }));
      const zoneRows$ = this.store.select(getZoneRows).pipe(takeUntil(this.ngUnsubscribe$));
      this.rows$ = combineLatest([zoneRows$, this.searchTerm$]).pipe(
        map(([rows, term]) => this.filterRows(
          (rows as ZoneRow[]).map(r => ({ ...r, typesDisplay: r.types.join(', ') })),
          term,
          ['label', 'buildingName', 'areaName']
        ))
      );
    }
  }

  onSearch(term: string) {
    this.searchTerm$.next(term ?? '');
  }

  onAddClick() {
    const key = this.mode === 'areas' ? DialogKeys.ADD_NEW_AREA : DialogKeys.ADD_NEW_ZONE;
    this.dialogService.openDialog(key);
  }

  onRowClick(row: AreaRow | ZoneRow) {
    if (this.mode !== 'zones') {
      return; // no "Area details" screen in this Figma export - see dev guide open question 1
    }
    this.router.navigate(['../zones', (row as ZoneRow).rowKey], { relativeTo: this.route });
  }

  onMenuSelection(event: { selectedOption: any; selectedRow: any }) {
    if (event.selectedOption.id === 'edit') {
      const key = this.mode === 'areas' ? DialogKeys.ADD_NEW_AREA : DialogKeys.ADD_NEW_ZONE;
      // Edit-mode prefill is handled inside the dialog component via its
      // @Input() editRow - see new-area-dialog / new-zone-dialog.
      this.dialogService.openDialog(key);
    } else if (event.selectedOption.id === 'delete') {
      // Wire to shared/components/delete-dialog with the correct per-type
      // delete call(s) - for a merged ZoneRow this may mean deleting more
      // than one physical zone record (row.sourceZones), see dev guide §3.
    }
  }

  private filterRows<T>(rows: T[], term: string, fields: (keyof T)[]): T[] {
    if (!term) {
      return rows;
    }
    const lower = term.toLowerCase();
    return rows.filter(row => fields.some(f => String(row[f] ?? '').toLowerCase().includes(lower)));
  }
}
