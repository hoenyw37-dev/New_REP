import { Component, Input } from '@angular/core';
import { ZoneType } from '../../../zones/model/zone-type';

/**
 * Colored type pill used for zone-type badges (Zones table, frame 2) and
 * device-type badges (device cards, frames 8-13).
 *
 * NOTE: shared/components/status (StatusComponent) was evaluated first but is
 * hard-coded to a fixed set of connection-status values (StatusType enum) and
 * isn't a fit for arbitrary Alarm/Control/Detection labels - hence this small
 * new component rather than reusing it. If a future ticket generalises
 * StatusComponent, this should be folded into it.
 */
@Component({
  selector: 'app-zone-type-badge',
  templateUrl: './zone-type-badge.component.html',
  styleUrls: ['./zone-type-badge.component.scss']
})
export class ZoneTypeBadgeComponent {
  @Input() type: ZoneType;
}
