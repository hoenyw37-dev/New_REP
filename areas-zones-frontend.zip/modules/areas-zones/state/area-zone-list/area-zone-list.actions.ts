import { Action } from '@ngrx/store';
import { AreaRow, ZoneRow } from '../../model/area-zone-row.model';

export enum AreaZoneListActionTypes {
  LoadAreaRows = '[AreaZoneList] Load Area Rows',
  LoadAreaRowsSuccess = '[AreaZoneList] Load Area Rows Success',
  LoadAreaRowsFail = '[AreaZoneList] Load Area Rows Fail',
  LoadZoneRows = '[AreaZoneList] Load Zone Rows',
  LoadZoneRowsSuccess = '[AreaZoneList] Load Zone Rows Success',
  LoadZoneRowsFail = '[AreaZoneList] Load Zone Rows Fail',
}

export class LoadAreaRows implements Action {
  readonly type = AreaZoneListActionTypes.LoadAreaRows;
  constructor(public payload: { siteId: string }) {}
}

export class LoadAreaRowsSuccess implements Action {
  readonly type = AreaZoneListActionTypes.LoadAreaRowsSuccess;
  constructor(public payload: AreaRow[]) {}
}

export class LoadAreaRowsFail implements Action {
  readonly type = AreaZoneListActionTypes.LoadAreaRowsFail;
  constructor(public payload: any) {}
}

export class LoadZoneRows implements Action {
  readonly type = AreaZoneListActionTypes.LoadZoneRows;
  constructor(public payload: { siteId: string }) {}
}

export class LoadZoneRowsSuccess implements Action {
  readonly type = AreaZoneListActionTypes.LoadZoneRowsSuccess;
  constructor(public payload: ZoneRow[]) {}
}

export class LoadZoneRowsFail implements Action {
  readonly type = AreaZoneListActionTypes.LoadZoneRowsFail;
  constructor(public payload: any) {}
}

export type AreaZoneListActions =
  | LoadAreaRows
  | LoadAreaRowsSuccess
  | LoadAreaRowsFail
  | LoadZoneRows
  | LoadZoneRowsSuccess
  | LoadZoneRowsFail;
