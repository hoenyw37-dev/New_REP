import { AreaRow, ZoneRow } from '../../model/area-zone-row.model';
import { AreaZoneListActions, AreaZoneListActionTypes } from './area-zone-list.actions';

export interface AreaZoneListState {
  areaRows: AreaRow[];
  zoneRows: ZoneRow[];
  loading: boolean;
  loaded: boolean;
  error: any;
}

export const initialState: AreaZoneListState = {
  areaRows: [],
  zoneRows: [],
  loading: false,
  loaded: false,
  error: null
};

export function areaZoneListReducer(state: AreaZoneListState = initialState, action: AreaZoneListActions): AreaZoneListState {
  switch (action.type) {
    case AreaZoneListActionTypes.LoadAreaRows:
    case AreaZoneListActionTypes.LoadZoneRows:
      return { ...state, loading: true, error: null };

    case AreaZoneListActionTypes.LoadAreaRowsSuccess:
      return { ...state, areaRows: action.payload, loading: false, loaded: true };

    case AreaZoneListActionTypes.LoadZoneRowsSuccess:
      return { ...state, zoneRows: action.payload, loading: false, loaded: true };

    case AreaZoneListActionTypes.LoadAreaRowsFail:
    case AreaZoneListActionTypes.LoadZoneRowsFail:
      return { ...state, loading: false, error: action.payload };

    default:
      return state;
  }
}
