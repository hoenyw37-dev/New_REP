import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AreaZoneListState } from './area-zone-list.reducer';

export * from './area-zone-list.actions';

export const getAreaZoneListState = createFeatureSelector<AreaZoneListState>('areaZoneList');

export const getAreaRows = createSelector(getAreaZoneListState, state => state.areaRows);
export const getZoneRows = createSelector(getAreaZoneListState, state => state.zoneRows);
export const getAreaZoneListLoading = createSelector(getAreaZoneListState, state => state.loading);
export const getAreaZoneListLoaded = createSelector(getAreaZoneListState, state => state.loaded);
export const getAreaZoneListError = createSelector(getAreaZoneListState, state => state.error);
