import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { forkJoin, Observable, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { Area } from '../../../../model/area';
import { Building } from '../../../../model/building';
import { BuildingsService } from '../../../../core/services/buildings.service';
import { AreasService } from '../../../../core/services/areas.service';
import { Zone } from '../../../zones/model/zone';
import { ZoneType } from '../../../zones/model/zone-type';
import { AlarmZonesService } from '../../../zones/services/alarm-zones.service';
import { ControlZonesService } from '../../../zones/services/control-zones.service';
import { DetectionZonesService } from '../../../zones/services/detection-zones.service';
import { AreaRow, ZoneRow } from '../../model/area-zone-row.model';
import {
  AreaZoneListActionTypes,
  LoadAreaRows,
  LoadAreaRowsFail,
  LoadAreaRowsSuccess,
  LoadZoneRows,
  LoadZoneRowsFail,
  LoadZoneRowsSuccess
} from './area-zone-list.actions';

@Injectable()
export class AreaZoneListEffects {

  loadAreaRows$: Observable<Action> = createEffect(() => this.actions$.pipe(
    ofType(AreaZoneListActionTypes.LoadAreaRows),
    map((action: LoadAreaRows) => action.payload),
    switchMap(({ siteId }) =>
      forkJoin({
        areas: this.areasService.getAreasForSite(siteId),
        buildings: this.buildingsService.getBuildings(siteId),
        // Zone lists are needed here purely to compute the "No. of zones" rollup
        // column per area (frame 1) - there is no dedicated area-summary endpoint.
        alarmZones: this.alarmZonesService.getZonesForSite(siteId),
        controlZones: this.controlZonesService.getZonesForSite(siteId),
        detectionZones: this.detectionZonesService.getZonesForSite(siteId)
      }).pipe(
        map(({ areas, buildings, alarmZones, controlZones, detectionZones }) =>
          this.buildAreaRows(areas, buildings, [...alarmZones, ...controlZones, ...detectionZones])
        ),
        map(rows => new LoadAreaRowsSuccess(rows)),
        catchError(error => of(new LoadAreaRowsFail(error)))
      )
    )
  ));

  loadZoneRows$: Observable<Action> = createEffect(() => this.actions$.pipe(
    ofType(AreaZoneListActionTypes.LoadZoneRows),
    map((action: LoadZoneRows) => action.payload),
    switchMap(({ siteId }) =>
      forkJoin({
        areas: this.areasService.getAreasForSite(siteId),
        buildings: this.buildingsService.getBuildings(siteId),
        alarmZones: this.alarmZonesService.getZonesForSite(siteId),
        controlZones: this.controlZonesService.getZonesForSite(siteId),
        detectionZones: this.detectionZonesService.getZonesForSite(siteId)
      }).pipe(
        map(({ areas, buildings, alarmZones, controlZones, detectionZones }) =>
          this.mergeZoneRows(areas, buildings, alarmZones, controlZones, detectionZones)
        ),
        map(rows => new LoadZoneRowsSuccess(rows)),
        catchError(error => of(new LoadZoneRowsFail(error)))
      )
    )
  ));

  constructor(
    private actions$: Actions,
    private areasService: AreasService,
    private buildingsService: BuildingsService,
    private alarmZonesService: AlarmZonesService,
    private controlZonesService: ControlZonesService,
    private detectionZonesService: DetectionZonesService
  ) { }

  private buildAreaRows(areas: Area[], buildings: Building[], allZones: Zone[]): AreaRow[] {
    const buildingsById = new Map(buildings.map(b => [b.id, b]));
    return areas.map(area => {
      const zonesInArea = allZones.filter(z => z.areaId === area.id);
      return {
        id: area.id,
        areaName: area.label,
        buildingId: area.buildingId,
        buildingName: buildingsById.get(area.buildingId)?.label ?? '',
        zoneCount: zonesInArea.length,
        // Panel count has no client-side source without an extra per-area panel
        // lookup; wire this to whichever panel-count endpoint/selector the
        // Panels module already exposes rather than guessing at one here.
        panelCount: 0,
        // Device count similarly requires a per-zone device-count rollup that
        // isn't returned by GetAreasForSite/GetAlarmZonesForSite etc. - if the
        // backend team can add a rollup to those responses later, wire it in
        // here instead of computing 0.
        deviceCount: 0,
        lastUpdated: null
      };
    });
  }

  private mergeZoneRows(
    areas: Area[],
    buildings: Building[],
    alarmZones: Zone[],
    controlZones: Zone[],
    detectionZones: Zone[]
  ): ZoneRow[] {
    const areasById = new Map(areas.map(a => [a.id, a]));
    const buildingsById = new Map(buildings.map(b => [b.id, b]));

    const typed: Array<{ zone: Zone; type: ZoneType }> = [
      ...alarmZones.map(zone => ({ zone, type: 'Alarm' as ZoneType })),
      ...controlZones.map(zone => ({ zone, type: 'Control' as ZoneType })),
      ...detectionZones.map(zone => ({ zone, type: 'Detection' as ZoneType }))
    ];

    const grouped = new Map<string, ZoneRow>();

    for (const { zone, type } of typed) {
      const rowKey = `${zone.zoneNumber}__${zone.label}`;
      const area = areasById.get(zone.areaId);
      const building = area ? buildingsById.get(area.buildingId) : undefined;

      if (!grouped.has(rowKey)) {
        grouped.set(rowKey, {
          rowKey,
          zoneNumber: zone.zoneNumber,
          label: zone.label,
          types: [],
          buildingId: building?.id ?? '',
          buildingName: building?.label ?? '',
          areaId: zone.areaId,
          areaName: area?.label ?? '',
          deviceCount: 0,
          lastUpdated: null,
          isLegacyZone: zone.isLegacyZone,
          sourceZones: {}
        });
      }

      const row = grouped.get(rowKey);
      row.types.push(type);
      row.sourceZones[type] = { id: zone.id, panelId: zone.panelId };
    }

    return Array.from(grouped.values());
  }
}
