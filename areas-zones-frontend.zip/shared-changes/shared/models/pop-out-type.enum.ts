export enum PopOutType {
  ZonesTypeDeviceSearch = 'ZonesTypeDeviceSearch',
  ZonesDetectionZoneSearch = 'ZonesDetectionZoneSearch',
  ZoneDeviceList = 'ZoneDeviceList'
}