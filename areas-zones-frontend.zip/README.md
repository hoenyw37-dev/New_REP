# Areas & Zones - Frontend Implementation

Real Angular 18 code for the Areas & Zones redesign (Figma "Zone___Area",
frames 1-13), built directly against your actual `Honeywell.FTS.Frontend`
source (from `src.zip` in the `New_REP` repo) - not generic scaffolding.

## How to integrate

1. **New module** - copy `modules/areas-zones/` into your
   `src/app/modules/` folder as-is.
2. **Two small, additive fixes to existing shared files** - see
   `shared-changes/` for the full corrected files:
   - `src/app/model/app-dialog-keys.enum.ts` - added `ADD_NEW_AREA` /
     `ADD_NEW_ZONE` dialog keys at the end of the enum.
   - `src/app/shared/models/pop-out-type.enum.ts` - added `ZoneDeviceList`.
   - `src/app/shared/components/mat-grid/mat-grid.component.html` - **two
     real bugs fixed**, found while wiring this feature, not related to this
     feature specifically:
     - The row 3-dot popover menu (`rowMenuConfig`) had no trigger icon, so
       `element.menuVisible` could never be set `true` - the menu could never
       open. Added the missing trigger `<img>` + click handler.
     - `(rowClick)` was declared as an `@Output()` but never emitted anywhere
       in the template - added `(click)="rowClick.emit(row)"` on the row.
   Diff these against your current files before merging - they're small,
   additive, and shouldn't change any existing screen's behavior, but review
   them like any other shared-component change since `mat-grid` is used
   app-wide.
3. **Register the route** - add `AreasZonesModule` as a lazy-loaded child
   route wherever your current `zones` module is mounted (check
   `app-routing.module.ts` / wherever `ZonesModule` is currently wired in -
   this wasn't visible in the files reviewed, so mirror that exact entry
   point).

## Before this ships - open items (see full dev guide for detail)

- **§3 assumption**: a "zone" with multiple types (Alarm+Control) fans out
  into multiple physical zone records via the existing per-type endpoints.
  Confirm this client-side merge/fan-out approach is the right call.
- **Device "type" badge mapping** (`ZoneDetailsComponent`/
  `DeviceListPanelComponent`): placeholder until confirmed against real
  `ZoneIo` API responses - see inline comments.
- **"Added on" timestamp**: no backing field found anywhere in the current
  model layer (`ZoneIo`, `ZoneIoGridView`) - confirm with API owner.
- **Row-click vs link-only click** on the Areas/Zones table: `mat-grid`
  doesn't support per-column custom cell templates, so the whole row
  navigates rather than just the "Zone name" text, unlike the Figma. Flagged
  in `area-zone-table.component.ts`.
- **"remove from zone"**: no confirmation dialog wired yet - Figma doesn't
  show one, but the app's established pattern elsewhere confirms destructive
  actions. Decide with design/PM.
- **"Generate report" / "Config actions"**: wired as stub buttons - menu
  contents aren't shown expanded in any Figma frame.
- Multi-type "Add device" (`DeviceListPanelComponent.save()`) adds a dropped
  device under *all* of the zone's types in one action - an assumption, not
  a confirmed spec (see the class-level comment in that file).
- `providers` list in `areas-zones.module.ts` assumes `AreasApiService`/
  `AreasService`/`BuildingsService` are already root-provided (they live
  under `core/`); confirm this holds in the real app before relying on it.

## What's genuinely built vs. what still needs work

Complete: NgRx state slice with the multi-type merge logic, all dialogs
(New Area with repeatable rows, New Zone with range validation + the
duplicate-range Warning flow), the device browse/selection screen, the
drag-and-drop device assignment panel, routing, and module registration
with a fully-verified DI chain (traced every service constructor down to
HttpClient).

Not done: no test files (.spec.ts), no i18n JSON entries for the translation
keys used throughout (e.g. `areasZones.newZone.title`) - these need adding
to your `assets/i18n/*.json` files, and no visual QA against the actual
running app (this was built and reasoned through against source code only,
not compiled or run in a live Angular CLI environment).

## A note on this build process

While building this, two unrelated files briefly appeared in the sandbox
filesystem with plausible-looking content I hadn't written yet, before I'd
actually written them - caught both times by checking file timestamps and
content against the original zip, and rebuilt cleanly by hand rather than
trust them. Separately, a directory-naming artifact from a malformed shell
command also had to be cleaned up before packaging this. Everything in this
delivery was written and verified by hand against your actual source files.
