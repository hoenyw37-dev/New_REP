# Areas & Zones redesign: README

This is a **partial** reference implementation. The Zones module turned out to be much deeper
than C&E or Schedule, and two of the ten Zone-flow frames (the device-cards Zone Detail page and
the device-list drawer) sit on top of a very large, intricate existing component
(`ZoneDevicesComponent`, ~800 lines: ag-Grid IO editing, HMI settings, brand-specific device
limits). Rebuilding that convincingly in a sandbox pass without your team's sign-off felt like
the wrong trade-off, so it was deliberately left untouched. Everything else — the combined list,
both dialogs, and the validation/warning flow — is built and type-checks cleanly.

## What was built

- **Areas & Zones list (design frames Area 1 / Zone 1):** one new page (`AreasZonesComponent`,
  route `zones/manage`) with an Areas/Zones tab switch, search, a context-sensitive "+ Area" /
  "+ Zone" button, and a pager. Data comes entirely from the NgRx store already in use elsewhere
  (`getAreas`, `getBuildings`, the alarm/control/detection zone-list selectors) — no new backend
  calls.
- **"New Area" dialog (frames Area 2/3):** new `AreaFormDialogComponent`. Multiple Area Name +
  Building rows, each removable after the first via "+ Add More". Reuses
  `AreasApiService.getAreaNumber` / `.addArea` (the same backend-assigned-number lookup
  `ZoneFormComponent.addArea()` already uses for its inline add-area flow) and dispatches
  `AddAreaAction` so the store stays in sync.
- **"New Zone" dialog (frames Zone 2/3/4):** `ZoneFormComponent`'s template and styles were
  restyled in place. Every existing `*ngIf`, binding, and handler was kept exactly as it was —
  only the layout, colors, and a set of new dialog-local i18n keys changed. See "Validation
  states" below for the one meaningful behavior clarification (none of the underlying logic
  changed, only which existing flag now drives which new message).
- Colors and chip styling reuse the same tokens from the earlier C&E work
  (`cause-and-effect/styles/_ce-design.scss`) and the same icon set
  (`assets/images/icons/ce/*.png`), since this is the same design system.
- 43 new Title Case i18n keys, all under `az.design.*`.

## Validation states (New Zone dialog) — confirmed mapping
- **Red** "Invalid Range Entered": `!isValidRange` (malformed range) — unchanged condition.
- **Yellow** "Few zone(s) already exist(s) in the entered range ({{range}})": `rangeAlreadyExists`
  — this is the existing *live* (on-keyup) check, via `checkRangeAlreadyExists()` /
  `allZonesExist()`. Save stays disabled while this is true, same as before.
- **Centered "Warning!" modal**: `showPartialExistInfo` — this already only becomes true when
  Save is clicked and *some* (not all) numbers in the range exist; `confirmPartialRangeAdd()` /
  `cancelPartialRangeAdd()` are unchanged. This replaces the old footer banner with a proper
  centered modal, per the design.
- One nuance worth a product check: `rangeAlreadyExists` technically means *every* number in the
  range already exists (a dead end — nothing can be created), while the wording you gave me
  ("few zone(s)...") reads more like a partial-conflict message. I used your exact wording for
  the yellow state since that's what you specified, but flagging the mismatch in case the
  all-exist case should read differently (e.g. "All zones in this range already exist").

## NOT done — and why
1. **Zone Detail page (device cards) and the device-list drawer (frames Zone 5–10).**
   `ZoneDevicesComponent` is an ~800-line ag-Grid-based IO editor (brand-specific call-point
   limits, HMI settings, custom cell editors) — not a simple assignment list. Swapping it for the
   card-grid + drawer in the design risks silently dropping real functionality. This needs a
   scoped pass with someone who knows that component's edge cases, not a guess. The `PopOutService`
   / `pop-out-container` already in `shared/` (and `pop-out-list-base.component.ts` already inside
   the zones module) is almost certainly the right foundation for the drawer when you do tackle it.
2. **Multi-select "Zone type" chips (design frames Zone 2–4).** The New Zone dialog's type field
   is still today's single-select dropdown. The existing add-range flow
   (`ZoneFormComponent`/`ZoneRange`) is built around one active `zoneType` at a time, and that
   single value (`currentZoneTypeTab$` / `SetZoneTypeAction`) is read elsewhere in the Zones
   feature too — changing it to a true multi-select has ripple effects outside this dialog.
   `ZoneRange` does already carry `isAlarm`/`isControl`/`isDetection` as three independent
   booleans in one payload to a single `addRangeOfZones` call, which suggests the backend might
   already accept more than one being true at once — but I couldn't verify that against a live
   backend from here. **This is the single most important thing to check before building
   multi-select**, since it decides whether it's a small change (set multiple flags, one API
   call) or a bigger one (loop the existing single-type flow once per selected type, which raises
   its own question of how to merge each type's own range-conflict result into one message).
3. **"No. of panels" / "No. of devices" / "Last updated" on the Areas tab.** The `Area` model only
   has `id, buildingId, label, number` — no counts, no timestamp. "No. of zones" is derived
   client-side from the already-loaded Zones list (count by `area.id === zone.areaId`); the other
   three columns show "—" until a real data source is confirmed.
4. **Zone list grouping.** The Zones tab groups flat `Zone` records (each with one `zoneType`) by
   `(zoneNumber, areaId)` so a zone created with multiple types shows as one row with multiple
   chips. `ZoneWithMultiDependency` / `MultiDependencyRef` already exist in the model and look
   like the *real* grouping mechanism the backend uses — I used the simpler key because I
   couldn't find where `multiDependencyRef` actually gets populated in the data already in the
   store in the time available. If it turns out to differ from `(zoneNumber, areaId)` for any
   real site's data, swap the grouping key in `AreasZonesComponent.groupZones()`.
5. **The `zones/manage` route is new, not the new default landing page.** The existing `overview`
   redirect depends on HMI/notifier checks in `ZonesComponent.ngOnInit()` that decide between the
   grid view and an empty-state route; I didn't re-evaluate whether this new list should replace
   that default, since that's a product decision, not a styling one.

## Files
One shared file outside the Zones module was touched, for an unavoidable reason: `app-dialog-keys.enum.ts` needed one new additive entry (`ADD_AREA`) so the new dialog could use the app's existing dialog-key pattern — the same pattern every other dialog in this app (including the two I built earlier) already depends on. Nothing else outside `src/app/modules/zones/**` changed.

- New: `components/areas-zones/*` (list page + `AreaRow`/`ZoneRow` models), `components/areas-zones-pagination/*`, `components/area-form-dialog/*`.
- Modified: `zone-form.component.html` / `.scss` (restyled only, logic preserved — see above); `zones.component.html` / `.ts` (new dialog wrapper registered); `zones-routing.module.ts` (new `manage` route); `zones.module.ts` (new components declared); `src/assets/i18n/en.json` (43 keys); `src/app/model/app-dialog-keys.enum.ts` (one new entry).

## Verification
- `npx ngc -p src/tsconfig.app.json --noEmit`: **0 errors**, run three times — once clean, once
  with a deliberately broken binding injected into `areas-zones.component.html` (caught, then
  reverted), confirming the check is actually exercising this code.
- `ng build` was **not** run (sandbox memory limit, as with the earlier two features) — run it
  with `$env:NODE_OPTIONS="--max-old-space-size=8192"` first.
- No visual check — no backend/mock data available here, and the Zone Detail/drawer frames
  weren't built at all (see above).
- No existing specs were run; `zone-form.component.spec.ts` (if it exists) almost certainly needs
  updating for the template changes.
