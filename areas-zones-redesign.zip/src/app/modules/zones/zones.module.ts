import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, forwardRef, NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ModulesSettingService } from '../../modules/panels/services/modules-setting.service';
import { SharedModule } from '../../shared/shared.module';
import { HmiApiService } from '../panels/api/hmi-api.service';
import { ModulesSettingApiService } from '../panels/api/modules-setting-api.service';
import { HmiService } from '../panels/services/hmi.service';
import { PanelSettingsApiService } from '../panels/services/panel-settings-api.service';
import { AlarmZoneOutputsApiService } from './api/alarm-zone-outputs-api.service';
import { AlarmZonesApiService } from './api/alarm-zones-api.service';
import { ControlZoneInputsOutputsApiService } from './api/control-zone-inputs-outputs-api.service';
import { ControlZonesApiService } from './api/control-zones-api.service';
import { DetectionZoneInputsApiService } from './api/detection-zone-inputs-api.service';
import { DetectionZonesApiService } from './api/detection-zones-api.service';
import { MultiDependencyZonesApiService } from './api/multi-dependency-zones-api.service';
import { ZonesApiService } from './api/zones-api.service';
import { EditAreaComponent } from './components/edit-area/edit-area.component';
import { EditBuildingComponent } from './components/edit-building/edit-building.component';
import { MultiDependencyContextMenuComponent } from './components/multi-dependency-context-menu/multi-dependency-context-menu.component';
import { NoZoneSelectedComponent } from './components/no-zone-selected/no-zone-selected.component';
import { ZoneDetailsComponent } from './components/zone-details/zone-details.component';
import { ZoneDevicesComponent } from './components/zone-devices/zone-devices.component';
import { ZoneFormComponent } from './components/zone-form/zone-form.component';
import { ZoneMultiDependencyComponent } from './components/zone-multi-dependency/zone-multi-dependency.component';
import { ZoneOverviewComponent } from './components/zone-overview/zone-overview.component';
import { ZonesDetectionZoneSearchComponent } from './components/zones-detection-zone-search/zones-detection-zone-search.component';
import { ZonesEmptyComponent } from './components/zones-empty/zones-empty.component';
import { ZonesExpanderComponent } from './components/zones-expander/zones-expander.component';
import { ZonesGridViewComponent } from './components/zones-grid-view/zones-grid-view.component';
import { ZonesHeaderComponent } from './components/zones-header/zones-header.component';
import { ZonesListViewComponent } from './components/zones-list-view/zones-list-view.component';
import { ZonesOverviewComponent } from './components/zones-overview/zones-overview.component';
import { ZonesTypeDeviceSearchComponent } from './components/zones-type-device-search/zones-type-device-search.component';
import { ZonesComponent } from './components/zones/zones.component';
import { AreasZonesComponent } from './components/areas-zones/areas-zones.component';
import { AreaFormDialogComponent } from './components/area-form-dialog/area-form-dialog.component';
import { AreasZonesPaginationComponent } from './components/areas-zones-pagination/areas-zones-pagination.component';
import { ZonesServiceKey } from './services/abstract-zones.service';
import { AlarmZoneOutputsService } from './services/alarm-zone-outputs.service';
import { AlarmZonesService } from './services/alarm-zones.service';
import { CommonZoneInputsOutputsService } from './services/common-zone-inputs-outputs.service';
import { CommonZonesService } from './services/common-zones.service';
import { ControlZoneInputsOutputsService } from './services/control-zone-inputs-outputs.service';
import { ControlZonesService } from './services/control-zones.service';
import { DetectionZoneInputsService } from './services/detection-zone-inputs.service';
import { DetectionZonesService } from './services/detection-zones.service';
import { MultiDependencyZonesService } from './services/multi-dependency-zones.service';
import { ZonesCountGuard } from './services/zones-count.guard';
import { ZonesService } from './services/zones.service';
import { ExpandedZoneListEffects } from './state/expanded-zone-list/expanded-zone-list.effects';
import { MultiDependencyEffects } from './state/multi-dependency/multi-dependency.effects';
import { ZoneDevicesEffects } from './state/zone-devices/zone-devices-effects';
import { AlarmZoneListEffects } from './state/zone-list/alarm-zone-list/alarm-zone-list.effects';
import { ControlZoneListEffects } from './state/zone-list/control-zone-list/control-zone-list.effects';
import { DetectionZoneListEffects } from './state/zone-list/detection-zone-list/detection-zone-list.effects';
import { ZonesTypeDeviceSearchEffects } from './state/zones-type-device-search/zones-type-device-search.effects';
import { ReducerProvider, ReducerZoneToken } from './state/zones.reducer';
import { ZonesRoutingModule } from './zones-routing.module';
import { AgGridModule } from 'ag-grid-angular';

@NgModule({
  imports: [
    CommonModule,
    ZonesRoutingModule,
    SharedModule,
    AgGridModule,
    StoreModule.forFeature('zones', ReducerZoneToken),
    EffectsModule.forFeature([
      ExpandedZoneListEffects,
      ZonesTypeDeviceSearchEffects,
      ZoneDevicesEffects,
      AlarmZoneListEffects,
      ControlZoneListEffects,
      DetectionZoneListEffects,
      MultiDependencyEffects
    ])
  ],
  declarations: [
    ZonesComponent,
    ZonesEmptyComponent,
    ZonesOverviewComponent,
    ZonesHeaderComponent,
    ZoneFormComponent,
    EditBuildingComponent,
    EditAreaComponent,
    ZonesGridViewComponent,
    ZonesExpanderComponent,
    ZonesTypeDeviceSearchComponent,
    ZoneDetailsComponent,
    ZonesListViewComponent,
    ZoneOverviewComponent,
    ZoneDevicesComponent,
    NoZoneSelectedComponent,
    MultiDependencyContextMenuComponent,
    ZoneMultiDependencyComponent,
    ZonesDetectionZoneSearchComponent,
    AreasZonesComponent,
    AreaFormDialogComponent,
    AreasZonesPaginationComponent
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [
    AlarmZonesApiService,
    AlarmZoneOutputsApiService,
    ControlZonesApiService,
    DetectionZonesApiService,
    DetectionZoneInputsApiService,
    ControlZoneInputsOutputsApiService,
    ZonesApiService,
    MultiDependencyZonesApiService,
    AlarmZonesService,
    AlarmZoneOutputsService,
    ControlZonesService,
    DetectionZonesService,
    CommonZonesService,
    CommonZoneInputsOutputsService,
    ControlZoneInputsOutputsService,
    DetectionZoneInputsService,
    ModulesSettingService,
    ModulesSettingApiService,
    MultiDependencyZonesService,
    { provide: ZonesServiceKey, useExisting: forwardRef(() => AlarmZonesService), multi: true },
    { provide: ZonesServiceKey, useExisting: forwardRef(() => ControlZonesService), multi: true },
    { provide: ZonesServiceKey, useExisting: forwardRef(() => DetectionZonesService), multi: true },
    ZonesCountGuard,
    ZonesService,
    PanelSettingsApiService,
    HmiService,
    HmiApiService,
    ReducerProvider
  ]
})
export class ZonesModule {
}