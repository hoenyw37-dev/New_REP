import { Component, EventEmitter, Input, Output } from '@angular/core';

/** Pager matching the design ("1-10 Records Of 28", ‹ 1 2 3 … N ›), shared by the Areas and Zones tabs. */
@Component({
  selector: 'app-areas-zones-pagination',
  templateUrl: './areas-zones-pagination.component.html',
  styleUrls: ['./areas-zones-pagination.component.scss']
})
export class AreasZonesPaginationComponent {
  @Input() total = 0;
  @Input() pageSize = 10;
  @Input() page = 0;
  @Output() pageChange = new EventEmitter<number>();

  get pageCount(): number { return Math.max(1, Math.ceil(this.total / this.pageSize)); }
  get from(): number { return this.total === 0 ? 0 : this.page * this.pageSize + 1; }
  get to(): number { return Math.min(this.total, (this.page + 1) * this.pageSize); }

  get pages(): number[] {
    const n = this.pageCount;
    if (n <= 6) { return Array.from({ length: n }, (_, i) => i); }
    const set = new Set<number>([0, 1, 2, n - 1, this.page]);
    const sorted = Array.from(set).filter(p => p >= 0 && p < n).sort((a, b) => a - b);
    const out: number[] = [];
    sorted.forEach((p, i) => { if (i > 0 && p - sorted[i - 1] > 1) { out.push(-1); } out.push(p); });
    return out;
  }

  go(p: number) {
    if (p < 0 || p >= this.pageCount || p === this.page) { return; }
    this.pageChange.emit(p);
  }
}
