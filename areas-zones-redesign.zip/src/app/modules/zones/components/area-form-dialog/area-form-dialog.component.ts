import { Component, OnDestroy, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { forkJoin, Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import { AreasApiService } from '../../../../core/api/areas-api.service';
import { AreasService } from '../../../../core/services/areas.service';
import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { Area } from '../../../../model/area';
import { DropDownListElement } from '../../../../shared/components/drop-down/model/drop-down-list-element';
import { AppState } from '../../../../state/app.state';
import { getSelectedSiteId } from '../../../../state/active-sites';
import { AddAreaAction } from '../../../../state/areas';
import { getBuildings } from '../../../../state/buildings';

/** One "Area Name + Building" row in the New Area dialog (design frames Area 2 / Area 3). */
interface NewAreaRow {
  label: string;
  buildingId: string;
}

/**
 * "New Area" dialog (design frames Area 2/3): one or more Area Name + Building rows, each
 * removable after the first via "+ Add more". Reuses the existing `AreasService.addArea` and
 * `getAreaNumber` (the same next-available-number lookup the current inline add-area flow in
 * `ZoneFormComponent.addArea()` already uses) -- the design has no "Area number" field, so each
 * row's number is still fetched from the backend, just not shown to the user.
 */
@Component({
  selector: 'app-area-form-dialog',
  templateUrl: './area-form-dialog.component.html',
  styleUrls: ['./area-form-dialog.component.scss']
})
export class AreaFormDialogComponent implements OnInit, OnDestroy {
  rows: NewAreaRow[] = [{ label: '', buildingId: null }];
  buildingsDropdownData: DropDownListElement[] = [];
  isSaving = false;

  private subscription: Subscription;
  private siteId: string;

  constructor(
    private store: Store<AppState>,
    private areasApiService: AreasApiService,
    private dialogService: DialogService
  ) { }

  ngOnInit() {
    this.subscription = this.store.pipe(select(getBuildings)).subscribe(buildings => {
      this.buildingsDropdownData = (buildings ?? []).map(building => ({ text: building.label, value: building.id }));
    });
    this.store.pipe(select(getSelectedSiteId), take(1)).subscribe(siteId => { this.siteId = siteId; });
  }

  selectBuilding(row: NewAreaRow, event: DropDownListElement) {
    row.buildingId = event?.value ?? null;
  }

  addMoreRows() {
    this.rows.push({ label: '', buildingId: null });
  }

  removeRow(index: number) {
    this.rows.splice(index, 1);
  }

  trackByIndex(index: number): number {
    return index;
  }

  canSave(): boolean {
    return this.rows.length > 0 && this.rows.every(row => !!row.label?.trim() && !!row.buildingId) && !this.isSaving;
  }

  save() {
    if (!this.canSave()) {
      return;
    }
    this.isSaving = true;
    // Each row can pick a different Building, so areas are created directly through
    // AreasApiService (the row's buildingId) rather than AreasService.addArea, which always
    // reads buildingId from the app's single "currently selected building" state -- that would
    // silently ignore a row's own Building choice whenever it differs from the selected one.
    forkJoin(this.rows.map(row => this.areasApiService.getAreaNumber(this.siteId).pipe(take(1)))).subscribe(
      numbers => {
        const newAreas: Area[] = this.rows.map((row, index) => ({
          id: undefined,
          buildingId: row.buildingId,
          label: row.label.trim(),
          number: numbers[index]
        }));
        forkJoin(newAreas.map(area => this.areasApiService.addArea(area))).subscribe(
          createdAreas => {
            createdAreas.forEach(created => this.store.dispatch(new AddAreaAction(created)));
            this.isSaving = false;
            this.closeAndReset();
          },
          error => {
            this.isSaving = false;
            console.log('[AreaFormDialogComponent] save', 'Error creating areas', error);
          }
        );
      },
      error => {
        this.isSaving = false;
        console.log('[AreaFormDialogComponent] save', 'Error fetching area numbers', error);
      }
    );
  }

  cancel() {
    this.closeAndReset();
  }

  private closeAndReset() {
    this.rows = [{ label: '', buildingId: null }];
    this.dialogService.closeDialog(DialogKeys.ADD_AREA);
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}
