import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { DialogConfig } from '../../../../shared/components/dialog/model/dialogConfig.model';
import { SetAppTitleAction } from '../../../../state/app-title';
import { AppState } from '../../../../state/app.state';
import { getSelectedSite } from '../../../../state/active-sites';
import { ZonesService } from '../../services/zones.service';
import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { getActiveSiteHmiSetting } from '../../../settings/state/hmi';
import { HmiSetting } from '../../../../model/hmi';
import { DeviceBrand } from '../../../../model/domain/device-brand.enum';

@Component({
  selector: 'app-zones',
  templateUrl: './zones.component.html'
})
export class ZonesComponent extends UnsubscribeDirective implements OnInit {

  addZoneDialog: DialogConfig = { key: DialogKeys.ADD_ZONE };
  addAreaDialog: DialogConfig = { key: DialogKeys.ADD_AREA };
  editBuildingDialog: DialogConfig = { key: DialogKeys.EDIT_BUILDING };
  editAreaDialog: DialogConfig = { key: DialogKeys.EDIT_AREA };
  isLoaderVisible: boolean = false;
  isNotifier: boolean = false;
  isNetworkedZoneEnable: boolean = true;

  constructor(private store: Store<AppState>, private zonesService: ZonesService,private router: Router) {
    super();
    this.store.dispatch(new SetAppTitleAction('ACTIVESITE_ZONES'));
    this.makeDomElementInactive('navbar__reports--id');
  }

  ngOnInit() {
    this.isLoaderVisible = true;
    
    // Load HMI settings first to determine navigation behavior
    this.store.select(getActiveSiteHmiSetting).pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe((hmi: HmiSetting) => {
        this.isNotifier = !!(hmi && (hmi.deviceBrand === DeviceBrand.Notifier || hmi.deviceBrand === DeviceBrand.HBS));
        this.isNetworkedZoneEnable = hmi?.isNetworkZoneModeEnabled ?? true;
      });

    this.store.select(getSelectedSite).pipe(takeUntil(this.ngUnsubscribe$))
      .subscribe(selectedSite => {
        this.zonesService.containsAnyZones(selectedSite.id).pipe(takeUntil(this.ngUnsubscribe$))
          .subscribe((zonesExist) => {
            this.isLoaderVisible = false;
            if (!zonesExist) {
              // When isNotifier && !isNetworkedZoneEnable, navigate to grid instead of empty
              if (this.isNotifier && !this.isNetworkedZoneEnable) {
                this.router.navigate(['/dashboard', 'site', 'zones', 'overview', 'grid']);
              } else {
                this.router.navigate(['/dashboard', 'site', 'zones', 'empty']);
              }
            }
          },
          (error: any) => {
            console.log('Error while checking zones exist', error);
            this.isLoaderVisible = false;
          });
      });
  }

  makeDomElementInactive(domElementId: string) {
    const el = document.getElementById(domElementId);
    if (!!el) {
      el.classList.remove('active');
    }
  }
}