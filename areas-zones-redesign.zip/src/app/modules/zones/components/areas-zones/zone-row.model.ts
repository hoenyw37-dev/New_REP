import { ZoneType } from '../../model/zone-type';

/** Flat row for the Zones tab (design frame "Zone 1"). One row can represent several underlying
 *  `Zone` records that share the same zone number and area (grouped client-side -- see README
 *  "Zone type grouping" for why, and what should replace this once confirmed against the
 *  backend's real multi-dependency grouping). */
export interface ZoneRow {
  srNo: number;
  /** ids of every underlying Zone record this row represents (one per type). */
  ids: string[];
  zone: string;
  types: ZoneType[];
  building: string;
  area: string;
  deviceCount: number;
  lastUpdated: string;
}
