/** Flat row for the Areas tab (design frame "Area 1"). */
export interface AreaRow {
  srNo: number;
  id: string;
  area: string;
  building: string;
  zoneCount: number;
  /** GAP: no existing endpoint returns panel/device counts or a last-updated date for an Area
   *  (see README). Shown as "—" until a real source is identified. */
  panelCount: string;
  deviceCount: string;
  lastUpdated: string;
}
