import { Component, OnDestroy, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { combineLatest, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { DialogSize } from '../../../../shared/components/dialog/dialogSize.enum';
import { AppState } from '../../../../state/app.state';
import { getAreas } from '../../../../state/areas';
import { getBuildings } from '../../../../state/buildings';
import { Zone } from '../../model/zone';
import { getAlarmZoneListState, getControlZoneListState, getDetectionZoneListState } from '../../state/zone-list';
import { AreaRow } from './area-row.model';
import { ZoneRow } from './zone-row.model';

/**
 * Combined "Areas & Zones" page (design frames Area 1 / Zone 1): one page, two tabs, each
 * backed by data already in the NgRx store (no new backend calls). The Zones tab groups the
 * site's flat Zone records -- which only ever carry ONE zoneType each -- by (zoneNumber, areaId)
 * so that a zone created with several types renders as a single row with several type chips,
 * matching the design. See README "Zone type grouping" for why this grouping key was chosen
 * over `multiDependencyRef`, and what to swap in once that's confirmed against the backend.
 */
@Component({
  selector: 'app-areas-zones',
  templateUrl: './areas-zones.component.html',
  styleUrls: ['./areas-zones.component.scss']
})
export class AreasZonesComponent implements OnInit, OnDestroy {
  activeTab: 'areas' | 'zones' = 'areas';
  searchText = '';
  page = 0;
  pageSize = 10;

  areaRows: AreaRow[] = [];
  zoneRows: ZoneRow[] = [];

  private subscription: Subscription;

  constructor(private store: Store<AppState>, private dialogService: DialogService) { }

  ngOnInit() {
    this.subscription = combineLatest([
      this.store.pipe(select(getAreas)),
      this.store.pipe(select(getBuildings)),
      this.store.pipe(select(getAlarmZoneListState)),
      this.store.pipe(select(getControlZoneListState)),
      this.store.pipe(select(getDetectionZoneListState))
    ]).pipe(
      map(([areas, buildings, alarmState, controlState, detectionState]) => {
        const buildingLabel = (id: string) => buildings?.find(b => b.id === id)?.label ?? '';
        const areaLabel = (id: string) => areas?.find(a => a.id === id)?.label ?? '';

        const allZones: Zone[] = [
          ...Object.values(alarmState?.entities ?? {}),
          ...Object.values(controlState?.entities ?? {}),
          ...Object.values(detectionState?.entities ?? {})
        ].filter((zone): zone is Zone => !!zone);

        const areaRows: AreaRow[] = (areas ?? []).map((area, index) => ({
          srNo: index + 1,
          id: area.id,
          area: area.label,
          building: buildingLabel(area.buildingId),
          zoneCount: allZones.filter(zone => zone.areaId === area.id).length,
          panelCount: '—',
          deviceCount: '—',
          lastUpdated: '—'
        }));

        const zoneRows = this.groupZones(allZones, areaLabel, buildingLabel, areas);

        return { areaRows, zoneRows };
      })
    ).subscribe(({ areaRows, zoneRows }) => {
      this.areaRows = areaRows;
      this.zoneRows = zoneRows;
    });
  }

  /** Groups flat Zone records by (zoneNumber, areaId) into one row per logical zone, with one
   *  type chip per distinct zoneType found in that group. See the class-level comment above. */
  private groupZones(zones: Zone[], areaLabel: (id: string) => string, buildingLabel: (id: string) => string, areas: { id: string; buildingId: string }[]): ZoneRow[] {
    const groups = new Map<string, Zone[]>();
    zones.forEach(zone => {
      const key = `${zone.zoneNumber}::${zone.areaId}`;
      const group = groups.get(key) ?? [];
      group.push(zone);
      groups.set(key, group);
    });

    return Array.from(groups.values()).map((group, index) => {
      const first = group[0];
      const area = areas.find(a => a.id === first.areaId);
      return {
        srNo: index + 1,
        ids: group.map(zone => zone.id),
        zone: first.label,
        types: Array.from(new Set(group.map(zone => zone.zoneType))).filter(Boolean) as any,
        building: area ? buildingLabel(area.buildingId) : '',
        area: areaLabel(first.areaId),
        deviceCount: 0,
        lastUpdated: '—'
      };
    });
  }

  private get filteredAreaRowsAll(): AreaRow[] {
    const term = this.searchText.trim().toLowerCase();
    return !term ? this.areaRows : this.areaRows.filter(row =>
      [row.area, row.building].some(value => value.toLowerCase().includes(term)));
  }

  private get filteredZoneRowsAll(): ZoneRow[] {
    const term = this.searchText.trim().toLowerCase();
    return !term ? this.zoneRows : this.zoneRows.filter(row =>
      [row.zone, row.building, row.area].some(value => value.toLowerCase().includes(term)));
  }

  get filteredAreaRows(): AreaRow[] {
    return this.paginate(this.filteredAreaRowsAll);
  }

  get filteredZoneRows(): ZoneRow[] {
    return this.paginate(this.filteredZoneRowsAll);
  }

  get totalRows(): number {
    return this.activeTab === 'areas' ? this.filteredAreaRowsAll.length : this.filteredZoneRowsAll.length;
  }

  private paginate<T>(rows: T[]): T[] {
    const start = this.page * this.pageSize;
    return rows.slice(start, start + this.pageSize);
  }

  onPageChange(page: number) {
    this.page = page;
  }

  onSearchChange(text: string) {
    this.searchText = text;
    this.page = 0;
  }

  setTab(tab: 'areas' | 'zones') {
    this.activeTab = tab;
    this.page = 0;
  }

  openAddArea() {
    this.dialogService.openDialog(DialogKeys.ADD_AREA);
  }

  openAddZone() {
    this.dialogService.openDialog(DialogKeys.ADD_ZONE);
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}
