import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../shared/auth/auth-guard/auth.guard';
import { NoZoneSelectedComponent } from './components/no-zone-selected/no-zone-selected.component';
import { ZoneDetailsComponent } from './components/zone-details/zone-details.component';
import { ZoneDevicesComponent } from './components/zone-devices/zone-devices.component';
import { ZoneMultiDependencyComponent } from './components/zone-multi-dependency/zone-multi-dependency.component';
import { ZoneOverviewComponent } from './components/zone-overview/zone-overview.component';
import { ZonesEmptyComponent } from './components/zones-empty/zones-empty.component';
import { ZonesGridViewComponent } from './components/zones-grid-view/zones-grid-view.component';
import { ZonesListViewComponent } from './components/zones-list-view/zones-list-view.component';
import { ZonesOverviewComponent } from './components/zones-overview/zones-overview.component';
import { ZonesComponent } from './components/zones/zones.component';
import { AreasZonesComponent } from './components/areas-zones/areas-zones.component';
import { UnsavedChangesGuard } from '../../core/services/can-deactivate-guard.service';
export const routes: Routes = [
  {
    path: '', component: ZonesComponent,
    canActivate: [AuthGuard],
    children: [
      // New combined Areas & Zones page (design frames Area 1 / Zone 1). Added as a sibling
      // route rather than replacing the 'overview' default, since that default's redirect to
      // 'overview/grid' vs 'empty' depends on HMI/notifier checks in ZonesComponent.ngOnInit()
      // that this reference implementation does not attempt to re-evaluate. See README.
      { path: 'manage', component: AreasZonesComponent, canActivate: [AuthGuard] },
      { path: 'overview', pathMatch: 'full', redirectTo: 'overview/grid', canActivate: [AuthGuard] },
      {
        path: 'overview', component: ZonesOverviewComponent, canActivate: [AuthGuard], children: [
          {
            path: 'grid', component: ZonesGridViewComponent, canActivate: [AuthGuard], children: [
              {
                path: 'zone/:id', component: ZoneDetailsComponent, canActivate: [AuthGuard], children: [
                  { path: 'overview', component: ZoneOverviewComponent, canActivate: [AuthGuard],canDeactivate: [UnsavedChangesGuard] },
                  { path: 'devices', component: ZoneDevicesComponent, canActivate: [AuthGuard] },
                  { path: 'multidependencies', component: ZoneMultiDependencyComponent, canActivate: [AuthGuard] },
                  { path: '', pathMatch: 'full', redirectTo: 'devices', canActivate: [AuthGuard] }
                ]
              },
              { path: '', pathMatch: 'full', component: NoZoneSelectedComponent, canActivate: [AuthGuard] }
            ]
          },
          { path: 'list', component: ZonesListViewComponent, canActivate: [AuthGuard] },
          { path: '', pathMatch: 'full', redirectTo: 'grid', canActivate: [AuthGuard] }
        ]
      },
      { path: 'empty', component: ZonesEmptyComponent, canActivate: [AuthGuard] },
      { path: '', pathMatch: 'full', redirectTo: 'overview', canActivate: [AuthGuard] }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ZonesRoutingModule {
}