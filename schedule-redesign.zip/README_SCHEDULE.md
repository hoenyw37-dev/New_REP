# Schedule page redesign: README

## What was built
The Schedule feature already existed (`src/app/modules/schedule`), so it was **restyled and extended, not duplicated**. No backend calls, services, or the recurrence data model were changed.

- **Rules list (frame 1):** header (title, search, filter, "+ Schedule"), a table built with **`@tanstack/angular-table`** (Sr. No. / Schedule (link) / Area / Start date / End date / Schedule time / Duration / Occurrence / kebab menu with Edit & Delete), sortable column headers, and a custom pager ("X-Y Records Of Z", ‹ 1 2 3 … 6 ›) driven by TanStack's own pagination row model.
- **Empty state:** simplified to only the centered "+ Schedule" button, per your explicit instruction (the old image/message were removed).
- **Add/Edit Schedule dialog (frames 2-5):** a single "Repeats Every [N] [Day(s)/Week(s)/Month(s)/Year(s)]" control (the unit select is bound directly to the existing `patternType`), plus the conditional sections:
  - **Weeks:** day-of-week toggle pills (Sun...Sat).
  - **Months:** "On Day [N]" / "On The [First...] [Monday...]" radio pair.
  - **Years:** "On Day [Month] [N]" / "On The [First...] [Monday...] Of [Month]" radio pair — this UI didn't exist before; the underlying `yearlyConfiguration` model and validation were already there.
  - A blue summary box ("Scheduled For Every 2 Week(s) On Sunday, Tuesday And Thursday", etc.) built from the existing option lists.
- All new label text follows Title Case, per your instruction, via 51 new i18n keys (`sch.design.*`).

## Why TanStack Table, and a dependency note
Your project didn't have TanStack Table installed. `@tanstack/angular-table` 9.x requires Angular ≥19, but this project is Angular 18, so I installed **`@tanstack/angular-table@8.20.5`** instead (supports Angular ≥17) and added it to `package.json`/`package-lock.json`. If you already use a different TanStack version elsewhere, let me know and I'll align it.

## Files
New: `components/schedule-table/*` (the TanStack table + `ScheduleRow` model), `components/schedule-pagination/*`.
Modified: `schedule.module.ts` (ag-Grid removed, two components registered); `schedule-grid-view` ts/html/scss; `schedule-grid-view-header` ts/html/scss; `add-edit-schedule` ts/html/scss; `schedule-empty` html/scss; `src/assets/i18n/en.json` (51 keys); `package.json` / `package-lock.json` (new dependency).
Reused unchanged: every icon in `src/assets/images/icons/ce/` (from the earlier C&E work) and its `styles/_ce-design.scss` design tokens — both are imported cross-module by plain Sass `@import`, no Angular coupling.

## Verification
- `npx ngc -p src/tsconfig.app.json --noEmit` (full AOT template + type check): **0 errors.**
- Two canary runs: a deliberately broken binding was injected into `schedule-table` and into `add-edit-schedule`; ngc caught both, then they were reverted. This confirms the check is actually exercising the new code, not silently skipping it.
- **`ng build` was NOT run** (same sandbox memory limit as the C&E work) — please run it on your machine with `$env:NODE_OPTIONS="--max-old-space-size=8192"` first.
- **No visual check was done** — no backend/mock data was available in this sandbox.
- Existing specs for `schedule-grid-view`, `schedule-grid-view-header`, and `add-edit-schedule` were not run and likely need updating (they probably reference the removed ag-Grid API).
- As with the earlier C&E work, running `ngc` standalone in this sandbox needed two tsconfig flags the Angular CLI normally sets on its own. Nothing in `src/tsconfig.app.json` was changed in this deliverable, and none should be needed for `ng build` on your machine.

## Gaps and assumptions
1. **Bulk delete / row-drag / auto-height** (old header buttons) were removed — the design has no checkboxes or drag handles. Single-row Edit/Delete via the kebab menu is unchanged and fully functional.
2. **Daily "Weekday only" toggle:** the existing model (`dailyConfiguration.isWeekdaysOnly`) still exists and still saves correctly, but its UI toggle was dropped because the design's Days frame shows only "Repeats every N day(s)" with nothing else.
3. **End date:** the design shows one "End date (Optional)" field. I mapped that directly to the existing `endType`/`endDate` pair: leaving it blank sets "No end date"; picking a date sets "End by date". The old explicit "No end date" radio button is gone from the UI (its underlying value is still set correctly).
4. **Start/End time fields** use the native HTML time input (unchanged from before) rather than a custom "Select time" dropdown, since no such control existed in the codebase. Visually this is close but not an exact match to the design's control.
5. **Filter button:** present per the design but not wired to any behavior yet (no per-column filter panel was specified in the design) — the header's Search box is the only functioning filter (a client-side quick filter across every column).
6. **Kebab menu options:** Edit and Delete only (no Duplicate), matching what previously existed for schedules.
7. Where a value cannot be computed (missing area, etc.), cells show "—", consistent with the earlier C&E work.
