import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';

import { ScheduleRoutingModule } from './schedule-routing.module';
import { ScheduleComponent } from './components/schedule/schedule.component';
import { SharedModule } from '../../shared/shared.module';
import { ScheduleEmptyComponent } from './components/schedule-empty/schedule-empty.component';
import { AddEditScheduleComponent } from './components/add-edit-schedule/add-edit-schedule.component';
import { ScheduleGridViewComponent } from './components/schedule-grid-view/schedule-grid-view.component';
import { ScheduleGridViewHeaderComponent } from './components/schedule-grid-view-header/schedule-grid-view-header.component';
import { ScheduleTableComponent } from './components/schedule-table/schedule-table.component';
import { SchedulePaginationComponent } from './components/schedule-pagination/schedule-pagination.component';

@NgModule({
  imports: [
    CommonModule,
    ScheduleRoutingModule,
    SharedModule
  ],
  declarations: [
    ScheduleComponent,
    ScheduleEmptyComponent,
    AddEditScheduleComponent,
    ScheduleGridViewComponent,
    ScheduleGridViewHeaderComponent,
    ScheduleTableComponent,
    SchedulePaginationComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
  ]
})
export class ScheduleModule {
}