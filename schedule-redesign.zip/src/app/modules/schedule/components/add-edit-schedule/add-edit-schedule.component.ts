import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

import { DialogService } from '../../../../core/services/dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { DropDownListElement } from '../../../../shared/components/drop-down/model/drop-down-list-element';
import { AppState } from '../../../../state/app.state';
import { Building } from '../../../../model/building';
import { Area } from '../../../../model/area';
import { getBuildings, SelectBuildingAction } from '../../../../state/buildings';
import { getAreas, SelectAreaAction } from '../../../../state/areas';
import { getSelectedSiteId } from '../../../../state/active-sites';
import { RecurrencePatternViewModel } from '../../models/recurrence-pattern-view-model';
import { RecurrenceEndType } from '../../models/recurrence-end-type';
import { RecurrencePatternType } from '../../models/recurrence-pattern-type';
import { WeekOfMonth } from '../../models/week-of-month';
import { RecurrenceDayOfWeek } from '../../models/recurrence-day-of-week';
import { ScheduleService } from '../../services/schedule.service';
import { AddEditScheduleService } from '../../services/add-edit-schedule.service';
import { RecurrenceMonth } from '../../models/recurrence-month';

@Component({
  selector: 'app-add-edit-schedule',
  templateUrl: './add-edit-schedule.component.html',
  styleUrls: ['./add-edit-schedule.component.scss']
})
export class AddEditScheduleComponent implements OnInit, OnDestroy {
  private readonly noEndDateValue = '9999-12-31';

  @Input() isEditMode: boolean = false;

  buildingSubscription: Subscription = null;
  areaSubscription: Subscription = null;
  allAreasSubscription: Subscription = null;
  siteSubscription: Subscription = null;
  saveScheduleSubscription: Subscription = null;
  nextFreeRecurrencePatternNumberSubscription: Subscription = null;
  scheduleDialogDataSubscription: Subscription = null;

  readonly RecurrenceEndType = RecurrenceEndType;
  readonly RecurrencePatternType = RecurrencePatternType;
  readonly defaultDuration = 15;

  navigateToGridViewOnSave: boolean = false;
  buildingsDropdownData: DropDownListElement[] = [];
  areasDropdownData: DropDownListElement[] = [];
  selectedBuilding: string = null;
  selectedArea: string = null;
  allAreas: Area[] = [];
  siteId: string = '';
  recurrencePatternViewModel: RecurrencePatternViewModel = null;
  weeklySelections: { [key: string]: boolean };
  dayOfMonthOptions: number[];
  timeOptions: Array<{ value: string; label: string }>;
  weekdays: Array<{ key: string; label: string }>;
  monthOptions: Array<{ value: RecurrenceMonth; label: string }>;
  monthlyOccurrenceOptions: Array<{ value: WeekOfMonth; label: string }>;
  relativeDayOfWeekOptions: Array<{ value: RecurrenceDayOfWeek; label: string }>;
  isInvalidDuration: boolean = false;
  isInvalidEndDate: boolean = false;
  isInvalidSchedule: boolean = false;
  isInvalidRecurrencePattern: boolean = false;
  isInvalidTimeEndDate: boolean = false;

  constructor(private dialogService: DialogService,
    private store: Store<AppState>,
    private scheduleService: ScheduleService,
    private addEditScheduleService: AddEditScheduleService,
    private translateService: TranslateService
  ) { }

  ngOnInit(): void {
    this.weeklySelections = this.addEditScheduleService.getWeeklySelections();
    this.dayOfMonthOptions = this.addEditScheduleService.getDayOfMonthOptions();
    this.weekdays = this.addEditScheduleService.getWeekdays();
    this.monthOptions = this.addEditScheduleService.getMonthOptions();
    this.monthlyOccurrenceOptions = this.addEditScheduleService.getMonthlyOccurrenceOptions();
    this.relativeDayOfWeekOptions = this.addEditScheduleService.getRelativeDayOfWeekOptions();
    this.siteSubscription = this.store.pipe(select(getSelectedSiteId)).subscribe(siteId => {
      this.siteId = siteId ?? '';
    });
    this.recurrencePatternViewModel = this.addEditScheduleService.addNewSchedule();

    this.scheduleDialogDataSubscription = this.dialogService.getMessage().subscribe((message) => {
      if (message?.dialogKey === DialogKeys.ADD_EDIT_SCHEDULE && message?.recurrencePatternViewModel) {
        this.isEditMode = !!message.isEditMode;
        this.navigateToGridViewOnSave = !!message.navigateToGridViewOnSave;
        this.recurrencePatternViewModel = message.recurrencePatternViewModel;
        this.applyManagedAreaSelection();
        this.syncWeeklySelections(this.recurrencePatternViewModel.weeklyConfiguration.daysOfWeek);
        if (!this.isEditMode) {
          if (this.nextFreeRecurrencePatternNumberSubscription) {
            this.nextFreeRecurrencePatternNumberSubscription.unsubscribe();
          }

          this.nextFreeRecurrencePatternNumberSubscription = this.scheduleService.getNextFreeRecurrencePatternNumber(this.siteId)
            .subscribe(number => {
              this.recurrencePatternViewModel.number = number;
            });
        }
      }
    });

    this.buildingSubscription = this.store.pipe(select(getBuildings),
      map(buildingList => this.convertToDropDownItems(buildingList))
    ).subscribe(data => this.buildingsDropdownData = data);
    this.allAreasSubscription = this.store.pipe(select(getAreas)).subscribe(areas => {
      this.allAreas = areas ?? [];
      this.updateAreasDropdownData();

      if (this.isEditMode) {
        this.applyManagedAreaSelection();
      }
    });

    this.syncWeeklySelections(this.recurrencePatternViewModel.weeklyConfiguration.daysOfWeek);
  }

  ngOnDestroy(): void {
    if (this.siteSubscription) {
      this.siteSubscription.unsubscribe();
    }
    if (this.buildingSubscription) {
      this.buildingSubscription.unsubscribe();
    }
    if (this.areaSubscription) {
      this.areaSubscription.unsubscribe();
    }
    if (this.allAreasSubscription) {
      this.allAreasSubscription.unsubscribe();
    }
    if (this.saveScheduleSubscription) {
      this.saveScheduleSubscription.unsubscribe();
    }
    if (this.nextFreeRecurrencePatternNumberSubscription) {
      this.nextFreeRecurrencePatternNumberSubscription.unsubscribe();
    }
    if (this.scheduleDialogDataSubscription) {
      this.scheduleDialogDataSubscription.unsubscribe();
    }
  }

  selectBuilding(buildingId: string | { value?: string }) {
    this.selectedBuilding = this.getSelectedDropDownValue(buildingId);
    this.selectedArea = null;
    this.recurrencePatternViewModel.managedAreaId = '';
    this.updateAreasDropdownData();
    this.store.dispatch(new SelectBuildingAction({ Id: this.selectedBuilding, isSelectFirstManagedArea: false }));
  }

  selectArea(areaId: string | { value?: string }) {
    this.selectedArea = this.getSelectedDropDownValue(areaId);
    this.recurrencePatternViewModel.managedAreaId = this.selectedArea ?? '';
    this.store.dispatch(new SelectAreaAction(this.selectedArea));
  }

  private convertToDropDownItems(list: Array<Building | Area>): DropDownListElement[] {
    return list.map(item => ({
      value: item.id,
      text: item.label
    }));
  }

  private getSelectedDropDownValue(selectedItem: string | { value?: string }): string {
    return typeof selectedItem === 'string' ? selectedItem : selectedItem?.value ?? null;
  }

  private applyManagedAreaSelection() {
    if (!this.recurrencePatternViewModel?.managedAreaId) {
      this.selectedBuilding = null;
      this.selectedArea = null;
      this.areasDropdownData = [];
      return;
    }

    const managedArea = this.allAreas.find(area => area.id === this.recurrencePatternViewModel.managedAreaId);

    this.selectedArea = this.recurrencePatternViewModel.managedAreaId;

    if (!managedArea) {
      return;
    }

    this.selectedBuilding = managedArea.buildingId;
    this.updateAreasDropdownData();

    if (this.isEditMode) {
      this.store.dispatch(new SelectBuildingAction({ Id: managedArea.buildingId, isSelectFirstManagedArea: false }));
      this.store.dispatch(new SelectAreaAction(managedArea.id));
    }
  }

  private updateAreasDropdownData() {
    if (!this.selectedBuilding) {
      this.areasDropdownData = [];
      return;
    }

    const areasForSelectedBuilding = this.allAreas.filter(area => area.buildingId === this.selectedBuilding);
    this.areasDropdownData = this.convertToDropDownItems(areasForSelectedBuilding);
  }

  onStartTimeChange() {
    this.updateDurationFromTimes();
    this.isInvalidTimeEndDate = false;
  }

  onEndTimeChange() {
    this.updateDurationFromTimes();
    this.isInvalidTimeEndDate = false;
  }

  onStartDateChange() {
    this.isInvalidEndDate = false;
    this.isInvalidTimeEndDate = false;
    this.isInvalidSchedule = false;
  }

  onEndDateChange() {
    this.isInvalidEndDate = false;
    this.isInvalidTimeEndDate = false;
    this.isInvalidSchedule = false;
  }

  onEndTypeChange() {
    this.isInvalidEndDate = false;
    this.isInvalidSchedule = false;

    if (this.recurrencePatternViewModel?.endType !== RecurrenceEndType.EndByDate) {
      return;
    }

    if (!this.recurrencePatternViewModel.endDate || this.recurrencePatternViewModel.endDate === this.noEndDateValue) {
      this.recurrencePatternViewModel.endDate = this.getCurrentDate();
    }
  }

  saveSchedule() {
    if (!this.canSaveSchedule() || this.hasScheduleValidationErrors()) {
      return;
    }

    const schedulePayload = this.buildSchedulePayload();
    const saveRequest = this.isEditMode
      ? this.scheduleService.updateSchedule(schedulePayload)
      : this.scheduleService.addSchedule(schedulePayload);

    this.saveScheduleSubscription = saveRequest.subscribe((response) => {
      console.log('Schedule saved successfully', response);
      this.selectedArea = null;
      this.dialogService.closeDialog(DialogKeys.ADD_EDIT_SCHEDULE);
      this.scheduleService.handleScheduleSaved(this.navigateToGridViewOnSave);
    },
      (error) => {
        console.error('Error saving schedule', error);
      });
  }

  cancel() {
    this.selectedArea = null;
    this.dialogService.closeDialog(DialogKeys.ADD_EDIT_SCHEDULE);
  }

  canSaveSchedule(): boolean {
    const label = this.recurrencePatternViewModel?.label?.trim();
    const managedAreaId = (this.selectedArea ?? this.recurrencePatternViewModel?.managedAreaId ?? '').trim();

    return !!label && !!managedAreaId;
  }

  /**
   * Design's single "Repeats every [N] [unit]" control. The unit select (see the template) is
   * bound directly to `recurrencePatternViewModel.patternType`; this getter/setter routes the
   * interval number to whichever pattern-specific config field that type actually uses, so the
   * rest of this component (validation, save, the summary below) needs no other changes.
   */
  get repeatInterval(): number {
    switch (this.recurrencePatternViewModel?.patternType) {
      case RecurrencePatternType.Daily: return this.recurrencePatternViewModel.dailyConfiguration?.recurrenceDay;
      case RecurrencePatternType.Weekly: return this.recurrencePatternViewModel.weeklyConfiguration?.recurrenceWeek;
      case RecurrencePatternType.Monthly: return this.recurrencePatternViewModel.monthlyConfiguration?.recurrenceMonth;
      case RecurrencePatternType.Yearly: return this.recurrencePatternViewModel.yearlyConfiguration?.recurrenceYear;
      default: return null;
    }
  }

  set repeatInterval(value: number) {
    const numericValue = value == null || (value as any) === '' ? null : Number(value);
    switch (this.recurrencePatternViewModel?.patternType) {
      case RecurrencePatternType.Daily: this.recurrencePatternViewModel.dailyConfiguration.recurrenceDay = numericValue; break;
      case RecurrencePatternType.Weekly: this.recurrencePatternViewModel.weeklyConfiguration.recurrenceWeek = numericValue; break;
      case RecurrencePatternType.Monthly: this.recurrencePatternViewModel.monthlyConfiguration.recurrenceMonth = numericValue; break;
      case RecurrencePatternType.Yearly: this.recurrencePatternViewModel.yearlyConfiguration.recurrenceYear = numericValue; break;
    }
    this.isInvalidSchedule = false;
  }

  /** Design's single "End date (Optional)" field -- empty means no end date, a value means end-by-date. */
  get endDateInput(): string {
    return this.recurrencePatternViewModel?.endType === RecurrenceEndType.EndByDate
      ? this.recurrencePatternViewModel.endDate : '';
  }

  onEndDateInputChange(value: string) {
    if (value) {
      this.recurrencePatternViewModel.endType = RecurrenceEndType.EndByDate;
      this.recurrencePatternViewModel.endDate = value;
    } else {
      this.recurrencePatternViewModel.endType = RecurrenceEndType.NoEndDate;
      this.recurrencePatternViewModel.endDate = this.noEndDateValue;
    }
    this.onEndDateChange();
  }

  /** Builds the blue info-box text under the pattern fields (design frames 3/4/5), e.g.
   *  "Scheduled For Every 2 Week(s) On Sunday, Tuesday And Thursday". */
  getRecurrenceSummary(): string {
    const type = this.recurrencePatternViewModel?.patternType;
    const count = this.repeatInterval || 1;

    if (type === RecurrencePatternType.Daily) {
      return this.translateService.instant('sch.design.summary.daily', { count });
    }

    if (type === RecurrencePatternType.Weekly) {
      const days = this.weekdays.filter(day => this.weeklySelections[day.key]).map(day => day.label);
      return days.length === 0
        ? this.translateService.instant('sch.design.summary.weekly-no-days', { count })
        : this.translateService.instant('sch.design.summary.weekly', { count, days: this.joinWithAnd(days) });
    }

    if (type === RecurrencePatternType.Monthly) {
      const config = this.recurrencePatternViewModel.monthlyConfiguration;
      if (config?.useRelativeDay) {
        const week = this.monthlyOccurrenceOptions.find(option => option.value === config.weekOfMonth)?.label ?? '';
        const day = this.relativeDayOfWeekOptions.find(option => option.value === config.relativeDayOfWeek)?.label ?? '';
        return this.translateService.instant('sch.design.summary.monthly-relative', { count, week, day });
      }
      return this.translateService.instant('sch.design.summary.monthly-day', { count, day: config?.dayOfMonth });
    }

    if (type === RecurrencePatternType.Yearly) {
      const config = this.recurrencePatternViewModel.yearlyConfiguration;
      const month = this.monthOptions.find(option => option.value === config?.month)?.label ?? '';
      if (config?.useRelativeDay) {
        const week = this.monthlyOccurrenceOptions.find(option => option.value === config.weekOfMonth)?.label ?? '';
        const day = this.relativeDayOfWeekOptions.find(option => option.value === config.relativeDayOfWeek)?.label ?? '';
        return this.translateService.instant('sch.design.summary.yearly-relative', { count, week, day, month });
      }
      return this.translateService.instant('sch.design.summary.yearly-day', { count, month, day: config?.dayOfMonth });
    }

    return '';
  }

  private joinWithAnd(items: string[]): string {
    if (items.length <= 1) { return items.join(''); }
    const and = this.translateService.instant('sch.design.and');
    return `${items.slice(0, -1).join(', ')} ${and} ${items[items.length - 1]}`;
  }

  getDurationLabel(): string {
    const duration = this.recurrencePatternViewModel?.duration;

    if (duration == null) {
      return '';
    }

    const hours = Math.floor(duration / 60);
    const minutes = duration % 60;
    const durationParts: string[] = [];

    if (hours > 0) {
      durationParts.push(`${hours} ${this.translateService.instant('schedules.hours.label')}`);
    }

    if (minutes > 0 || hours === 0) {
      durationParts.push(`${minutes} ${this.translateService.instant('panels.basicdata.minutes')}`);
    }

    return durationParts.join(' ');
  }

  private isEndDateBeforeStartDate() {
    this.isInvalidEndDate = false;
    if (this.recurrencePatternViewModel?.endType !== RecurrenceEndType.EndByDate) {
      this.isInvalidEndDate = false;
    }

    const startDate = this.recurrencePatternViewModel?.startDate;
    const endDate = this.recurrencePatternViewModel?.endDate;

    if (!startDate || !endDate) {
      this.isInvalidEndDate = false;
    }

    this.isInvalidEndDate = endDate < startDate;
  }

  private isTimeSchedule(): boolean {
    const startTime = this.recurrencePatternViewModel?.startTime;
    const endTime = this.recurrencePatternViewModel?.endTime;

    if (!startTime || !endTime) {
      return false;
    }

    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    const startTotalMinutes = (startHours * 60) + startMinutes;
    const endTotalMinutes = (endHours * 60) + endMinutes;

    return endTotalMinutes <= startTotalMinutes;
  }

  private isScheduleEndDateInvalid() {
    this.isInvalidTimeEndDate = false;

    if (this.recurrencePatternViewModel?.patternType !== RecurrencePatternType.Daily) {
      return;
    }

    if (this.recurrencePatternViewModel?.endType !== RecurrenceEndType.EndByDate) {
      return;
    }

    const startDate = this.recurrencePatternViewModel?.startDate;
    const endDate = this.recurrencePatternViewModel?.endDate;

    if (!startDate || !endDate) {
      return;
    }

    const hasValidDuration = this.recurrencePatternViewModel?.duration > 0;

    this.isInvalidTimeEndDate = hasValidDuration && this.isTimeSchedule() && endDate <= startDate;
  }

  private isDurationInvalid() {
    this.isInvalidDuration = this.recurrencePatternViewModel.duration <= 0;
  }

  private isRecurrencePatternInvalid(): boolean {
    this.isInvalidRecurrencePattern = false;
    if (this.recurrencePatternViewModel?.patternType === RecurrencePatternType.Daily)
    {
      const isWeekdaysOnly = this.recurrencePatternViewModel?.dailyConfiguration?.isWeekdaysOnly;
      const recurrenceDay = this.recurrencePatternViewModel?.dailyConfiguration?.recurrenceDay;
      if (!isWeekdaysOnly && recurrenceDay <= 0)
      {
        this.isInvalidRecurrencePattern = true;
      }
    }
    else if (this.recurrencePatternViewModel?.patternType === RecurrencePatternType.Weekly) {
      const daysOfWeek = this.syncWeeklyConfigurationDaysOfWeek();
      const recurrenceWeek = this.recurrencePatternViewModel?.weeklyConfiguration?.recurrenceWeek;
      if (daysOfWeek === RecurrenceDayOfWeek.None) {
        this.isInvalidRecurrencePattern = true;
      }
      else if (recurrenceWeek <= 0)
      {
        this.isInvalidRecurrencePattern = true;
      }
    }
    else if (this.recurrencePatternViewModel?.patternType === RecurrencePatternType.Monthly) {
      const recurrenceMonth = this.recurrencePatternViewModel?.monthlyConfiguration?.recurrenceMonth;
      if (recurrenceMonth <= 0)
      {
        this.isInvalidRecurrencePattern = true;
      }
    }
    else if (this.recurrencePatternViewModel?.patternType === RecurrencePatternType.Yearly) {
      const recurrenceYear = this.recurrencePatternViewModel?.yearlyConfiguration?.recurrenceYear;
      const useRelativeDay = this.recurrencePatternViewModel?.yearlyConfiguration?.useRelativeDay;
      const month = this.recurrencePatternViewModel?.yearlyConfiguration?.month;
      const dayOfMonth = this.recurrencePatternViewModel?.yearlyConfiguration?.dayOfMonth;
      const maxDayOfMonth = this.getMaxDayOfMonth(month);

      if (recurrenceYear <= 0)
      {
        this.isInvalidRecurrencePattern = true;
      }
      else if (!useRelativeDay && (dayOfMonth <= 0 || dayOfMonth > maxDayOfMonth))
      {
        this.isInvalidRecurrencePattern = true;
      }
    }
    
    return this.isInvalidRecurrencePattern;
  }

  private updateDurationFromTimes(): void {
    this.isInvalidDuration = false;
    this.isInvalidSchedule = false;
    const durationMinutes = this.getDurationInMinutes(this.recurrencePatternViewModel.startTime, this.recurrencePatternViewModel.endTime);
    this.recurrencePatternViewModel.duration = durationMinutes;
  }

  private hasScheduleValidationErrors(): boolean {
    this.isEndDateBeforeStartDate();
    this.isScheduleEndDateInvalid();
    this.isDurationInvalid();
    this.isRecurrencePatternInvalid();

    this.isInvalidSchedule = this.isInvalidEndDate || this.isInvalidTimeEndDate
      || this.isInvalidDuration || this.isInvalidRecurrencePattern;
    return this.isInvalidSchedule;
  }

  private getDurationInMinutes(startTime: string, endTime: string): number {
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);
    const startTotalMinutes = (startHours * 60) + startMinutes;
    const endTotalMinutes = (endHours * 60) + endMinutes;
    const minutesInDay = 24 * 60;

    return (endTotalMinutes - startTotalMinutes + minutesInDay) % minutesInDay;
  }

  private buildSchedulePayload(): RecurrencePatternViewModel {
    const endDate = this.recurrencePatternViewModel.endType === RecurrenceEndType.NoEndDate
      ? this.noEndDateValue : this.recurrencePatternViewModel.endDate;
    const daysOfWeek = this.syncWeeklyConfigurationDaysOfWeek();

    return {
      ...this.recurrencePatternViewModel,
      siteId: this.siteId,
      managedAreaId: this.selectedArea ?? this.recurrencePatternViewModel.managedAreaId ?? '',
      endDate,
      weeklyConfiguration: {
        ...this.recurrencePatternViewModel.weeklyConfiguration,
        daysOfWeek
      }
    };
  }

  private syncWeeklyConfigurationDaysOfWeek(): RecurrenceDayOfWeek {
    const daysOfWeek = this.getSelectedWeekdaysFlag();

    if (this.recurrencePatternViewModel?.weeklyConfiguration) {
      this.recurrencePatternViewModel.weeklyConfiguration.daysOfWeek = daysOfWeek;
    }

    return daysOfWeek;
  }

  private getMaxDayOfMonth(month: RecurrenceMonth): number {
    switch (month) {
      case RecurrenceMonth.February:
        return 28;
      case RecurrenceMonth.April:
      case RecurrenceMonth.June:
      case RecurrenceMonth.September:
      case RecurrenceMonth.November:
        return 30;
      default:
        return 31;
    }
  }

  private getSelectedWeekdaysFlag(): RecurrenceDayOfWeek {
    let selectedDays = RecurrenceDayOfWeek.None;

    if (this.weeklySelections.sunday) {
      selectedDays |= RecurrenceDayOfWeek.Sunday;
    }
    if (this.weeklySelections.monday) {
      selectedDays |= RecurrenceDayOfWeek.Monday;
    }
    if (this.weeklySelections.tuesday) {
      selectedDays |= RecurrenceDayOfWeek.Tuesday;
    }
    if (this.weeklySelections.wednesday) {
      selectedDays |= RecurrenceDayOfWeek.Wednesday;
    }
    if (this.weeklySelections.thursday) {
      selectedDays |= RecurrenceDayOfWeek.Thursday;
    }
    if (this.weeklySelections.friday) {
      selectedDays |= RecurrenceDayOfWeek.Friday;
    }
    if (this.weeklySelections.saturday) {
      selectedDays |= RecurrenceDayOfWeek.Saturday;
    }

    return selectedDays;
  }

  private syncWeeklySelections(daysOfWeek: RecurrenceDayOfWeek): void {
    this.weeklySelections = {
      sunday: (daysOfWeek & RecurrenceDayOfWeek.Sunday) === RecurrenceDayOfWeek.Sunday,
      monday: (daysOfWeek & RecurrenceDayOfWeek.Monday) === RecurrenceDayOfWeek.Monday,
      tuesday: (daysOfWeek & RecurrenceDayOfWeek.Tuesday) === RecurrenceDayOfWeek.Tuesday,
      wednesday: (daysOfWeek & RecurrenceDayOfWeek.Wednesday) === RecurrenceDayOfWeek.Wednesday,
      thursday: (daysOfWeek & RecurrenceDayOfWeek.Thursday) === RecurrenceDayOfWeek.Thursday,
      friday: (daysOfWeek & RecurrenceDayOfWeek.Friday) === RecurrenceDayOfWeek.Friday,
      saturday: (daysOfWeek & RecurrenceDayOfWeek.Saturday) === RecurrenceDayOfWeek.Saturday
    };
  }

  private getCurrentDate(): string {
    return new Date().toISOString().split('T')[0];
  }
}