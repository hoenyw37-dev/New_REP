import { Component, EventEmitter, Input, Output, input } from '@angular/core';
import {
  ColumnDef, createAngularTable, getCoreRowModel, getPaginationRowModel, getSortedRowModel,
  SortingState
} from '@tanstack/angular-table';

import { ScheduleRow } from './schedule-row.model';

/**
 * TanStack-Table-backed grid for the Schedule list (design frame 1). Sorting and pagination
 * are handled by @tanstack/angular-table's row models; cell markup (the "Schedule" link and the
 * kebab menu) is rendered directly in the template rather than through flex-render, so it can
 * match the design pixel-for-pixel.
 *
 * `rows` is a signal input (Angular 18) rather than a plain @Input because createAngularTable's
 * options callback must read a signal to know when to recompute -- a plain mutated array would
 * not be picked up.
 */
@Component({
  selector: 'app-schedule-table',
  templateUrl: './schedule-table.component.html',
  styleUrls: ['./schedule-table.component.scss']
})
export class ScheduleTableComponent {
  rows = input<ScheduleRow[]>([]);
  @Input() pageSize = 10;

  @Output() editRow = new EventEmitter<ScheduleRow>();
  @Output() deleteRow = new EventEmitter<ScheduleRow>();

  private sorting: SortingState = [];

  /**
   * Column ids only -- header text is looked up from `columnLabelKeys` in the template (via the
   * translate pipe) rather than through TanStack's own header renderer, since every header is
   * plain, design-matched text with no per-column markup.
   */
  private readonly columns: ColumnDef<ScheduleRow, any>[] = [
    { id: 'srNo', accessorKey: 'srNo' },
    { id: 'schedule', accessorKey: 'schedule' },
    { id: 'area', accessorKey: 'area' },
    { id: 'startDate', accessorKey: 'startDate' },
    { id: 'endDate', accessorKey: 'endDate' },
    { id: 'scheduleTime', accessorKey: 'scheduleTime' },
    { id: 'duration', accessorKey: 'duration' },
    { id: 'occurrence', accessorKey: 'occurrence' },
    { id: 'actions' }
  ];

  readonly columnLabelKeys: { [columnId: string]: string } = {
    srNo: 'sch.design.col.sr-no',
    schedule: 'sch.design.col.schedule',
    area: 'sch.design.col.area',
    startDate: 'sch.design.col.start-date',
    endDate: 'sch.design.col.end-date',
    scheduleTime: 'sch.design.col.schedule-time',
    duration: 'sch.design.col.duration',
    occurrence: 'sch.design.col.occurrence',
    actions: ''
  };

  table = createAngularTable<ScheduleRow>(() => ({
    data: this.rows(),
    columns: this.columns,
    state: { sorting: this.sorting },
    onSortingChange: updater => {
      this.sorting = typeof updater === 'function' ? updater(this.sorting) : updater;
      this.table.setOptions(prev => ({ ...prev, state: { ...prev.state, sorting: this.sorting } }));
    },
    initialState: { pagination: { pageSize: this.pageSize, pageIndex: 0 } },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel()
  }));

  /** True for sortable data columns; the trailing kebab column has no header text to sort by. */
  isSortable(columnId: string): boolean {
    return columnId !== 'actions';
  }

  sortDirection(columnId: string): 'asc' | 'desc' | false {
    return this.table.getColumn(columnId)?.getIsSorted() ?? false;
  }

  toggleSort(columnId: string) {
    this.table.getColumn(columnId)?.toggleSorting(undefined);
  }

  get pageIndex(): number { return this.table.getState().pagination.pageIndex; }
  get pageCount(): number { return this.table.getPageCount(); }
  get totalRows(): number { return this.table.getFilteredRowModel().rows.length; }

  goToPage(page: number) {
    this.table.setPageIndex(page);
  }
}
