import { RecurrencePatternViewModel } from '../../models/recurrence-pattern-view-model';

/**
 * Flat row shape for the TanStack table (design frame 1). All text values are pre-formatted
 * by ScheduleGridViewComponent, reusing its existing label-building logic 1:1 -- only the
 * rendering layer (ag-Grid -> TanStack Table) changed, not how these strings are produced.
 */
export interface ScheduleRow {
  srNo: number;
  schedule: string;
  area: string;
  startDate: string;
  endDate: string;
  scheduleTime: string;
  duration: string;
  occurrence: string;
  /** Original record, needed by the row-actions menu (Edit / Delete) and the "Schedule" link. */
  source: RecurrencePatternViewModel;
}
