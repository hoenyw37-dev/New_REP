import { Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';

import { UnsubscribeDirective } from '../../../../shared/utility/unsubscribe-directive';

/**
 * Header bar for the Schedule list (design frame 1): title, search, filter toggle, "+ Schedule".
 * The old row-drag / auto-height / bulk-delete toggle buttons are not part of the design and were
 * removed from this bar -- see README "Gaps". Add / Edit / Delete of a single schedule are still
 * fully available (the "+ Schedule" button here, and Edit / Delete in each row's kebab menu).
 */
@Component({
  selector: 'app-schedule-grid-view-header',
  templateUrl: './schedule-grid-view-header.component.html',
  styleUrls: ['./schedule-grid-view-header.component.scss']
})
export class ScheduleGridViewHeaderComponent extends UnsubscribeDirective implements OnDestroy {

  @Output() onAddNewSchedule = new EventEmitter();
  @Output() searchChange = new EventEmitter<string>();
  @Output() filterToggle = new EventEmitter<boolean>();

  searchText = '';
  filterActive = false;

  constructor() {
    super();
  }

  addNewSchedule() {
    this.onAddNewSchedule.emit();
  }

  onSearch(value: string) {
    this.searchText = value;
    this.searchChange.emit(value);
  }

  toggleFilter() {
    this.filterActive = !this.filterActive;
    this.filterToggle.emit(this.filterActive);
  }

  ngOnDestroy() {
    this.ngUnsubscribe$.next();
    this.ngUnsubscribe$.complete();
  }
}