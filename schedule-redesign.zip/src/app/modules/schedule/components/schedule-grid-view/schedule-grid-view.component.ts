import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ScheduleRow } from '../schedule-table/schedule-row.model';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';

import { ScheduleService } from '../../services/schedule.service';
import { ScheduleDialogService } from '../../services/schedule-dialog.service';
import { DialogKeys } from '../../../../model/app-dialog-keys.enum';
import { DialogConfig } from '../../../../shared/components/dialog/model/dialogConfig.model';
import { DialogSize } from '../../../../shared/components/dialog/dialogSize.enum';
import { RecurrenceEndType } from '../../models/recurrence-end-type';
import { RecurrenceDayOfWeek } from '../../models/recurrence-day-of-week';
import { RecurrencePatternType } from '../../models/recurrence-pattern-type';
import { RecurrencePatternViewModel } from '../../models/recurrence-pattern-view-model';
import { WeekOfMonth } from '../../models/week-of-month';
import { AppState } from '../../../../state/app.state';
import { getSelectedSiteId } from '../../../../state/active-sites';
import { getAreas } from '../../../../state/areas';
import { Area } from '../../../../model/area';
import { DialogService } from '../../../../core/services/dialog.service';
import { DeleteDialogComponent } from '../../../../shared/components/delete-dialog/delete-dialog.component';

@Component({
  selector: 'app-schedule-grid-view',
  templateUrl: './schedule-grid-view.component.html',
  styleUrls: ['./schedule-grid-view.component.scss']
})
export class ScheduleGridViewComponent implements OnInit, OnDestroy {

  @ViewChild(DeleteDialogComponent, { static: true }) deleteDialogComponentObj: DeleteDialogComponent;

  deleteScheduleDialog: DialogConfig = { key: DialogKeys.DELETE_SCHEDULE, size: DialogSize.SMALL };

  siteSubscription: Subscription = null;
  recurrencePatternSubscription: Subscription = null;
  areasSubscription: Subscription = null;
  scheduleSavedSubscription: Subscription = null;

  scheduleCount: number = 0;
  scheduleGridData: Array<RecurrencePatternViewModel> = [];
  /** Flat rows for app-schedule-table (TanStack Table), built from scheduleGridData below. */
  scheduleRows: ScheduleRow[] = [];
  /** Rows after the header search box's quick filter (design frame 1's Search field). */
  filteredScheduleRows: ScheduleRow[] = [];
  searchText: string = '';
  managedAreaLabels: { [id: string]: string } = {};
  siteId: string = null;
  selectedDeleteScheduleId: string = null;
  shouldNavigateToEmptyOnRefresh: boolean = false;
  isDataLoading: boolean = false;
  hasSchedules: boolean = false;

  constructor(private scheduleService: ScheduleService,
    private store: Store<AppState>,
    protected dialogService: DialogService,
    private router: Router,
    private translate: TranslateService,
    private scheduleDialogService: ScheduleDialogService
  ) { }

  ngOnInit() {
    this.syncScheduleCount();
    this.areasSubscription = this.store.pipe(select(getAreas)).subscribe(areas => {
      this.managedAreaLabels = this.buildManagedAreaLabelMap(areas);
      this.rebuildRows();
    });

    this.siteSubscription = this.store.pipe(select(getSelectedSiteId),
      filter((siteId): siteId is string => !!siteId)).subscribe(siteId => {
        this.siteId = siteId;
        this.getSchedules();
      });

    this.scheduleSavedSubscription = this.scheduleService.scheduleSaved$.subscribe(() => {
      if (this.siteId) {
        this.getSchedules();
      }
    });
  }

  /** Builds the flat rows for app-schedule-table from scheduleGridData, reusing the existing
   *  label-building methods below unchanged (only the rendering layer moved off ag-Grid). */
  private rebuildRows() {
    this.scheduleRows = this.scheduleGridData.map((data, index) => ({
      srNo: index + 1,
      schedule: data.label,
      area: this.getManagedAreaLabel(data) || this.translate.instant('sch.design.no-value'),
      startDate: this.getStartDateTimeLabel(data) || this.translate.instant('sch.design.no-value'),
      endDate: this.getEndDateTimeLabel(data) || this.translate.instant('sch.design.no-value'),
      scheduleTime: this.getScheduleTimeLabel(data) || this.translate.instant('sch.design.no-value'),
      duration: this.getDurationLabel(data?.duration) || this.translate.instant('sch.design.no-value'),
      occurrence: this.getPatternConfigurations(data) || this.translate.instant('sch.design.no-value'),
      source: data
    }));
    this.applySearchFilter();
  }

  /** "2:00 PM - 2:30 PM" (design's "Schedule time" column) from the existing start/end time formatter. */
  private getScheduleTimeLabel(data?: RecurrencePatternViewModel): string {
    const start = this.getFormattedTimeLabel(data?.startTime);
    const end = this.getFormattedTimeLabel(data?.endTime);
    if (start && end) { return `${start} - ${end}`; }
    return start || end || '';
  }

  /** Header search box (design frame 1): a quick filter across every visible column's text. */
  onSearchChange(text: string) {
    this.searchText = text;
    this.applySearchFilter();
  }

  private applySearchFilter() {
    const term = this.searchText.trim().toLowerCase();
    this.filteredScheduleRows = !term ? this.scheduleRows : this.scheduleRows.filter(row =>
      [row.schedule, row.area, row.startDate, row.endDate, row.scheduleTime, row.duration, row.occurrence]
        .some(value => value.toLowerCase().includes(term)));
  }

  private getSchedules() {
    this.isDataLoading = true;
    this.recurrencePatternSubscription = this.scheduleService.getRecurrencePatternsBySiteId(this.siteId, false).subscribe(patterns => {
      this.scheduleGridData = this.normalizePatterns(patterns);
      this.hasSchedules = this.scheduleGridData.length > 0;
      this.syncScheduleCount();
      this.rebuildRows();
      this.isDataLoading = false;

      if (this.shouldNavigateToEmptyOnRefresh && this.scheduleGridData.length === 0) {
        this.shouldNavigateToEmptyOnRefresh = false;
        this.router.navigate(['/dashboard', 'site', 'schedule', 'empty']);
        return;
      }

      this.shouldNavigateToEmptyOnRefresh = false;
    },
      (error: any) => {
        console.log('Error fetching schedules', error);
        this.isDataLoading = false;
      });
  }

  ngOnDestroy() {
    if (this.areasSubscription) {
      this.areasSubscription.unsubscribe();
    }
    if (this.siteSubscription) {
      this.siteSubscription.unsubscribe();
    }
    if (this.recurrencePatternSubscription) {
      this.recurrencePatternSubscription.unsubscribe();
    }
    if (this.scheduleSavedSubscription) {
      this.scheduleSavedSubscription.unsubscribe();
    }
  }

  addNewSchedule() {
    this.scheduleDialogService.openAddNewSchedulePopup(false);
  }

  /**
   * Design frame 1 has no row checkboxes / bulk-select UI, so bulk delete was dropped from this
   * screen (see README "Gaps"). Deleting a single schedule, from a row's kebab menu, is unchanged.
   */
  deleteSchedule() {
    this.scheduleService.deleteSchedule(this.selectedDeleteScheduleId).subscribe(() => {
      this.shouldNavigateToEmptyOnRefresh = true;
      this.getSchedules();
    },
      (error: any) => {
        console.log('Error deleting schedule', error);
      });
  }

  /** Called from app-schedule-table's (editRow) output (the "Schedule" link and the kebab's Edit item). */
  editSelectedSchedule(row: ScheduleRow) {
    this.scheduleDialogService.openEditSchedulePopup(row.source);
  }

  /** Called from app-schedule-table's (deleteRow) output (the kebab's Delete item). */
  deleteSelectedSchedule(row: ScheduleRow) {
    this.selectedDeleteScheduleId = row.source.id;
    this.deleteDialogComponentObj.config = this.scheduleDialogService.populateDeleteScheduleConfig(false, this.deleteScheduleDialog.key);
    this.dialogService.openDialog(this.deleteScheduleDialog.key);
  }

  private getManagedAreaLabel(data?: RecurrencePatternViewModel): string {
    if (!data?.managedAreaId) {
      return '';
    }

    return this.managedAreaLabels[data.managedAreaId] ?? data.managedAreaId;
  }

  private getPatternTypeLabel(data?: RecurrencePatternViewModel): string {
    if (!data) {
      return '';
    }

    switch (data.patternType) {
      case RecurrencePatternType.Daily:
        return this.translate.instant('schedules.daily');
      case RecurrencePatternType.Weekly:
        return this.translate.instant('schedules.weekly');
      case RecurrencePatternType.Monthly:
        return this.translate.instant('schedules.monthly');
      case RecurrencePatternType.Yearly:
        return this.translate.instant('schedules.yearly');
      default:
        return '';
    }
  }

  private getPatternConfigurations(data?: RecurrencePatternViewModel): string {
    if (!data) {
      return '';
    }

    switch (data.patternType) {
      case RecurrencePatternType.Daily:
        return this.getDailyConfigurationSummary(data);
      case RecurrencePatternType.Weekly:
        return this.getWeeklyConfigurationSummary(data);
      case RecurrencePatternType.Monthly:
        return this.getMonthlyConfigurationSummary(data);
      case RecurrencePatternType.Yearly:
        return this.getYearlyConfigurationSummary(data);
      default:
        return '';
    }
  }

  private getEndDateTimeLabel(data?: RecurrencePatternViewModel): string {
    const endDate = this.getEndDateValue(data);
    const endTime = this.getFormattedTimeLabel(data?.endTime);

    if (endDate && endTime) {
      return `${endDate} ${endTime}`;
    }

    return endDate || endTime || '';
  }

  private getStartDateTimeLabel(data?: RecurrencePatternViewModel): string {
    const startDate = this.normalizeDateValue(data?.startDate);
    const startTime = this.getFormattedTimeLabel(data?.startTime);

    if (startDate && startTime) {
      return `${startDate} ${startTime}`;
    }

    return startDate || startTime || '';
  }

  private getEndDateValue(data?: RecurrencePatternViewModel): string {
    if (!data) {
      return '';
    }
    
    return this.normalizeDateValue(data.endDate) ?? '';
  }

  private getFormattedTimeLabel(time: string | null | undefined): string {
    if (!time) {
      return '';
    }

    const timeMatch = time.match(/(\d{2}):(\d{2})/);

    if (!timeMatch) {
      return time;
    }

    const hours = Number(timeMatch[1]);
    const minutes = timeMatch[2];
    const period = hours >= 12 ? 'PM' : 'AM';
    const hour12 = hours % 12 || 12;

    return `${hour12}:${minutes} ${period}`;
  }

  private getDurationLabel(duration: number | string | null | undefined): string {
    if (duration == null || duration === '') {
      return '';
    }

    const totalMinutes = typeof duration === 'number' ? duration : Number(duration);

    if (Number.isNaN(totalMinutes)) {
      return duration.toString();
    }

    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    const durationParts: string[] = [];

    if (hours > 0) {
      durationParts.push(`${hours} ${this.translate.instant('schedules.hours.label')}`);
    }

    if (minutes > 0 || hours === 0) {
      durationParts.push(`${minutes} ${this.translate.instant('panels.basicdata.minutes')}`);
    }

    return durationParts.join(' ');
  }

  private getDailyConfigurationSummary(data?: RecurrencePatternViewModel): string {
    if (!data?.dailyConfiguration) {
      return '';
    }

    const { isWeekdaysOnly, recurrenceDay } = data.dailyConfiguration;

    if (isWeekdaysOnly) {
      return this.translate.instant('schedules.weekday');
    }

    return `${this.translate.instant('schedules.every')} ${recurrenceDay} ${this.translate.instant('schedules.days')}`;
  }

  private getWeeklyConfigurationSummary(data?: RecurrencePatternViewModel): string {
    if (!data?.weeklyConfiguration) {
      return '';
    }

    const { daysOfWeek, recurrenceWeek } = data.weeklyConfiguration;
    const selectedDays = this.getSelectedWeekdayLabels(daysOfWeek);
    const weeklySummary = `${this.translate.instant('schedules.recurEvery')} ${recurrenceWeek} ${this.translate.instant('schedules.weekOn')}`;

    if (selectedDays.length === 0) {
      return weeklySummary;
    }

    return `${weeklySummary} ${selectedDays.join(', ')}`;
  }

  private getMonthlyConfigurationSummary(data?: RecurrencePatternViewModel): string {
    if (!data?.monthlyConfiguration) {
      return '';
    }

    const { useRelativeDay, dayOfMonth, weekOfMonth, relativeDayOfWeek, recurrenceMonth } = data.monthlyConfiguration;

    if (useRelativeDay) {
      const weekOfMonthLabel = this.getWeekOfMonthLabel(weekOfMonth);
      const relativeDayOfWeekLabel = this.getDayOfWeekLabel(relativeDayOfWeek);

      return `${this.translate.instant('schedules.the')} ${weekOfMonthLabel}, ${relativeDayOfWeekLabel}, ${this.translate.instant('schedules.ofEvery')} ${recurrenceMonth} ${this.translate.instant('schedules.months')}`;
    }

    return `${this.translate.instant('schedules.day')} ${dayOfMonth}, ${this.translate.instant('schedules.ofEvery')} ${recurrenceMonth} ${this.translate.instant('schedules.months')}`;
  }

  private getYearlyConfigurationSummary(data?: RecurrencePatternViewModel): string {
    if (!data?.yearlyConfiguration) {
      return '';
    }

    const { useRelativeDay, dayOfMonth, month, weekOfMonth, relativeDayOfWeek, recurrenceYear } = data.yearlyConfiguration;
    const monthLabel = this.getMonthLabel(month);

    if (useRelativeDay) {
      const weekOfMonthLabel = this.getWeekOfMonthLabel(weekOfMonth);
      const relativeDayOfWeekLabel = this.getDayOfWeekLabel(relativeDayOfWeek);

      return `${this.translate.instant('schedules.onThe')} ${weekOfMonthLabel}, ${relativeDayOfWeekLabel} ${this.translate.instant('schedules.of')} ${monthLabel}`;
    }

    return `${this.translate.instant('schedules.on')} ${monthLabel} ${dayOfMonth}`;
  }

  private normalizeDateValue(date: string | null | undefined): string | null {
    if (!date) {
      return null;
    }

    const dateMatch = date.match(/(\d{4})-(\d{2})-(\d{2})/);

    if (dateMatch) {
      return `${dateMatch[2]}/${dateMatch[3]}/${dateMatch[1]}`;
    }

    return date;
  }

  private getSelectedWeekdayLabels(daysOfWeek: RecurrenceDayOfWeek): string[] {
    const weekdayFlags = [
      RecurrenceDayOfWeek.Sunday,
      RecurrenceDayOfWeek.Monday,
      RecurrenceDayOfWeek.Tuesday,
      RecurrenceDayOfWeek.Wednesday,
      RecurrenceDayOfWeek.Thursday,
      RecurrenceDayOfWeek.Friday,
      RecurrenceDayOfWeek.Saturday
    ];

    return weekdayFlags
      .filter(day => (daysOfWeek & day) === day)
      .map(day => this.getDayOfWeekLabel(day));
  }

  private getDayOfWeekLabel(dayOfWeek?: RecurrenceDayOfWeek): string {
    if (!dayOfWeek) {
      return '';
    }

    switch (dayOfWeek) {
      case RecurrenceDayOfWeek.Sunday:
        return this.translate.instant('schedules.sunday');
      case RecurrenceDayOfWeek.Monday:
        return this.translate.instant('schedules.monday');
      case RecurrenceDayOfWeek.Tuesday:
        return this.translate.instant('schedules.tuesday');
      case RecurrenceDayOfWeek.Wednesday:
        return this.translate.instant('schedules.wednesday');
      case RecurrenceDayOfWeek.Thursday:
        return this.translate.instant('schedules.thursday');
      case RecurrenceDayOfWeek.Friday:
        return this.translate.instant('schedules.friday');
      case RecurrenceDayOfWeek.Saturday:
        return this.translate.instant('schedules.saturday');
      default:
        return '';
    }
  }

  private getWeekOfMonthLabel(weekOfMonth?: WeekOfMonth): string {
    if (!weekOfMonth) {
      return '';
    }

    switch (weekOfMonth) {
      case WeekOfMonth.First:
        return this.translate.instant('schedules.first');
      case WeekOfMonth.Second:
        return this.translate.instant('schedules.second');
      case WeekOfMonth.Third:
        return this.translate.instant('schedules.third');
      case WeekOfMonth.Fourth:
        return this.translate.instant('schedules.fourth');
      case WeekOfMonth.Last:
        return this.translate.instant('schedules.last');
      default:
        return '';
    }
  }

  private getMonthLabel(month?: number): string {
    const monthKeys = [
      'schedules.january',
      'schedules.february',
      'schedules.march',
      'schedules.april',
      'schedules.may',
      'schedules.june',
      'schedules.july',
      'schedules.august',
      'schedules.september',
      'schedules.october',
      'schedules.november',
      'schedules.december'
    ];

    if (!month || month < 1 || month > monthKeys.length) {
      return month?.toString() ?? '';
    }

    return this.translate.instant(monthKeys[month - 1]);
  }

  private syncScheduleCount() {
    this.scheduleCount = this.scheduleGridData?.length ?? 0;
  }

  private buildManagedAreaLabelMap(areas: Area[] | null | undefined): { [id: string]: string } {
    return (areas ?? []).reduce((labels, area) => {
      labels[area.id] = area.label;
      return labels;
    }, {} as { [id: string]: string });
  }

  private normalizePatterns(patterns: RecurrencePatternViewModel[] | { $values?: RecurrencePatternViewModel[] } | null | undefined): RecurrencePatternViewModel[] {
    if (Array.isArray(patterns)) {
      return patterns;
    }

    if (patterns && Array.isArray(patterns.$values)) {
      return patterns.$values;
    }

    return [];
  }
}